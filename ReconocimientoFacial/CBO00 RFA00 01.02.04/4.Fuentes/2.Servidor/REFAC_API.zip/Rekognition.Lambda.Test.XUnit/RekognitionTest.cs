﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Threading.Tasks;
using Xunit;

namespace Rekognition.Lambda.Test.XUnit
{
    public class RekognitionTest
    {
        string accessKey = "AKIAX6DIGQ2RR2MTMI4J";
        string secretKey = "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";
        string color = "VERDE";
        string functionName = "RekognitionPython";
        string region = "USEAST1";

        [Theory]
        [InlineData(240, 480, true)]
        public void validateRange(int height, int width, bool expected)
        {
            string id = Guid.NewGuid().ToString();
            LambdaClient client = new(new Model.LambdaConfig
            {
                accessKey = accessKey,
                secretKey = secretKey,
                functionName = functionName,
                region = region,
                percentageBW = 100,
                color = color
            });
            var start = client.StartOnPremise(id, width, height);
            Assert.Equal(expected, start.body.noseTop < (height / 2));
        }

        [Theory]
        [InlineData("_Messi1.jpg")]
        public async Task Verify(string fileName)
        {
            //string accessKey = "AKIAX6DIGQ2R34YIPSF3";
            //string secretKey = "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";
            LambdaClient client = new(new Model.LambdaConfig
            {
                accessKey = accessKey,
                secretKey = secretKey,
                functionName = functionName,
                region = region,
                percentageBW = 100,
                color = color
            });
            string id = Guid.NewGuid().ToString();
            string Path = @"C:\img\" + fileName;
            using (Image image = Image.FromFile(Path))
            {
                var start = client.StartOnPremise(id, image.Width, image.Height);
                using (MemoryStream m = new MemoryStream())
                {
                    image.Save(m, image.RawFormat);
                    byte[] imageBytes = m.ToArray();
                    string base64String = Convert.ToBase64String(imageBytes);
                    //await Assert.ThrowsAsync<ArgumentOutOfRangeException>(() => client.Verify(base64String, start.body));
                    var verify = await client.Verify(base64String, start.body, new Model.ProcessAWSConfig
                    {
                        instruction = false,
                        ppe = false,
                        labels = false
                    });
                    Assert.NotNull(verify);
                }
            }
        }

        [Theory]
        [InlineData("_Messi2.jpg")]
        public async Task Compare(string target)
        {
            //string accessKey = "AKIAUVZ32XLNZ74BT2LZ";
            //string secretKey = "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";
            //string accessKey = "AKIA2NYRZ3Z7D5ZAARI7"; //PD
            //string secretKey = "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"; //PD
            LambdaClient client = new(new Model.LambdaConfig
            {
                accessKey = accessKey,
                secretKey = secretKey,
                functionName = functionName,
                region = region,
                percentageBW = 100,
                color = color
            });
            string source = target;
            string Path = @"C:\img\";
            string base64Source = string.Empty;
            string base64Target = string.Empty;
            using (Image image = Image.FromFile(Path + source))
            {
                using (MemoryStream m = new MemoryStream())
                {
                    image.Save(m, image.RawFormat);
                    byte[] imageBytes = m.ToArray();
                    base64Source = Convert.ToBase64String(imageBytes);
                }
            }
            using (Image image = Image.FromFile(Path + target))
            {
                using (MemoryStream m = new MemoryStream())
                {
                    image.Save(m, image.RawFormat);
                    byte[] imageBytes = m.ToArray();
                    base64Target = Convert.ToBase64String(imageBytes);
                }
            }
            var facematch = await client.Compare(base64Source, base64Target, 80);
            Assert.NotNull(facematch);
        }

        [Theory]
        //[InlineData("ANVERSO.jpg")]
        //[InlineData("REVERSO.jpg")]
        //[InlineData("CARNET_REVERSO_JRGT.png")]
        [InlineData("CARNET_ANVERSO.png")]
        public async Task DetextText(string target)
        {
            List<string> anverso = new List<string>();
            anverso.Add("ESTADO PLURINACIONAL BOLIVIA");
            anverso.Add("CEDULA IDENTIDAD");
            anverso.Add("FIRMA");
            anverso.Add("INTERESADO");
            List<string> reverso = new List<string>();
            //reverso.Add("ELSERVICIOGENERALDEIDENTIFICACIONPERSONAL");
            LambdaClient client = new(new Model.LambdaConfig
            {
                accessKey = accessKey,
                secretKey = secretKey,
                functionName = functionName,
                region = region,
                percentageBW = 100,
                color = color
            });
            string source = target;
            string Path = @"C:\img\";
            string base64Source = string.Empty;
            using (Image image = Image.FromFile(Path + source))
            {
                using (MemoryStream m = new MemoryStream())
                {
                    image.Save(m, image.RawFormat);
                    byte[] imageBytes = m.ToArray();
                    base64Source = Convert.ToBase64String(imageBytes);
                }
            }
            var response = await client.DetectText(base64Source, anverso);
            Assert.True(response.statusCode == 200);
        }

        //[Theory]
        //[InlineData("ANVERSO.jpg")]
        ////[InlineData("REVERSO.jpg")]
        ////[InlineData("CARNET_REVERSO_JRGT.png")]
        ////[InlineData("CARNET_ANVERSO 2.png")]
        //public async Task DetextTextV2(string target)
        //{
        //    List<string> anverso = new List<string>();
        //    anverso.Add("ESTADO PLURINACIONAL BOLIVIA");
        //    anverso.Add("CEDULA IDENTIDAD");
        //    anverso.Add("FIRMA");
        //    anverso.Add("INTERESADO");

        //    List<string> reverso = new List<string>();
        //    //reverso.Add("ELSERVICIOGENERALDEIDENTIFICACIONPERSONAL");

        //    LambdaClient client = new LambdaClient(accessKey, secretKey, "USEAST1", "RekognitionPython", color);
        //    string source = target;
        //    string Path = @"C:\img\";
        //    string base64Source = string.Empty;
        //    using (Image image = Image.FromFile(Path + source))
        //    {
        //        using (MemoryStream m = new MemoryStream())
        //        {
        //            image.Save(m, image.RawFormat);
        //            byte[] imageBytes = m.ToArray();
        //            base64Source = Convert.ToBase64String(imageBytes);
        //        }
        //    }
        //    var response = await client.DetectTextV2(base64Source, anverso);
        //    Assert.True(response.statusCode == 200);
        //}
    }
}
