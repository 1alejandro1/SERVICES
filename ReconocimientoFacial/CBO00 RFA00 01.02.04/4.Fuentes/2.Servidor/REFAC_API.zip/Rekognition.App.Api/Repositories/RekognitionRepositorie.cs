﻿using BCP.CROSS.DATAACCESS;
using Newtonsoft.Json;
using Rekognition.App.Api.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace Rekognition.App.Api.Repositories
{
    public interface IRekognitionRepositorie
    {
        Task<bool> AddSession(int channel, string sessionID, string idc, string email, int celular, string channelName);
        Task<bool> AddChallenge(VerifyResponse response, Lambda.Model.InformationModel information);
        Task<bool> UpdateSession(string sessionID, int areaHeight, int areaLeft, int areaTop, int areaWidth, int imageHeight, int imageWidth, int minFaceAreaPercent, int noseHeight, int noseLeft, int noseTop, int noseWidth, int channel);
        Task<VerifyResponse> GetChallengeSuccess(string userId);
        Task<int> GetChannelCredentials(string accessKey, string secretKey);
        Task<bool> ExistSession(string sessionID);
        Task<CountRetryModel> GetCountRetry(string idc);
        Task<bool> AddBlocking(string idc, int channelID);
        Task<SessionModel> GetDataSession(string sessionID);
        Task<SessionDataResponse> GetDataSessionV2(string sessionID);
        Task<List<ParameterModel>> GetParameter(int channelID, string type);
        Task<List<ProcessComparisonModel>> GetProcessComparison(string sessionID);
        Task<bool> AddProcessComparison(ProcessComparisonModel response);
        Task<bool> UpdateDigitalSignature(string sessionID, int id);
        Task<ProcessModel> GetProcess(string sessionID);
        Task<bool> AddProcess(string sessionID, ProcessModel model);
        Task<bool> AddMinorAccount(string sessionID, string idcTutor);
    }
    public class RekognitionRepositorie : IRekognitionRepositorie
    {
        private readonly IDataAccess dataAccess;
        private static readonly string DATABASE_CONNECTION_NAME = "REKOGNITION";

        public RekognitionRepositorie(IDataAccess dataAccess)
        {
            this.dataAccess = dataAccess;
        }

        public async Task<bool> AddSession(int channel, string sessionID, string idc, string email, int celular, string channelName)
        {
            try
            {
                List<SqlParameter> parameters = new();
                parameters.Add(new SqlParameter("@SESSION_ID_VC", sessionID));
                parameters.Add(new SqlParameter("@IDC_VC", idc));
                parameters.Add(new SqlParameter("@EMAIL_VC", email));
                parameters.Add(new SqlParameter("@CELULAR_VC", celular));
                parameters.Add(new SqlParameter("@CHANNEL_ID_IN ", channel));
                parameters.Add(new SqlParameter("@CHANNEL_VC", channelName));
                return await dataAccess.ExecuteStoredProcedure(DATABASE_CONNECTION_NAME, "rekognition.SESSION_AddSESSION_ID_VC", parameters);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<bool> AddChallenge(VerifyResponse response, Lambda.Model.InformationModel model)
        {
            try
            {
                List<SqlParameter> parameters = new();
                parameters.Add(new SqlParameter("@SESSION_ID_VC", response.sessionID));
                parameters.Add(new SqlParameter("@STATE_BT", response.body.state));
                parameters.Add(new SqlParameter("@PHASE_VC", response.body.phase));
                parameters.Add(new SqlParameter("@MESSAGE_VC", response.body.message.ToUpper()));
                parameters.Add(new SqlParameter("@FILE_NAME_VC", (string.IsNullOrEmpty(response.body.fileName) ? string.Empty : response.body.fileName)));
                parameters.Add(new SqlParameter("@INFORMATION_VC", (model == null ? string.Empty : JsonConvert.SerializeObject(model))));
                return await dataAccess.ExecuteStoredProcedure(DATABASE_CONNECTION_NAME, "rekognition.CHALLENGE_AddSESSION_ID_VC", parameters);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<bool> UpdateSession(string sessionID, int areaHeight, int areaLeft, int areaTop, int areaWidth, int imageHeight, int imageWidth, int minFaceAreaPercent, int noseHeight, int noseLeft, int noseTop, int noseWidth, int channel)
        {
            try
            {
                List<SqlParameter> parameters = new();
                parameters.Add(new SqlParameter("@SESSION_ID_VC", sessionID));
                parameters.Add(new SqlParameter("@AREA_HEIGHT_IN", areaHeight));
                parameters.Add(new SqlParameter("@AREA_LEFT_IN", areaLeft));
                parameters.Add(new SqlParameter("@AREA_TOP_IN", areaTop));
                parameters.Add(new SqlParameter("@AREA_WIDTH_IN", areaWidth));
                parameters.Add(new SqlParameter("@CHANNEL_ID_IN", channel));
                parameters.Add(new SqlParameter("@IMAGE_HEIGHT_IN", imageHeight));
                parameters.Add(new SqlParameter("@IMAGE_WIDTH_IN", imageWidth));
                parameters.Add(new SqlParameter("@MIN_FACE_AREA_PERCENT", minFaceAreaPercent));
                parameters.Add(new SqlParameter("@NOSE_HEIGHT_IN", noseHeight));
                parameters.Add(new SqlParameter("@NOSE_LEFT_IN", noseLeft));
                parameters.Add(new SqlParameter("@NOSE_TOP_IN", noseTop));
                parameters.Add(new SqlParameter("@NOSE_WIDTH_IN", noseWidth));
                return await dataAccess.ExecuteStoredProcedure(DATABASE_CONNECTION_NAME, "rekognition.SESSION_UpdateSESSION_ID_VC", parameters);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<VerifyResponse> GetChallengeSuccess(string userId)
        {
            try
            {
                List<SqlParameter> parameters = new();
                parameters.Add(new SqlParameter("@SESSION_ID_VC", userId));
                var dataTable = await dataAccess.SelectStoredProcedure(DATABASE_CONNECTION_NAME, "rekognition.CHALLENGE_GetSESSION_ID_VC", parameters);
                if (dataTable.Rows.Count > 0)
                {
                    VerifyResponse response = new()
                    {
                        sessionID = userId,
                        body = new VerifyBodyResponse
                        {
                            state = bool.Parse(dataTable.Rows[0]["STATE_BT"].ToString()),
                            phase = dataTable.Rows[0]["PHASE_VC"].ToString(),
                            fileName = dataTable.Rows[0]["FILE_NAME_VC"].ToString(),
                            message = dataTable.Rows[0]["MESSAGE_VC"].ToString(),
                            information = dataTable.Rows[0]["INFORMATION_VC"].ToString()
                        }
                    };
                    return response;
                }
                else
                {
                    return new VerifyResponse
                    {
                        body = new VerifyBodyResponse { state = false }
                    };
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<int> GetChannelCredentials(string accessKey, string secretKey)
        {
            try
            {
                List<SqlParameter> parameters = new();
                parameters.Add(new SqlParameter("@ACCESS_KEY_VC", accessKey));
                parameters.Add(new SqlParameter("@SECRET_KEY_VC", secretKey));
                var dataTable = await dataAccess.SelectStoredProcedure(DATABASE_CONNECTION_NAME, "rekognition.CHANNEL_GetCredentials", parameters);
                return int.Parse(dataTable.Rows[0]["ID_IN"].ToString());
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<bool> ExistSession(string sessionID)
        {
            try
            {
                List<SqlParameter> parameters = new();
                parameters.Add(new SqlParameter("@SESSION_ID_VC", sessionID));
                var dataTable = await dataAccess.SelectStoredProcedure(DATABASE_CONNECTION_NAME, "rekognition.SESSION_ExistSESSION_ID_VC", parameters);
                return int.Parse(dataTable.Rows[0]["VALUE"].ToString()) == 1;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<CountRetryModel> GetCountRetry(string idc)
        {
            try
            {
                List<SqlParameter> parameters = new();
                parameters.Add(new SqlParameter("@IDC_VC", idc));
                var dataTable = await dataAccess.SelectStoredProcedure(DATABASE_CONNECTION_NAME, "rekognition.SESSION_GetCountRetry", parameters);
                CountRetryModel model = new();
                if (dataTable.Rows.Count == 0)
                    return new() { count = 0, idc = idc };
                return new()
                {
                    count = int.Parse(dataTable.Rows[0]["COUNT_IN"].ToString()),
                    idc = dataTable.Rows[0]["IDC_VC"].ToString(),
                    blocking = bool.Parse(dataTable.Rows[0]["BLOCKING_BT"].ToString())
                };
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<bool> AddBlocking(string idc, int channelID)
        {
            try
            {
                List<SqlParameter> parameters = new();
                parameters.Add(new SqlParameter("@IDC_VC", idc));
                parameters.Add(new SqlParameter("@CHANNEL_ID_IN", channelID));
                return await dataAccess.ExecuteStoredProcedure(DATABASE_CONNECTION_NAME, "rekognition.BLOCKING_AddIDC_VC", parameters);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<SessionModel> GetDataSession(string sessionID)
        {
            try
            {
                List<SqlParameter> parameters = new();
                parameters.Add(new SqlParameter("@SESSION_ID_VC", sessionID));
                DataTable table = await dataAccess.SelectStoredProcedure(DATABASE_CONNECTION_NAME, "rekognition.SESSION_GetIDC_VC", parameters);
                if (table.Rows.Count == 0)
                    throw new Exception("SESSION INVALIDA");
                return new SessionModel
                {
                    idc = table.Rows[0]["IDC_VC"].ToString(),
                    state = bool.Parse(table.Rows[0]["STATE_BT"].ToString()),
                    phase = table.Rows[0]["PHASE_VC"].ToString()
                };
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<SessionDataResponse> GetDataSessionV2(string sessionID)
        {
            try
            {
                List<SqlParameter> parameters = new();
                parameters.Add(new SqlParameter("@SESSION_ID_VC", sessionID));
                DataTable table = await dataAccess.SelectStoredProcedure(DATABASE_CONNECTION_NAME, "rekognition.SESSION_GetSESSION_ID_VC", parameters);
                if (table.Rows.Count == 0)
                    throw new Exception("SESSION INVALIDA");
                var response = new SessionDataResponse();
                response.idc = table.Rows[0]["IDC_VC"].ToString();
                response.email = table.Rows[0]["EMAIL_VC"].ToString();
                response.celular = table.Rows[0]["CELULAR_VC"].ToString();
                response.id = int.Parse(table.Rows[0]["ID_IN"].ToString());
                response.canal = table.Rows[0]["CHANNEL_VC"].ToString();
                response.idCanal = int.Parse(table.Rows[0]["ID_CHANNEL_IN"].ToString());
                if (table.Columns.Contains("IS_MINOR_ACCOUNT_BT"))
                {
                    response.esMenor = table.Rows[0]["IS_MINOR_ACCOUNT_BT"].ToString() == "1";
                    response.idcTutor = table.Rows[0]["IDC_TUTOR_VC"].ToString();
                }
                else
                {
                    response.esMenor = false;
                    response.idcTutor = string.Empty;
                }
                response.dateCreated = DateTime.Parse(table.Rows[0]["DATE_CREATED_DT"].ToString());
                return response;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<List<ParameterModel>> GetParameter(int channelID, string type)
        {
            try
            {
                List<ParameterModel> lstParameter = new();
                List<SqlParameter> parameters = new();
                parameters.Add(new SqlParameter("@CHANNEL_ID_IN", channelID));
                parameters.Add(new SqlParameter("@TYPE_VC", type));
                DataTable table = await dataAccess.SelectStoredProcedure(DATABASE_CONNECTION_NAME, "rekognition.PARAMETER_GetList", parameters);
                if (table.Rows.Count == 0)
                    throw new Exception("NO SE ENCONTRARON PARAMETROS.");
                foreach (DataRow item in table.Rows)
                {
                    lstParameter.Add(new ParameterModel
                    {
                        type = item["TYPE_VC"].ToString(),
                        name = item["NAME_VC"].ToString(),
                        value = item["VALUE_VC"].ToString()
                    });
                }
                return lstParameter;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<List<ProcessComparisonModel>> GetProcessComparison(string sessionID)
        {
            try
            {
                List<ProcessComparisonModel> lstProcessComparison = new();
                List<SqlParameter> parameters = new();
                parameters.Add(new SqlParameter("@SESSION_ID_VC", sessionID));
                var table = await dataAccess.SelectStoredProcedure(DATABASE_CONNECTION_NAME, "rekognition.PROCESS_COMPARISON_GetSESSION_ID_VC", parameters);
                if (table.Rows.Count > 0)
                {
                    foreach (DataRow item in table.Rows)
                    {
                        lstProcessComparison.Add(new ProcessComparisonModel
                        {
                            message = item["MESSAGE_VC"].ToString(),
                            percentage = decimal.Parse(item["PERCENTAGE_DC"].ToString()),
                            sessionID = sessionID,
                            status = bool.Parse(item["STATUS_BT"].ToString()),
                            type = item["TYPE_VC"].ToString()
                        });
                    }
                }
                return lstProcessComparison;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<bool> AddProcessComparison(ProcessComparisonModel model)
        {
            try
            {
                List<SqlParameter> parameters = new();
                parameters.Add(new SqlParameter("@SESSION_ID_VC", model.sessionID));
                parameters.Add(new SqlParameter("@TYPE_VC", model.type));
                parameters.Add(new SqlParameter("@STATUS_BT", model.status));
                parameters.Add(new SqlParameter("@PERCENTAGE_DC", Math.Round(model.percentage, 2)));
                parameters.Add(new SqlParameter("@MESSAGE_VC", model.message));
                return await dataAccess.ExecuteStoredProcedure(DATABASE_CONNECTION_NAME, "rekognition.PROCESS_COMPARISON_AddSESSION_ID_VC", parameters);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<bool> UpdateDigitalSignature(string sessionID, int id)
        {
            try
            {
                List<SqlParameter> parameters = new();
                parameters.Add(new SqlParameter("@SESSION_ID_VC", sessionID));
                parameters.Add(new SqlParameter("@ID_IN", id));
                return await dataAccess.ExecuteStoredProcedure(DATABASE_CONNECTION_NAME, "rekognition.DIGITAL_SIGNATURE_UpdateSESSION_ID_VC", parameters);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<ProcessModel> GetProcess(string sessionID)
        {
            try
            {
                ProcessModel process = new ProcessModel();
                List<SqlParameter> parameters = new();
                parameters.Add(new SqlParameter("@SESSION_ID_VC", sessionID));
                var table = await dataAccess.SelectStoredProcedure(DATABASE_CONNECTION_NAME, "rekognition.PROCESS_GetSESSION_ID_VC", parameters);
                if (table.Rows.Count > 0)
                {
                    process.State = bool.Parse(table.Rows[0]["STATE_BT"].ToString());
                    process.Value = table.Rows[0]["VALUE_VC"].ToString();
                }
                return process;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public async Task<bool> AddProcess(string sessionID, ProcessModel model)
        {
            try
            {
                List<SqlParameter> parameters = new();
                parameters.Add(new SqlParameter("@SESSION_ID_VC", sessionID));
                parameters.Add(new SqlParameter("@STATE_BT", model.State));
                parameters.Add(new SqlParameter("@VALUE_VC", model.Value));
                return await dataAccess.ExecuteStoredProcedure(DATABASE_CONNECTION_NAME, "rekognition.PROCESS_AddSESSION_ID_VC", parameters);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<bool> AddMinorAccount(string sessionID, string idcTutor)
        {
            try
            {
                List<SqlParameter> parameters = new();
                parameters.Add(new SqlParameter("@SESSION_ID_VC", sessionID));
                parameters.Add(new SqlParameter("@IDC_TUTOR_VC", idcTutor));
                parameters.Add(new SqlParameter("@BLANK_1", ""));
                parameters.Add(new SqlParameter("@BLANK_2", ""));
                return await dataAccess.ExecuteStoredProcedure(DATABASE_CONNECTION_NAME, "rekognition.MINOR_ACCOUNT_AddIDC_TUTOR_VC", parameters);
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
