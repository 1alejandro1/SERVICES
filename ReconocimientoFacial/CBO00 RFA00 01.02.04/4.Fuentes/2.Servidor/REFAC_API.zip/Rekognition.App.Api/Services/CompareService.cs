﻿using BCP.CROSS.COMMON;
using BCP.CROSS.LOGGER;
using BCP.CROSS.SECRYPT;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Rekognition.App.Api.Commons;
using Rekognition.App.Api.Model;
using Rekognition.Lambda;
using Rekognition.Lambda.Model;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace Rekognition.App.Api.Services
{
    public interface ICompareService
    {
        Task<ComparisonModel> CarnetIdentidad(string sessionID, string source);
        Task<DataSegipModel> GetDataSegip(string nroDocumento, string complemento);
        Task<ComparisonModel> Segip(string sessionID, string source, string idc);
        void GuardarSegip(string sessionID, DataSegipModel dataSegip, string tipo = "");
    }

    public class CompareService : ICompareService
    {
        private static readonly string sectionNameSegip = "segip_service";
        private static readonly string sectionNameAws = "aws_service";
        private readonly AwsConfig awsConfig;
        private readonly SegipConfig segipConfig;
        private readonly LambdaClient client;
        private readonly ILogger _logger;
        private readonly IFiles files;
        private readonly IManagerSecrypt secrypt;
        private readonly decimal percentage;

        public CompareService(IConfiguration configuration, ILogger logger, IFiles files, IManagerSecrypt secrypt)
        {
            this._logger = logger;
            this.files = files;
            this.secrypt = secrypt;
            this.segipConfig = new SegipConfig();
            configuration.GetSection(sectionNameSegip).Bind(segipConfig);
            this.awsConfig = new AwsConfig();
            configuration.GetSection(sectionNameAws).Bind(awsConfig);
            string access_key = this.secrypt.Desencriptar(this.awsConfig.access_key);
            string secret_key = this.secrypt.Desencriptar(this.awsConfig.secret_key);
            this.client = new LambdaClient(new LambdaConfig
            {
                accessKey = access_key,
                secretKey = secret_key,
                functionName = this.awsConfig.functionName,
                region = this.awsConfig.region,
                percentageBW = this.awsConfig.percentageBW,
                color = this.awsConfig.Color
            });
            this.percentage = 90;
        }

        public async Task<ComparisonModel> Segip(string sessionID, string source, string idc)
        {
            string nroDocument = idc.Substring(0, 8);
            string complemento = idc.Substring(11, 2);
            ComparisonModel segip = new();
            segip.percentage = 0;
            segip.proccess = "SEGIP";
            segip.state = false;
            segip.idc = string.Empty;
            segip.nombreCompleto = string.Empty;
            try
            {
                _logger.Debug($"SESSION: {sessionID} => CONSULTA SEGIP WCF INICIO");
                var dataSegip = await GetDataSegip(nroDocument, (complemento == "00" ? "" : complemento));
                _logger.Debug($"SESSION: {sessionID} => CONSULTA SEGIP WCF FIN");
                if (dataSegip.success)
                {
                    if (dataSegip.data.EsValido && dataSegip.data.intCodigoRespuesta == 2)
                    {
                        GuardarSegip(sessionID, dataSegip);
                        _logger.Debug($"SESSION: {sessionID} => COMPARACION AWS INICIO");
                        var rspCompare = await client.Compare(source, dataSegip.data.foto, 80);
                        _logger.Debug($"SESSION: {sessionID} => COMPARACION AWS FIN");
                        if (rspCompare == null)
                        {
                            rspCompare = new Lambda.Model.Body.Facematch();
                            rspCompare.Similarity = 0;
                        }
                        segip.percentage = rspCompare.Similarity;
                        segip.state = rspCompare.Similarity > this.percentage;
                        segip.message = segip.state ? "COMPLETADO" : "NO COMPLETADO";
                        segip.idc = string.IsNullOrEmpty(dataSegip.data.complemento) ? dataSegip.data.ci : $"{dataSegip.data.ci} {dataSegip.data.complemento}";
                        segip.nombreCompleto = $"{dataSegip.data.paterno} {dataSegip.data.materno} {dataSegip.data.nombre}";
                    }
                    else
                    {
                        _logger.Debug($"{sessionID}: {dataSegip.data.intCodigoRespuesta} - {dataSegip.data.strDescripcionRespuesta}");
                        segip.message = dataSegip.data.strDescripcionRespuesta.ToUpper();
                    }
                }
                else
                {
                    segip.message = $"{dataSegip.message.ToUpper()}";
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                segip.message = ex.Message.ToUpper();
            }
            return segip;

        }

        public void GuardarSegip(string sessionID, DataSegipModel dataSegip, string tipo = "")
        {
            string foto = $"FOTO_SEGIP.png";
            string certificado = $"CERTIFICADO_SEGIP.pdf";
            if (!string.IsNullOrEmpty(tipo))
            {
                foto = $"FOTO_SEGIP_{tipo}.png";
                certificado = $"CERTIFICADO_SEGIP_{tipo}.pdf";
            }
            _logger.Debug($"SESSION: {sessionID} => GUARDAR FOTO SEGIP {tipo}");
            ParameterImage parameter1 = new(sessionID, foto, dataSegip.data.foto);
            Thread t1 = new(new ParameterizedThreadStart(ThreadProc));
            t1.Start(parameter1);
            _logger.Debug($"SESSION: {sessionID} => GUARDAR CERTIFICADO SEGIP {tipo}");
            ParameterImage parameter2 = new(sessionID, certificado, Convert.ToBase64String(dataSegip.data.ReporteCertificacion));
            Thread t2 = new(new ParameterizedThreadStart(ThreadProc));
            t2.Start(parameter2);
        }

        public async Task<ComparisonModel> CarnetIdentidad(string sessionID, string source)
        {
            ComparisonModel carnet = new();
            carnet.percentage = 0;
            carnet.proccess = "CARNET";
            carnet.state = false;
            carnet.idc = string.Empty;
            carnet.nombreCompleto = string.Empty;
            try
            {
                _logger.Debug($"SESSION: {sessionID} => OBTENER CARNET ANVERSO FILE SERVER");
                carnet.image = files.OpenFile(sessionID, "CARNET_ANVERSO.png");
                _logger.Debug($"SESSION: {sessionID} => COMPARACION AWS INICIO");
                var rspCompare = await client.Compare(source, carnet.image, 80);
                _logger.Debug($"SESSION: {sessionID} => COMPARACION AWS FIN");
                if (rspCompare == null)
                {
                    rspCompare = new Body.Facematch();
                    rspCompare.Similarity = 0;
                }
                if (rspCompare == null)
                {
                    rspCompare = new Lambda.Model.Body.Facematch();
                    rspCompare.Similarity = 0;
                }
                carnet.percentage = rspCompare.Similarity;
                carnet.state = rspCompare.Similarity > this.percentage;
                carnet.message = carnet.state ? "COMPLETADO" : "NO COMPLETADO";
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                if (ex.Message.ToUpper().Contains("NOT FIND"))
                    carnet.message = "NO SE CARGO EL DOCUMENTO PARA REALIZAR LA VERIFICACION.";
                else
                    carnet.message = ex.Message.ToUpper();
            }
            return carnet;
        }

        public async Task<DataSegipModel> GetDataSegip(string nroDocumento, string complemento)
        {
            try
            {
                _logger.Debug($"INICIO BUSQUEDA SEGIP: {nroDocumento}{complemento}");
                string url = segipConfig.url;
                string method = "/segip/cliente/busqueda";
                var request = new
                {
                    segipConfig.canal,
                    strDocumentoIdentidad = nroDocumento.TrimStart('0'),
                    strComplemento = complemento == "00" ? "" : complemento,
                    strNombre = "",
                    strPaterno = "",
                    strMaterno = "",
                    strFechaNac = "",
                    strUsuario = segipConfig.usuario
                };
                var response = await ApiRest.PostAsync<DataSegipModel>(url, method, request, Authentication.None);
                if (!(response.success && response.data.EsValido))
                    _logger.Information($"NRO_DOCUMENTO: {nroDocumento}; COMPLEMENTO: {complemento} => RESPONSE: {JsonConvert.SerializeObject(response)}");
                _logger.Debug($"FIN BUSQUEDA SEGIP: {nroDocumento}{complemento}");
                return response;
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                throw;
            }
        }

        private void ThreadProc(object parameter)
        {
            ParameterImage _parameter = (ParameterImage)parameter;
            files.SaveFile(_parameter.sessionID, _parameter.image, _parameter.fileName);
        }
    }
}
