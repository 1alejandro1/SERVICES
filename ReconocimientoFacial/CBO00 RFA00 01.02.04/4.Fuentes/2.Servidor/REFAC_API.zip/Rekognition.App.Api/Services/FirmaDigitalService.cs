﻿using BCP.CROSS.COMMON;
using BCP.CROSS.LOGGER;
using BCP.CROSS.SECRYPT;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Rekognition.App.Api.Commons;
using Rekognition.App.Api.DTOs;
using Rekognition.App.Api.Model;
using Rekognition.App.Api.Model.Config;
using Rekognition.App.Api.Repositories;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Rekognition.App.Api.Services
{
    public interface IFirmaDigitalService
    {
        Task<SaveResponse> CreateClient(BaseRequest request);
        Task<SaveResponse> CreateClientV2(BaseRequest request, string carnetAnverso, string carnetReverso, string selfie);
    }

    public class FirmaDigitalService : IFirmaDigitalService
    {
        private readonly FirmaDigitalConfig _authConfig;
        private readonly ILogger _logger;
        private readonly IManagerSecrypt _secrypt;
        private readonly IRekognitionRepositorie _rekognition;
        private readonly IFiles _files;

        public FirmaDigitalService(IConfiguration configuration, ILogger logger, IManagerSecrypt secrypt, IRekognitionRepositorie rekognition, IFiles files)
        {
            this._authConfig = new FirmaDigitalConfig();
            configuration.GetSection("firmaDigital_api").Bind(_authConfig);
            this._logger = logger;
            this._secrypt = secrypt;
            this._rekognition = rekognition;
            this._files = files;
        }

        public async Task<SaveResponse> CreateClient(BaseRequest request)
        {
            try
            {
                _logger.Debug(string.Format("REQUEST: {0}", JsonConvert.SerializeObject(request)));
                var data = await _rekognition.GetDataSessionV2(request.sessionID);
                string nroDocument = data.idc.Substring(0, 8);
                string extension = data.idc.Substring(9, 2);
                string complemento = data.idc.Substring(11, 2);
                if (data.id == 0)
                {
                    _logger.Debug($"{request.sessionID} INICIO FIRMA DIGITAL");
                    string username = _secrypt.Desencriptar(_authConfig.username);
                    string password = _secrypt.Desencriptar(_authConfig.password);
                    string token = _secrypt.Desencriptar(_authConfig.token);
                    List<Tuple<string, string>> headers = new List<Tuple<string, string>>();
                    headers.Add(new Tuple<string, string>("channel", data.canal));
                    headers.Add(new Tuple<string, string>("publicToken", token));
                    headers.Add(new Tuple<string, string>("appUserId", username.Replace("_", "") + DateTime.Now.ToString("yyyyMMdd")));
                    _logger.Debug($"FIN {request.sessionID} CONFIGURACION CABECERA Y AUTENTIFICACION => {data.canal}");

                    _logger.Debug($"CARNET ANVERSO: {request.sessionID}");
                    string carnetAnverso = _files.OpenFile(request.sessionID, "CARNET_ANVERSO.png");
                    _logger.Debug($"CARNET REVERSO: {request.sessionID}");
                    string carnetReverso = _files.OpenFile(request.sessionID, "CARNET_REVERSO.png");
                    _logger.Debug($"SELFIE : {request.sessionID}");
                    string selfie = _files.OpenFile(request.sessionID, "SELFIE.png");

                    _logger.Debug($"CREATE REQUEST: {request.sessionID}");
                    var _request = new
                    {
                        NumIdc = nroDocument.TrimStart('0'),
                        ExtencionIdc = extension,
                        ComplementoIdc = complemento,
                        Email = data.email,
                        Celular = data.celular,
                        Base64Selfi = selfie,
                        Base64CiReverso = carnetReverso,
                        Base64CiAncerso = carnetAnverso
                    };
                    _logger.Debug($"{request.sessionID} INICIO SERVICIO FIRMA DIGITAL");
                    var response = await ApiRest.PostAsync<FirmaDigitalModel>(_authConfig.url, "FirmaDigitalOneShot/CreateClient", _request, Authentication.BasicAuth, username, password, headers);
                    _logger.Debug($"{request.sessionID} RESPONSE FIRMA DIGITAL: {JsonConvert.SerializeObject(response)}");
                    if (response.success && response.code == "200")
                        await _rekognition.UpdateDigitalSignature(request.sessionID, int.Parse(response.idClient));
                    _logger.Debug($"{request.sessionID} FIN FIRMA DIGITAL");
                    return new SaveResponse
                    {
                        state = response.success && response.code == "200",
                        sessionID = request.sessionID,
                        message = "COMPLETADO"
                    };
                }
                else
                {
                    _logger.Debug($"{request.sessionID} FIRMA DIGITAL YA GENERADA {data.id}");
                    return new SaveResponse
                    {
                        state = true,
                        sessionID = request.sessionID,
                        message = "COMPLETADO ANTERIORMENTE"
                    };
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                throw;
            }
        }

        public async Task<SaveResponse> CreateClientV2(BaseRequest request, string carnetAnverso, string carnetReverso, string selfie)
        {
            try
            {
                _logger.Debug(string.Format("REQUEST: {0}", JsonConvert.SerializeObject(request)));
                var data = await _rekognition.GetDataSessionV2(request.sessionID);
                string nroDocument = data.idc.Substring(0, 8);
                string extension = data.idc.Substring(9, 2);
                string complemento = data.idc.Substring(11, 2);
                if (data.id == 0)
                {
                    _logger.Debug($"{request.sessionID} INICIO FIRMA DIGITAL");
                    string username = _secrypt.Desencriptar(_authConfig.username);
                    string password = _secrypt.Desencriptar(_authConfig.password);
                    string token = _secrypt.Desencriptar(_authConfig.token);
                    List<Tuple<string, string>> headers = new List<Tuple<string, string>>();
                    headers.Add(new Tuple<string, string>("channel", data.canal));
                    headers.Add(new Tuple<string, string>("publicToken", token));
                    headers.Add(new Tuple<string, string>("appUserId", username.Replace("_", "") + DateTime.Now.ToString("yyyyMMdd")));
                    _logger.Debug($"FIN {request.sessionID} CONFIGURACION CABECERA Y AUTENTIFICACION => {data.canal}");
                    _logger.Debug($"CREATE REQUEST: {request.sessionID}");
                    var _request = new
                    {
                        NumIdc = nroDocument.TrimStart('0'),
                        ExtencionIdc = extension,
                        ComplementoIdc = complemento,
                        Email = data.email,
                        Celular = data.celular,
                        Base64Selfi = selfie,
                        Base64CiReverso = carnetReverso,
                        Base64CiAncerso = carnetAnverso
                    };
                    _logger.Debug($"{request.sessionID} INICIO SERVICIO FIRMA DIGITAL");
                    var response = await ApiRest.PostAsync<FirmaDigitalModel>(_authConfig.url, "FirmaDigitalOneShot/CreateClient", _request, Authentication.BasicAuth, username, password, headers);
                    _logger.Debug($"{request.sessionID} RESPONSE FIRMA DIGITAL: {JsonConvert.SerializeObject(response)}");
                    if (response.success && response.code == "200")
                        await _rekognition.UpdateDigitalSignature(request.sessionID, int.Parse(response.idClient));
                    _logger.Debug($"{request.sessionID} FIN FIRMA DIGITAL");
                    return new SaveResponse
                    {
                        state = response.success && response.code == "200",
                        sessionID = request.sessionID,
                        message = "COMPLETADO"
                    };
                }
                else
                {
                    _logger.Debug($"{request.sessionID} FIRMA DIGITAL YA GENERADA {data.id}");
                    return new SaveResponse
                    {
                        state = true,
                        sessionID = request.sessionID,
                        message = "COMPLETADO ANTERIORMENTE"
                    };
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                throw;
            }
        }
    }
}
