﻿using BCP.CROSS.LOGGER;
using BCP.CROSS.SECRYPT;
using Microsoft.Extensions.Configuration;
using Rekognition.App.Api.Commons;
using Rekognition.App.Api.Model;
using Rekognition.App.Api.Model.Config;
using Rekognition.Lambda.Model;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace Rekognition.App.Api.Services
{
    public interface IocrService
    {
        Task<DetectTextResponse> DetectText(string session, string image, string tipo);
    }
    public class ocrService : IocrService
    {
        private readonly ILogger logger;
        private readonly IManagerSecrypt secrypt;
        private readonly ocrConfig ocr;

        public ocrService(ILogger logger, IConfiguration configuration, IManagerSecrypt secrypt)
        {
            this.logger = logger;
            this.secrypt = secrypt;
            ocr = new ocrConfig();
            configuration.GetSection("ocr_service").Bind(ocr);
        }
        public async Task<DetectTextResponse> DetectText(string session, string image, string tipo)
        {
            try
            {
                string method = "ci";
                var request = new
                {
                    id_referencia = session,
                    anverso_reverso = tipo,
                    imagen_ci = image
                };
                string password = secrypt.Desencriptar(ocr.password);
                var _response = await ApiRest.PostAsync<DetectTextOCRModel>(ocr.url, method, request, Authentication.Ntlm, ocr.user, password);
                var response = new DetectTextResponse();
                response.statusCode = _response.cod_resp == "00" ? 200 : 500;
                response.body = new BodyDetectText();
                if (response.statusCode == 200)
                {
                    var split = _response.full_ocr.Replace("\n", "_").Split("_");
                    response.body.TextDetections = split.Select(x => new Textdetection
                    {
                        DetectedText = x,
                        ParentId = null
                    }).ToList();
                }
                return response;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
    }
}
