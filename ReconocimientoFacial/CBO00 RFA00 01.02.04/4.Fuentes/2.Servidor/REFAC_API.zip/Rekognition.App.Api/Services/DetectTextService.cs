﻿using BCP.CROSS.LOGGER;
using BCP.CROSS.SECRYPT;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Rekognition.App.Api.Model;
using Rekognition.App.Api.Repositories;
using Rekognition.Lambda;
using Rekognition.Lambda.Model;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Rekognition.App.Api.Services
{
    public interface IDetectTextService
    {
        Task<ProcessModel> GetTextImage(string sessionID, string image, string tipo);
    }

    public class DetectTextService : IDetectTextService
    {
        private readonly AwsConfig awsConfig;
        private readonly WebConfig webConfig;
        private readonly ILogger _logger;
        private readonly IManagerSecrypt _secrypt;
        private readonly IRekognitionRepositorie _rekognition;
        private readonly IocrService ocr;
        private readonly ICompareService compare;
        private readonly Lambda.LambdaClient _client;

        public DetectTextService(IConfiguration configuration, ILogger logger, IManagerSecrypt secrypt, IRekognitionRepositorie rekognition, IocrService ocr, ICompareService compare)
        {
            this._logger = logger;
            this._secrypt = secrypt;
            this._rekognition = rekognition;
            this.ocr = ocr;
            this.compare = compare;
            this.awsConfig = new AwsConfig();
            configuration.GetSection("aws_service").Bind(awsConfig);
            string access_key = this._secrypt.Desencriptar(this.awsConfig.access_key);
            string secret_key = this._secrypt.Desencriptar(this.awsConfig.secret_key);
            _client = new LambdaClient(new LambdaConfig
            {
                accessKey = access_key,
                secretKey = secret_key,
                functionName = this.awsConfig.functionName,
                region = this.awsConfig.region,
                percentageBW = this.awsConfig.percentageBW,
                color = this.awsConfig.Color
            });
            this.webConfig = new WebConfig();
            configuration.GetSection("web").Bind(webConfig);
        }

        public async Task<ProcessModel> GetTextImage(string sessionID, string image, string tipo)
        {
            try
            {
                bool isGrayScale = IsGrayScale(image);
                if (!isGrayScale)
                {
                    ProcessModel model = new ProcessModel();
                    List<string> detectText = new List<string>();
                    if (tipo == "ANVERSO")
                        detectText = awsConfig.DetectText.Anverso;
                    if (tipo == "REVERSO")
                        detectText = awsConfig.DetectText.Reverso;
                    DetectTextResponse response = new DetectTextResponse();
                    response.statusCode = 500;
                    _logger.Information($"SESSION: {sessionID}; TIPO: {this.awsConfig.DetectText.Version} =>  INICIAR TEXT");
                    if (webConfig.detectText == "AWS")
                    {
                        if (this.awsConfig.DetectText.Version == "1")
                            response = await _client.DetectText(image, detectText);
                        else
                            response = await _client.DetectTextV2(image, detectText);
                    }
                    else
                    {
                        response = await ocr.DetectText(sessionID, image, tipo.ToLower());
                    }
                    _logger.Information($"SESSION: {sessionID} =>  FIN TEXT");
                    if (response.statusCode == 200)
                    {
                        List<string> _lstText = response.body.TextDetections.Select(x => x.DetectedText.ToUpper()).ToList();
                        var _value = await _rekognition.GetProcess(sessionID);
                        DetectTextModel value = new();
                        value.anverso = new AnversoModel();
                        value.reverso = new ReversoModel();
                        if (_value != null && _value.Value != null)
                            value = JsonConvert.DeserializeObject<DetectTextModel>(_value.Value);
                        bool procesado = false;
                        model.Message = string.Empty;
                        var data = await _rekognition.GetDataSessionV2(sessionID);
                        string _idc = data.idc.Substring(0, 8);
                        string _complemento = data.idc.Substring(11, 2);
                        bool idc = GetIDC(_lstText, int.Parse(_idc));
                        switch (tipo)
                        {
                            case "ANVERSO":
                                value.anverso = new AnversoModel();
                                value.anverso.EsValido = true;
                                value.anverso.Mensaje = string.Empty;
                                try
                                {
                                    value.anverso.Idc = idc ? int.Parse(_idc) : 0;
                                    if (!idc)
                                    {
                                        value.anverso.EsValido = false;
                                        value.anverso.Mensaje += "EL NRO DE CARNET NO COINCIDE" + Environment.NewLine;
                                        model.Message = value.anverso.Mensaje;
                                    }
                                    DateTime fechaExpiracion = DateTime.MinValue;
                                    bool fecha = GetFechaExpira(_lstText, ref fechaExpiracion);
                                    value.anverso.FechaExpiracion = fechaExpiracion;
                                    //if (fecha)
                                    //{
                                    //    int dias = Convert.ToInt32(fechaExpiracion.Subtract(DateTime.Now).TotalDays);
                                    //    if (dias < 0)
                                    //    {
                                    //        value.anverso.EsValido = false;
                                    //        value.anverso.Mensaje += "LA FECHA DE CARNET YA ESTA EXPIRADA" + Environment.NewLine;
                                    //        model.Message = value.anverso.Mensaje;
                                    //    }
                                    //}
                                    //else
                                    //{
                                    //    value.anverso.EsValido = false;
                                    //    value.anverso.Mensaje += "NO SE PUDO VALIDAR EL FORMATO DE FECHA DE EXPIRACIÓN" + Environment.NewLine;
                                    //    model.Message = value.anverso.Mensaje;
                                    //}
                                    if (string.IsNullOrEmpty(value.anverso.Mensaje))
                                        value.anverso.Mensaje = "COMPLETADO";
                                    else
                                    {
                                        _logger.Debug($"{sessionID} => {string.Join(" | ", _lstText)}");
                                        model.Message = value.anverso.Mensaje;
                                    }
                                    procesado = value.anverso.EsValido;
                                }
                                catch (Exception ex)
                                {
                                    value.anverso.EsValido = false;
                                    value.anverso.Mensaje = ex.Message.ToUpper();
                                    _logger.Error(ex);
                                }
                                break;
                            case "REVERSO":
                                var segip = await compare.GetDataSegip(_idc, _complemento);
                                value.reverso = new ReversoModel();
                                value.reverso.Mensaje = string.Empty;
                                value.reverso.EsValido = true;
                                try
                                {
                                    if (segip.success && segip.data.EsValido)
                                    {
                                        value.reverso.Idc = int.Parse(_idc);
                                        string nombres = string.Empty;
                                        string nombreCompleto = $"{segip.data.nombre} {segip.data.paterno} {segip.data.materno}";
                                        bool ValidaNombres = GetNombres(_lstText, nombreCompleto, ref nombres);
                                        if (!ValidaNombres)
                                        {
                                            value.reverso.EsValido = false;
                                            value.reverso.Mensaje += "NO SE PUDO VALIDAR EL NOMBRE" + Environment.NewLine;
                                        }
                                        else
                                        {
                                            value.reverso.Nombres = nombreCompleto;
                                            if (!LambdaClient.SimpleRatio(nombreCompleto, nombres))
                                            {
                                                value.reverso.Nombres = nombres;
                                                value.reverso.EsValido = false;
                                                value.reverso.Mensaje += "EL NOMBRE NO COINCIDE CON SEGIP" + Environment.NewLine;
                                            }
                                        }
                                        DateTime fechaNacimiento = DateTime.ParseExact(segip.data.fechaNacimiento, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                                        value.reverso.FechaNacimiento = fechaNacimiento;
                                        int year = GetEdad(fechaNacimiento);
                                        if (!data.esMenor)
                                        {
                                            value.reverso.EsMenor = false;
                                            value.reverso.NombresTutor = string.Empty;
                                            if (year < 18)
                                            {
                                                value.reverso.EsValido = false;
                                                value.reverso.Mensaje += "TODAVIA NO CUMPLES LA EDAD PERMITIDA" + Environment.NewLine;
                                            }
                                        }
                                        else
                                        {
                                            compare.GuardarSegip(sessionID, segip);
                                            value.reverso.EsMenor = true;
                                            string _idcTutor = data.idcTutor.Substring(0, 8);
                                            string _complementoTutor = data.idcTutor.Substring(11, 2);
                                            if (year >= 18)
                                            {
                                                value.reverso.EsValido = false;
                                                value.reverso.Mensaje += "TU EDAD NO CUMPLE PARA CUENTA MENOR" + Environment.NewLine;
                                            }
                                            var segipTutor = await compare.GetDataSegip(_idcTutor, _complementoTutor);
                                            if (segipTutor.success && segipTutor.data.EsValido)
                                            {
                                                compare.GuardarSegip(sessionID, segipTutor, "TUTOR");
                                                string nombreCompletoTutor = $"{segipTutor.data.nombre} {segipTutor.data.paterno} {segipTutor.data.materno}";
                                                value.reverso.NombresTutor = nombreCompletoTutor;
                                            }
                                            else
                                            {
                                                value.reverso.EsValido = false;
                                                value.reverso.Mensaje += "CARNET DEL TUTOR NO ENCONTRADO EN SEGIP" + Environment.NewLine;
                                            }
                                            //bool idcTutor = GetIDC(_lstText, int.Parse(_idcTutor));
                                            //value.reverso.IdcTutor = idcTutor ? int.Parse(_idcTutor) : 0;
                                            //if (!idcTutor)
                                            //{
                                            //    value.reverso.EsValido = false;
                                            //    value.reverso.Mensaje += "EL NRO DE CARNET NO COINCIDE" + Environment.NewLine;
                                            //}
                                            //var segipTutor = await compare.GetDataSegip(_idcTutor, _complementoTutor);
                                            //if (segipTutor.success && segipTutor.data.EsValido)
                                            //{
                                            //    compare.GuardarSegip(sessionID, segipTutor, "TUTOR");
                                            //    string nombreCompletoTutor = $"{segipTutor.data.nombre} {segipTutor.data.paterno} {segipTutor.data.materno}";
                                            //    bool ValidaNombresTutor = GetNombres(_lstText, nombreCompletoTutor, ref nombres);
                                            //    value.reverso.NombresTutor = nombreCompletoTutor;
                                            //    if (!LambdaClient.SimpleRatio(nombreCompletoTutor, nombres))
                                            //    {
                                            //        value.reverso.NombresTutor = nombres;
                                            //        value.reverso.EsValido = false;
                                            //        value.reverso.Mensaje += "EL NOMBRE DEL TUTOR NO COINCIDE CON SEGIP" + Environment.NewLine;
                                            //    }
                                            //}
                                            //else
                                            //{
                                            //    value.reverso.EsValido = false;
                                            //    value.reverso.Mensaje += "CARNET DEL TUTOR NO ENCONTRADO EN SEGIP" + Environment.NewLine;
                                            //}
                                        }
                                    }
                                    else
                                    {
                                        value.reverso.EsValido = false;
                                        value.reverso.Mensaje += "CARNET NO ENCONTRADO EN SEGIP" + Environment.NewLine;
                                    }
                                    if (string.IsNullOrEmpty(value.reverso.Mensaje))
                                        value.reverso.Mensaje = "COMPLETADO";
                                    else
                                    {
                                        _logger.Debug($"{sessionID} => {string.Join(" | ", _lstText)}");
                                        model.Message = value.reverso.Mensaje;
                                    }
                                    procesado = value.reverso.EsValido;
                                }
                                catch (Exception ex)
                                {
                                    value.reverso.EsValido = false;
                                    value.reverso.Mensaje = ex.Message.ToUpper();
                                    _logger.Error(ex);
                                }
                                break;
                            default:
                                break;
                        }
                        model.State = value.anverso.EsValido && value.reverso.EsValido;
                        model.Value = JsonConvert.SerializeObject(value);
                        _logger.Debug($"SESSION: {sessionID} => RESPONSE: {JsonConvert.SerializeObject(model)}");
                        await _rekognition.AddProcess(sessionID, model);
                    }
                    else
                    {
                        string concat = string.Empty;
                        if (response.body != null && response.body.TextDetections != null)
                            concat = String.Join("", response.body.TextDetections.ToList().Select(x => x.DetectedText).ToList()).Replace(" ", "").ToUpper();
                        model.State = false;
                        model.Message = "LA IMAGEN CARGADA NO PASO LA VALIDACION";
                        _logger.Debug($"SESSION: {sessionID} => FORMATO NO VALIDO RESPONSE: {concat}");
                    }
                    return model;
                }
                else
                {
                    return new ProcessModel
                    {
                        State = false,
                        Message = "LA IMAGEN CARGADA AL PARECER ES UNA FOTOCOPIA"
                    };
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                throw;
            }
        }

        private bool Contains(string text, string[] array)
        {
            foreach (var item in array)
            {
                if (text.Contains(item))
                    return true;
            }
            return false;
        }

        private bool GetFechaExpira(List<string> lstDetect, ref DateTime fecha)
        {
            bool validation = false;
            fecha = DateTime.MinValue;
            string data = string.Empty;
            try
            {
                string[] _expira = { "VALIDA", "VÁLIDA", "EMITIDA", "EXPIRA", "INDEFINIDO" };
                List<string> datos = lstDetect.Where(x => Contains(x, _expira)).ToList();
                string texto = string.Empty;
                if (datos.Contains("INDEFINIDO"))
                {
                    fecha = DateTime.MaxValue;
                    validation = true;
                }
                else
                {
                    texto = datos.FirstOrDefault().ToUpper();
                    List<string> values = GetSearchMonth(string.Join("", lstDetect));
                    string[] _replace_1 = { " DE " };

                    string dia = string.Empty;
                    int mes = 0;
                    int anio = 0;

                    foreach (var item in values)
                    {
                        string[] _split = item.Split(_replace_1, StringSplitOptions.RemoveEmptyEntries);
                        if (_split.Length >= 1 && string.IsNullOrEmpty(dia))
                            dia = GetDia(_split[0]);
                        if (_split.Length >= 2 && mes == 0)
                            mes = GetMes(_split[1]);
                        if (_split.Length >= 3 && anio == 0)
                            anio = int.Parse(_split[2].Trim().Substring(0, 4));
                    }
                    if (anio <= DateTime.Now.Year)
                        anio += 10;
                    fecha = new DateTime(anio, mes, int.Parse(dia));
                    validation = true;
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
            }
            return validation;
        }

        private bool GetIDC(List<string> lstDetect, int idc)
        {
            try
            {
                string join = string.Join("|", lstDetect);
                return join.Contains(idc.ToString());
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                throw new Exception($"IDC: {ex.Message.ToUpper()}");
            }
        }

        private bool GetNombres(List<string> lstDetect, string nombreCompleto, ref string nombres)
        {
            try
            {
                var letters = nombreCompleto.Split(" ").ToList();

                var lettersOCR = string.Join(' ', lstDetect);
                var splitLettersOCR = lettersOCR.Split(" ");
                foreach (var item in splitLettersOCR)
                {
                    foreach (var _letters in letters)
                    {
                        bool detect = LambdaClient.SimpleRatio(_letters.Replace("Ñ", "N"), item.Replace("Ñ", "N"));
                        if (detect)
                        {
                            letters.Remove(_letters);
                            if (letters.Count() == 0)
                            {
                                nombres = nombreCompleto;
                                return true;
                            }
                            break;
                        }
                    }
                }


                nombres = string.Empty;
                string[] _search = { "A", "A:" };
                var search = lstDetect.Where(x => x.StartsWith("A:") || x.StartsWith("A")).ToList();
                List<string> values = new List<string>();
                foreach (var item in search)
                {
                    bool _searchs = false;
                    foreach (var text in lstDetect)
                    {
                        if (text == item && !_searchs)
                        {
                            _searchs = true;
                            continue;
                        }
                        if (_searchs)
                        {
                            if (!values.Exists(x => x == text))
                            {
                                values.Add(text);
                                _searchs = false;
                            }
                        }
                    }
                }
                foreach (var item in values)
                {
                    if (!item.All(char.IsDigit))
                    {
                        nombres = item;
                        break;
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                return false;
            }
        }

        private int GetEdad(DateTime fechaNacimiento)
        {
            try
            {
                DateTime now = DateTime.Today;
                int edad = DateTime.Today.Year - fechaNacimiento.Year;
                if (DateTime.Today < fechaNacimiento.AddYears(edad))
                    --edad;
                return edad;
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                throw new Exception($"EDAD: {ex.Message.ToUpper()}");
            }
        }

        private string GetDia(string texto)
        {
            for (int i = 0; i < texto.Length; i++)
            {
                if (char.IsDigit((texto)[i]))
                {
                    texto = texto.Substring(i);
                    break;
                }
            }
            int value = 1;
            return int.TryParse(texto, out value) ? value.ToString() : "1";
        }

        private int GetMes(string texto)
        {
            int _mes = 0;
            string[] keys = new string[] { "ENERO", "FEBRERO", "MARZO", "ABRIL", "MAYO", "JUNIO", "JULIO", "AGOSTO", "SEPTIEMBRE", "OCTUBRE", "NOVIEMBRE", "DICIEMBRE" };
            string sKeyResult = keys.FirstOrDefault<string>(s => texto.Contains(s));
            if (string.IsNullOrEmpty(sKeyResult))
                sKeyResult = this._client.ComparePartialRatio(keys.ToList(), texto);
            switch (sKeyResult)
            {
                case "ENERO":
                    _mes = 1;
                    break;
                case "FEBRERO":
                    _mes = 2;
                    break;
                case "MARZO":
                    _mes = 3;
                    break;
                case "ABRIL":
                    _mes = 4;
                    break;
                case "MAYO":
                    _mes = 5;
                    break;
                case "JUNIO":
                    _mes = 6;
                    break;
                case "JULIO":
                    _mes = 7;
                    break;
                case "AGOSTO":
                    _mes = 8;
                    break;
                case "SEPTIEMBRE":
                    _mes = 9;
                    break;
                case "OCTUBRE":
                    _mes = 10;
                    break;
                case "NOVIEMBRE":
                    _mes = 11;
                    break;
                case "DICIEMBRE":
                    _mes = 12;
                    break;
                default:
                    break;
            }
            return _mes;
        }

        private List<string> GetSearchMonth(string texto)
        {
            try
            {
                List<string> lstDatos = new List<string>();
                string[] keys = new string[] { "ENERO", "FEBRERO", "MARZO", "ABRIL", "MAYO", "JUNIO", "JULIO", "AGOSTO", "SEPTIEMBRE", "OCTUBRE", "NOVIEMBRE", "DICIEMBRE" };
                Tuple<int, string> first = null;
                Tuple<int, string> second = null;
                foreach (var item in keys)
                {
                    int i = texto.IndexOf(item);
                    if (i != -1)
                    {
                        first = new Tuple<int, string>(i, item);
                        string temp = texto.Substring(i + item.Length);
                        i = temp.IndexOf(item);
                        if (i != -1)
                        {
                            second = new Tuple<int, string>(i + first.Item1 + item.Length, item);
                        }
                        break;
                    }
                }
                if (first != null)
                {
                    lstDatos.Add(texto.Substring(first.Item1 - 10, first.Item2.Length + 20));
                }
                if (second != null)
                {
                    lstDatos.Add(texto.Substring(second.Item1 - 10));
                }
                return lstDatos;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public bool IsGrayScale(string base64Source)
        {
            List<int> colores = new List<int>();
            try
            {
                int threshold = awsConfig.threshold;
                Bitmap bmp = null;
                try
                {
                    byte[] byteBuffer = Convert.FromBase64String(base64Source.Replace("data:image/png;base64,", ""));
                    MemoryStream memoryStream = new MemoryStream(byteBuffer);
                    memoryStream.Position = 0;
                    bmp = (Bitmap)Bitmap.FromStream(memoryStream);
                    memoryStream.Close();
                    memoryStream = null;
                    byteBuffer = null;
                }
                catch (Exception ex)
                {
                    _logger.Error(ex);
                }
                Color pixelColor = Color.Empty;
                int rgbDelta;
                for (int x = 0; x < bmp.Width; x++)
                {
                    for (int y = 0; y < bmp.Height; y++)
                    {
                        pixelColor = bmp.GetPixel(x, y);
                        rgbDelta = Math.Abs(pixelColor.R - pixelColor.G) + Math.Abs(pixelColor.G - pixelColor.B) + Math.Abs(pixelColor.B - pixelColor.R);
                        if (!colores.Exists(x => x == rgbDelta))
                            colores.Add(rgbDelta);
                        if (rgbDelta > threshold)
                            return false;
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
            }
            return true;
        }
    }
}
