﻿using BCP.CROSS.COMMON;
using BCP.CROSS.LOGGER;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Rekognition.App.Api.Commons;
using Rekognition.App.Api.DTOs;
using Rekognition.App.Api.Model;
using Rekognition.App.Api.Model.Config;
using Rekognition.App.Api.Model.Response;
using Rekognition.App.Api.Repositories;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace Rekognition.App.Api.Services
{
    public interface IPasivaService
    {
        Task<InstruccionPasivaResponse> GetInstruccion(string sessionID);
        Task<BasePasivaResponse> GetValidacion(string sessionID, string selfi);
    }

    public class PasivaService : IPasivaService
    {
        private readonly ILogger _logger;
        private readonly IRekognitionRepositorie _rekognition;
        private readonly IFiles _files;
        private readonly PasivaConfig pasivaConfig;

        public PasivaService(ILogger logger, IConfiguration configuration, IRekognitionRepositorie rekognition, IFiles files)
        {
            this._logger = logger;
            this._rekognition = rekognition;
            this._files = files;
            this.pasivaConfig = new PasivaConfig();
            configuration.GetSection("pasiva_api").Bind(this.pasivaConfig);
        }
        public async Task<InstruccionPasivaResponse> GetInstruccion(string sessionID)
        {
            string method = "Instrucciones/SolicitudInstrucciones";
            InstruccionPasivaResponse response = null;
            try
            {
                var data = await _rekognition.GetDataSessionV2(sessionID);
                if (data.id == 0)
                {
                    string nroDocument = data.idc.Substring(0, 8);
                    string extension = data.idc.Substring(9, 2);
                    string complemento = data.idc.Substring(11, 2);

                    string canal = "AFILIACION_SOLI";
                    string passCanal = "AFILIACION_SOLI";
                    string celular = data.celular;
                    string idc = $"{int.Parse(nroDocument)}{extension}-{complemento}";
                    var request = new
                    {
                        canal = canal,
                        passcanal = passCanal,
                        celular = celular,
                        ci = idc
                    };
                    response = await ApiRest.PostAsync<InstruccionPasivaResponse>(this.pasivaConfig.url, method, request, Authentication.None);
                }
                else
                {
                    response = new InstruccionPasivaResponse
                    {
                        code = "400",
                        success = false,
                        message = "Sesión invalida",
                        imgInstruccion = string.Empty,
                        selfi = string.Empty
                    };
                }
                return response;
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                throw;
            }
        }
        public async Task<BasePasivaResponse> GetValidacion(string sessionID, string selfi)
        {
            string method = "Instrucciones/AnalisisRecFacialCliente";
            BasePasivaResponse response = null;
            try
            {
                _logger.Debug($"SESSION_ID: {sessionID}");
                if (string.IsNullOrEmpty(selfi))
                    _logger.Error(new Exception("NO SE CARGO SELFI"));
                var data = await _rekognition.GetDataSessionV2(sessionID);
                if (data.id == 0)
                {
                    string nroDocument = data.idc.Substring(0, 8);
                    string extension = data.idc.Substring(9, 2);
                    string complemento = data.idc.Substring(11, 2);

                    string canal = "AFILIACION_SOLI";
                    string passCanal = "AFILIACION_SOLI";
                    string celular = data.celular;
                    string idc = $"{int.Parse(nroDocument)}{extension}-{complemento}";

                    var request = new
                    {
                        canal = canal,
                        passcanal = passCanal,
                        celular = celular,
                        ci = idc,
                        selfi = selfi
                    };
                    response = await ApiRest.PostAsync<BasePasivaResponse>(this.pasivaConfig.url, method, request, Authentication.None);
                    _logger.Debug($"RESPONSE PASIVA: {JsonConvert.SerializeObject(response)}");
                    BodyInstructionGatewayRequest body = null;
                    if (response.success)
                    {
                        body = new BodyInstructionGatewayRequest
                        {
                            message = response.message.ToUpper(),
                            image = selfi,
                            state = response.success,
                            phase = "SuccessState"
                        };
                    }
                    else
                    {
                        body = new BodyInstructionGatewayRequest
                        {
                            message = response.message.ToUpper(),
                            image = selfi,
                            state = response.success,
                            phase = "InstructionState"
                        };
                    }
                    var thread = new Thread(() => ThreadIntruction(new InstructionGatewayRequest
                    {
                        sessionID = sessionID,
                        body = body
                    }));
                    thread.Start();
                }
                else
                {
                    response = new InstruccionPasivaResponse
                    {
                        code = "400",
                        success = false,
                        message = "Sesión invalida",
                        imgInstruccion = string.Empty,
                        selfi = string.Empty
                    };
                }
                return response;
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                throw;
            }
        }
        private void ThreadIntruction(object _request)
        {
            lock (_request)
            {
                try
                {
                    InstructionGatewayRequest request = (InstructionGatewayRequest)_request;
                    string fileName = DateTime.Now.ToString("ddMMyyyyHHmmssfff") + ".png";
                    string file = request.body.image;
                    Lambda.Model.InformationModel information = null;
                    if (request.body.state)
                    {
                        _files.SaveImage(request.sessionID, file, "SELFIE.png");
                    }
                    _files.SaveImage(request.sessionID, file, fileName);
                    _rekognition.AddChallenge(new VerifyResponse
                    {
                        sessionID = request.sessionID,
                        body = new VerifyBodyResponse
                        {
                            state = request.body.state,
                            message = request.body.message,
                            phase = request.body.phase,
                            fileName = fileName
                        }
                    }, information);
                }
                catch (Exception ex)
                {
                    _logger.Error(ex);
                }
            }
        }
    }
}
