﻿using BCP.CROSS.COMMON;
using BCP.CROSS.LOGGER;
using BCP.CROSS.SECRYPT;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Rekognition.App.Api.DTOs;
using Rekognition.App.Api.Model;
using Rekognition.App.Api.Model.Response;
using Rekognition.App.Api.Repositories;
using Rekognition.Facial;
using Rekognition.Facial.Common;
using Rekognition.Lambda;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace Rekognition.App.Api.Services
{
    public interface IRekognitionService
    {
        SessionResponse GetSessionID();
        Task<int> GetChannelCredentials(string accessKey, string secretKey);
        Task<StartResponse> Start(StartRequest request, int idChannel);
        Task<VerifyResponse> Verify(VerifyRequest request, int channelID);
        Task<UrlSessionResponse> CreateSession(CreateSessionRequest request, int idChannel);
        Task<DataSessionResponse> GetDataSession(BaseRequest request);
        Task<StateSessionResponse> StateSession(BaseRequest request);
        Task<SaveResponse> TimeOutState(BaseRequest request);
        Task<SaveResponse> LoadImage(LoadCardImageRequest request);
        Task<List<ParameterModel>> ParametersChannel(ParametersChannelRequest request);
        Task<ValidacionResponse> Validator(BaseRequest request);
        Task<GenericResponse<string>> RegisterSession(StartGatewayRequest request, int idChannel);
        Task<GenericResponse<int>> Credentials(CredentialGatewayRequest request);
        GenericResponse<string> Instruction(InstructionGatewayRequest request);
    }
    public class RekognitionService : IRekognitionService
    {
        private static readonly string sectionNameAws = "aws_service";
        private static readonly string sectionNameWeb = "web";
        private readonly AwsConfig awsConfig;
        private readonly WebConfig webConfig;
        private readonly ILogger _logger;
        private readonly IManagerSecrypt _secrypt;
        private readonly IFiles _files;
        private readonly IRekognitionRepositorie _repositorie;
        private readonly ICompareService _compare;
        private readonly IDetectTextService _detectText;
        private readonly LambdaClient _client;
        private readonly IVerificationService verification;

        public RekognitionService(IConfiguration configuration,
            ILogger logger,
            IManagerSecrypt secrypt,
            IFiles files,
            IRekognitionRepositorie repositorie,
            ICompareService compare,
            IDetectTextService detectText,
            IVerificationService verification)
        {
            this._logger = logger;
            this._secrypt = secrypt;
            this._files = files;
            this._repositorie = repositorie;
            this._compare = compare;
            this._detectText = detectText;
            this.verification = verification;
            this.webConfig = new WebConfig();
            configuration.GetSection(sectionNameWeb).Bind(webConfig);
            this.awsConfig = new AwsConfig();
            configuration.GetSection(sectionNameAws).Bind(awsConfig);
            string access_key = this._secrypt.Desencriptar(this.awsConfig.access_key);
            string secret_key = this._secrypt.Desencriptar(this.awsConfig.secret_key);
            this._client = new LambdaClient(new Lambda.Model.LambdaConfig
            {
                accessKey = access_key,
                secretKey = secret_key,
                functionName = this.awsConfig.functionName,
                region = this.awsConfig.region,
                percentageBW = this.awsConfig.percentageBW,
                color = this.awsConfig.Color,
                nose = new Lambda.Model.NoseConfig
                {
                    maxHDist = this.awsConfig.nose.maxHDist,
                    maxVDist = this.awsConfig.nose.maxVDist,
                    minHDist = this.awsConfig.nose.minHDist
                }
            }); ;
        }
        public SessionResponse GetSessionID()
        {
            return new SessionResponse
            {
                sessionID = Guid.NewGuid().ToString()
            };
        }
        public async Task<int> GetChannelCredentials(string accessKey, string secretKey)
        {
            try
            {
                return await _repositorie.GetChannelCredentials(accessKey, secretKey);
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                throw;
            }
        }
        public async Task<StartResponse> Start(StartRequest request, int idChannel)
        {
            try
            {
                _logger.Debug(string.Format("REQUEST: {0}", JsonConvert.SerializeObject(request)));
                bool valida = !(await _repositorie.ExistSession(request.sessionID));
                if (request.multiFactor)
                    valida = true;
                if (valida)
                {
                    CountRetryModel countRetry = await _repositorie.GetCountRetry(request.idc);
                    if (countRetry.count >= this.awsConfig.attempts)
                    {
                        if (!countRetry.blocking)
                        {
                            await _repositorie.AddBlocking(request.idc, idChannel);
                        }
                        throw new Exception("EL CLIENTE HA SIDO BLOQUEADO POR VARIOS REINTENTOS.");
                    }
                    else
                    {
                        if (request.multiFactor)
                        {
                            var session = await _repositorie.GetDataSessionV2(request.sessionID);
                            idChannel = session.idCanal;
                        }
                        _logger.Debug(string.Format("ID CHANNEL: {0}", idChannel));
                        await _repositorie.AddSession(idChannel, request.sessionID, request.idc, string.Empty, 0, string.Empty);

                        List<ParameterModel> instruction = await _repositorie.GetParameter(idChannel, "INSTRUCTION");
                        var _instruction = instruction.FirstOrDefault(x => x.name == "INSTRUCTION").value == "TRUE";

                        var _rspService = this._client.StartOnPremise(request.sessionID, request.width, request.height);
                        StartResponse response = new();
                        response.sessionID = request.sessionID;
                        if (_rspService.statusCode == 200)
                        {
                            response.body = new StartBodyResponse
                            {
                                areaHeight = _rspService.body.areaHeight,
                                areaLeft = _rspService.body.areaLeft,
                                areaTop = _rspService.body.areaTop,
                                areaWidth = _rspService.body.areaWidth,
                                minFaceAreaPercent = _rspService.body.minFaceAreaPercent,
                                noseHeight = _instruction ? _rspService.body.noseHeight : 0,
                                noseLeft = _instruction ? _rspService.body.noseLeft : 0,
                                noseTop = _instruction ? _rspService.body.noseTop : 0,
                                noseWidth = _instruction ? _rspService.body.noseWidth : 0,
                                imageHeight = _rspService.body.imageHeight,
                                imageWidth = _rspService.body.imageWidth
                            };
                            await _repositorie.UpdateSession(response.sessionID,
                                response.body.areaHeight,
                                response.body.areaLeft,
                                response.body.areaTop,
                                response.body.areaWidth,
                                response.body.imageHeight,
                                response.body.imageWidth,
                                response.body.minFaceAreaPercent,
                                response.body.noseHeight,
                                response.body.noseLeft,
                                response.body.noseTop,
                                response.body.noseWidth,
                                idChannel);
                            _logger.Debug(string.Format("RESPONSE: {0}", JsonConvert.SerializeObject(response)));
                        }
                        else
                        {
                            throw new Exception("INFORMACION INVALIDA");
                        }
                        return response;
                    }
                }
                else
                {
                    throw new Exception($"LA SESSION ID EXISTE {0}");
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                throw;
            }
        }
        public async Task<VerifyResponse> Verify(VerifyRequest request, int channelID)
        {
            try
            {
                Lambda.Model.StartModel model = new()
                {
                    areaHeight = request.areaHeight,
                    areaLeft = request.areaLeft,
                    areaTop = request.areaTop,
                    areaWidth = request.areaWidth,
                    imageHeight = request.imageHeight,
                    imageWidth = request.imageWidth,
                    minFaceAreaPercent = request.minFaceAreaPercent,
                    noseHeight = request.noseHeight,
                    noseLeft = request.noseLeft,
                    noseTop = request.noseTop,
                    noseWidth = request.noseWidth,
                    userId = request.sessionID
                };
                _logger.Debug(string.Format("REQUEST: {0} AREA: {1}", JsonConvert.SerializeObject(model), request.cumpleArea));
                _logger.Debug($"{request.sessionID} VALIDA SESION");
                if (await _repositorie.ExistSession(request.sessionID))
                {
                    var data = await _repositorie.GetDataSessionV2(request.sessionID);
                    _logger.Debug($"{request.sessionID} BUSCAR ESTADO COMPLETADO");
                    VerifyResponse validation = await _repositorie.GetChallengeSuccess(request.sessionID);
                    string[] state = { "SuccessState", "VerificationFailState", "TimeOutState" };
                    if (state.Contains(validation.body.phase))
                    {
                        return new VerifyResponse
                        {
                            sessionID = request.sessionID,
                            body = new VerifyBodyResponse
                            {
                                fileName = string.IsNullOrEmpty(validation.body.fileName) ? string.Empty : validation.body.fileName,
                                message = validation.body.message,
                                phase = validation.body.phase,
                                state = validation.body.state
                            }
                        };
                    }
                    if (string.IsNullOrEmpty(request.cumpleArea))
                    {
                        if (validation.body.phase == "InstructionState")
                        {
                            _logger.Debug($"{request.sessionID} INSTRUCCION COMPLETADA");
                            var comparar = await _repositorie.GetProcessComparison(request.sessionID);
                            if (comparar.Count() == 0)
                            {
                                Thread _selfie = new(new ParameterizedThreadStart(ThreadCopy));
                                _selfie.Start(new CopyModel { SessionID = request.sessionID, FileName = validation.body.fileName });

                                VerifyResponse response = new();
                                response.sessionID = request.sessionID;
                                response.body = new VerifyBodyResponse();
                                response.body.phase = validation.body.phase;
                                response.body.message = validation.body.message;
                                List<ParameterModel> flow = await _repositorie.GetParameter(channelID, "FLOW_COMPARE");
                                _logger.Debug($"{request.sessionID} OBTENER IMAGEN COMPLETADA INSTRUCCION INICIO");
                                string selfie = _files.OpenFile(request.sessionID, validation.body.fileName);
                                _logger.Debug($"{request.sessionID} OBTENER IMAGEN COMPLETADA INSTRUCCION FIN");
                                ParameterCompare parameter = new(request.sessionID, selfie);
                                bool segip = flow.FirstOrDefault(x => x.name == "SEGIP").value == "TRUE";
                                if (segip)
                                {
                                    await _repositorie.AddProcessComparison(new ProcessComparisonModel
                                    {
                                        message = "PENDIENTE",
                                        status = false,
                                        sessionID = request.sessionID,
                                        type = "SEGIP",
                                        percentage = 0
                                    });
                                }
                                bool carnet = flow.FirstOrDefault(x => x.name == "CARNET").value == "TRUE";
                                if (carnet)
                                {
                                    await _repositorie.AddProcessComparison(new ProcessComparisonModel
                                    {
                                        message = "PENDIENTE",
                                        status = false,
                                        sessionID = request.sessionID,
                                        type = "CARNET",
                                        percentage = 0
                                    });
                                }
                                var _compareSegip = CompareSegip(parameter, segip);
                                var _compareCarnetIdentidad = CompareCarnetIdentidad(parameter, carnet);
                                var compareSegip = await _compareSegip;
                                var compareCarnetIdentidad = await _compareCarnetIdentidad;
                                _logger.Debug($"{request.sessionID} FINALIZO COMPARACION");
                                if (compareSegip && compareCarnetIdentidad.state)
                                {
                                    response.body.phase = "SuccessState";
                                    response.body.state = true;
                                    response.body.message = FirstLetterString(ConstantMessage.VERIFICATION_MESSAGE_1);
                                }
                                else
                                {
                                    response.body.phase = "VerificationFailState";
                                    response.body.state = false;
                                    response.body.message = "ASEGÚRATE DE CUMPLIR CON LAS INTRUCCIONES, POR FAVOR INTENTA DE NUEVO";
                                }
                                await _repositorie.AddChallenge(response, null);
                                return response;
                            }
                            else
                            {
                                return new VerifyResponse
                                {
                                    sessionID = request.sessionID,
                                    body = new VerifyBodyResponse
                                    {
                                        fileName = validation.body.fileName,
                                        message = FirstLetterString(validation.body.message),
                                        phase = validation.body.phase,
                                        state = validation.body.state
                                    }
                                };
                            }
                        }
                        _logger.Debug($"{request.sessionID} INICIA VERIFICACION");
                        List<ParameterModel> lstInstruction = await _repositorie.GetParameter(data.idCanal, "INSTRUCTION");
                        ParameterVerify verify = new(
                            model,
                            request.image64,
                            channelID,
                            instruction: lstInstruction.FirstOrDefault(x => x.name == "INSTRUCTION").value == "TRUE",
                            labels: lstInstruction.FirstOrDefault(x => x.name == "LABELS").value == "TRUE",
                            ppe: lstInstruction.FirstOrDefault(x => x.name == "PPE").value == "TRUE",
                            movimiento: decimal.Parse(lstInstruction.FirstOrDefault(x => x.name == "MOVIMIENTO").value));
                        validation = await Verify(verify);
                        _logger.Debug($"{request.sessionID} FIN VERIFICACION");
                        return new VerifyResponse
                        {
                            sessionID = request.sessionID,
                            body = new VerifyBodyResponse
                            {
                                fileName = string.IsNullOrEmpty(validation.body.fileName) ? string.Empty : validation.body.fileName,
                                message = validation.body.message,
                                phase = validation.body.phase,
                                state = validation.body.state
                            }
                        };
                    }
                    else
                    {
                        string fileName = DateTime.Now.ToString("ddMMyyyyHHmmssfff") + ".png";
                        ParameterImage parameterimage = new(request.sessionID, fileName, request.image64);
                        var image = SaveImage(parameterimage);
                        var response = new VerifyResponse
                        {
                            sessionID = request.sessionID,
                            body = new VerifyBodyResponse
                            {
                                fileName = fileName,
                                message = FirstLetterString(ConstantMessage.AREA_MESSAGE_1),
                                phase = "AreaState",
                                state = false
                            }
                        };
                        await _repositorie.AddChallenge(response, null);
                        return response;
                    }
                }
                else
                {
                    throw new Exception("SESION NO VALIDA");
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                throw;
            }
        }
        private string FirstLetterString(string cadena)
        {
            try
            {
                if (!string.IsNullOrEmpty(cadena))
                {
                    cadena = cadena.Replace("{{COLOR}}", awsConfig.Color);
                    string temp = cadena.ToLower();
                    return cadena.First().ToString().ToUpper() + temp.Substring(1);
                }
                return string.Empty;
            }
            catch (Exception ex)
            {
                return cadena;
            }
        }
        private void ThreadImage(object parameter)
        {
            ParameterImage _parameter = (ParameterImage)parameter;
            try
            {
                _files.SaveImage(_parameter.sessionID, _parameter.image, _parameter.fileName);
            }
            catch (Exception ex)
            {
                _logger.Debug($"{_parameter.sessionID}: {ex.Message}: JSON => {JsonConvert.SerializeObject(_parameter)}");
            }
            _logger.Debug($"{_parameter.sessionID} FIN HILO SAVE IMAGE");
        }
        private void ThreadCopy(object parameter)
        {
            CopyModel _parameter = (CopyModel)parameter;
            try
            {
                _logger.Debug($"{_parameter.SessionID} GUARDANDO SELFIE");
                _files.CopyFile($"{_parameter.SessionID}", _parameter.FileName, "SELFIE.png");
            }
            catch (Exception ex)
            {
                _logger.Debug($"{_parameter.SessionID}: {ex.Message}");
            }
            _logger.Debug($"{_parameter.SessionID} FIN HILO VERIFICACION");
        }
        private async Task<VerifyResponse> Verify(ParameterVerify _parameter)
        {
            string base64Guid = Convert.ToBase64String(Guid.NewGuid().ToByteArray());
            var uid = Regex.Replace(base64Guid, "[/+=]", "");
            _logger.Debug($"{_parameter.start.userId}|ID: {uid}|INICIO VERIFICACION");
            string fileName = DateTime.Now.ToString("ddMMyyyyHHmmssfff") + ".png";
            ParameterImage parameterimage = new(_parameter.start.userId, fileName, _parameter.image);
            VerifyResponse response = new();
            try
            {
                if (_parameter.movimiento == 0)
                {
                    _parameter.start.noseTop = 0;
                    _parameter.start.noseHeight = 0;
                    _parameter.start.noseLeft = 0;
                    _parameter.start.noseWidth = 0;
                }
                var data = await this.verification.ValidationAsync(new Facial.Model.FacialRequest
                {
                    Area = new Facial.Model.Rectangle
                    {
                        Height = _parameter.start.areaHeight,
                        Left = _parameter.start.areaLeft,
                        Top = _parameter.start.areaTop,
                        Width = _parameter.start.areaWidth
                    },
                    IdTrace = uid,
                    Image = Convert.FromBase64String(_parameter.image),
                    Instruction = _parameter.instruction,
                    minFaceAreaPercentTolerance = _parameter.start.minFaceAreaPercent,
                    Nose = new Facial.Model.Rectangle
                    {
                        Height = _parameter.start.noseHeight,
                        Left = _parameter.start.noseLeft,
                        Top = _parameter.start.noseTop,
                        Width = _parameter.start.noseWidth,
                    }
                });
                response.sessionID = _parameter.start.userId;
                response.body = new();
                response.body.phase = data.Phase;
                data.Message.Remove("");
                response.body.message = FirstLetterString(string.Join(",", data.Message));
                response.body.state = response.body.phase.ToUpper().Contains("SUCCESSSTATE");
                response.body.fileName = fileName;
                await _repositorie.AddChallenge(response, new Lambda.Model.InformationModel());
                if (data.Image != null)
                    parameterimage = new(response.sessionID, response.body.fileName, Convert.ToBase64String(data.Image));
            }
            catch (Exception ex)
            {
                _logger.Debug($"{_parameter.start.userId}|ID: {uid}|REQUEST: {JsonConvert.SerializeObject(_parameter)}");
                _logger.Error(new Exception($"{_parameter.start.userId}|ID: {uid}| MESSAGE: {ex.Message}"));
            }
            finally
            {
                _logger.Debug($"{_parameter.start.userId}|ID: {uid}|GUARDAR IMAGEN INICIO");
                var image = SaveImage(parameterimage);
                _logger.Debug($"{_parameter.start.userId}|ID: {uid}|GUARDAR IMAGEN FIN: {image}");
            }
            _logger.Debug($"{_parameter.start.userId}|ID: {uid}|FIN VERIFICACION");
            return response;
        }
        private async Task<bool> CompareSegip(ParameterCompare _parameter, bool valida)
        {
            if (valida)
            {
                var dataSession = await _repositorie.GetDataSession(_parameter.sessionID);
                _logger.Debug($"{_parameter.sessionID} => VERIFICACION SEGIP INICIO");
                ComparisonModel segip = await _compare.Segip(_parameter.sessionID, _parameter.source, dataSession.idc);
                await _repositorie.AddProcessComparison(new ProcessComparisonModel
                {
                    message = segip.message,
                    status = segip.state,
                    sessionID = _parameter.sessionID,
                    type = "SEGIP",
                    percentage = segip.percentage
                });
                _logger.Debug($"{_parameter.sessionID} => VERIFICACION SEGIP FIN");
                return segip.state;
            }
            else
            {
                await _repositorie.AddProcessComparison(ProcessComparisonModel.Disable(_parameter.sessionID, "SEGIP"));
                return false;
            }
        }
        private async Task<ComparisonModel> CompareCarnetIdentidad(ParameterCompare _parameter, bool valida)
        {
            if (valida)
            {
                _logger.Debug($"{_parameter.sessionID} => VERIFICACION CARNET IDENTIDAD INICIO");
                ComparisonModel carnet = await _compare.CarnetIdentidad(_parameter.sessionID, _parameter.source);
                await _repositorie.AddProcessComparison(new ProcessComparisonModel
                {
                    message = carnet.message,
                    status = carnet.state,
                    sessionID = _parameter.sessionID,
                    type = "CARNET",
                    percentage = carnet.percentage
                });
                _logger.Debug($"{_parameter.sessionID} => VERIFICACION CARNET IDENTIDAD FIN");
                return carnet;
            }
            else
            {
                await _repositorie.AddProcessComparison(ProcessComparisonModel.Disable(_parameter.sessionID, "CARNET"));
                return new ComparisonModel
                {
                    state = true
                };
            }
        }
        private bool SaveImage(ParameterImage _parameter)
        {
            try
            {
                _files.SaveImage(_parameter.sessionID, _parameter.image, _parameter.fileName);
            }
            catch (Exception ex)
            {
                _logger.Debug($"{_parameter.sessionID}: {ex.Message}: JSON => {JsonConvert.SerializeObject(_parameter)}");
            }
            return true;
        }
        //PARAMETER
        public async Task<List<ParameterModel>> ParametersChannel(ParametersChannelRequest request)
        {
            try
            {
                _logger.Debug($"REQUEST => {JsonConvert.SerializeObject(request)}");
                var response = await _repositorie.GetParameter(request.channelId, "ALL");
                return response;
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                throw;
            }
        }
        //MULTIFACTOR
        public async Task<StateSessionResponse> StateSession(BaseRequest request)
        {
            try
            {
                _logger.Debug(string.Format("REQUEST: {0}", JsonConvert.SerializeObject(request)));
                var _phase = await _repositorie.GetChallengeSuccess(request.sessionID);
                var _data = await _repositorie.GetDataSessionV2(request.sessionID);
                string[] state = { "SuccessState", "VerificationFailState", "TimeOutState" };
                StateSessionResponse response = new StateSessionResponse();
                if (!_data.esMenor)
                {
                    response = new StateSessionResponse
                    {
                        Idc = _data.idc,
                        sessionID = request.sessionID,
                        Phase = string.IsNullOrEmpty(_phase.body.phase) ? "InitState" : _phase.body.phase,
                        IdDigitalSignature = _data.id,
                        State = _data.id != 0,
                        FinishedProcess = state.Contains(_phase.body.phase)
                    };
                }
                else
                {
                    var carnetProcess = await _repositorie.GetProcess(request.sessionID);
                    bool validaMenor = false;
                    if (carnetProcess != null && carnetProcess.Value != null)
                    {
                        DetectTextModel model = JsonConvert.DeserializeObject<DetectTextModel>(carnetProcess.Value);
                        validaMenor = model.reverso.EsValido && model.anverso.EsValido;
                    }
                    response = new StateSessionResponse
                    {
                        Idc = _data.idc,
                        sessionID = request.sessionID,
                        Phase = validaMenor ? "SuccessState" : "InitState",
                        IdDigitalSignature = _data.id,
                        State = validaMenor,
                        FinishedProcess = validaMenor
                    };
                }
                return response;
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                throw;
            }
        }
        public async Task<UrlSessionResponse> CreateSession(CreateSessionRequest request, int idChannel)
        {
            try
            {
                _logger.Debug(string.Format("REQUEST: {0}", JsonConvert.SerializeObject(request)));
                CountRetryModel countRetry = await _repositorie.GetCountRetry(request.idc);
                if (countRetry.count >= awsConfig.attempts)
                {
                    if (!countRetry.blocking)
                    {
                        await _repositorie.AddBlocking(request.idc, idChannel);
                    }
                    throw new Exception("EL CLIENTE HA SIDO BLOQUEADO POR VARIOS REINTENTOS.");
                }
                else
                {
                    string guid = Guid.NewGuid().ToString();
                    await _repositorie.AddSession(idChannel, guid, request.idc, request.email, request.celular, request.canal);
                    string nroDocument = request.idc.Substring(0, 8);
                    string complemento = request.idc.Substring(11, 2);
                    _compare.GetDataSegip(nroDocument, complemento);
                    if (request.esMenor.ToUpper() == "SI")
                    {
                        _logger.Debug($"CUENTA MENOR => IDC TUTOR:{request.idcTutor}");
                        nroDocument = request.idcTutor.Substring(0, 8);
                        complemento = request.idcTutor.Substring(11, 2);
                        _compare.GetDataSegip(nroDocument, complemento);
                        await _repositorie.AddMinorAccount(guid, request.idcTutor);
                    }
                    string url = $"{webConfig.url}?GUID={guid}";
                    _logger.Debug($"SESSION CREADA: {guid} IDC: {request.idc}");
                    return new UrlSessionResponse
                    {
                        url = url,
                        sessionID = guid
                    };
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                throw;
            }
        }
        public async Task<SaveResponse> TimeOutState(BaseRequest request)
        {
            try
            {
                VerifyResponse response = new();
                response.sessionID = request.sessionID;
                response.body = new VerifyBodyResponse();
                response.body.phase = "TimeOutState";
                response.body.state = false;
                response.body.message = "ASEGÚRATE DE CUMPLIR CON LAS INTRUCCIONES, POR FAVOR INTENTA DE NUEVO";
                bool _response = await _repositorie.AddChallenge(response, null);
                return new SaveResponse
                {
                    sessionID = request.sessionID,
                    state = _response,
                    message = "COMPLETADO"
                };

            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                throw;
            }
        }
        public async Task<SaveResponse> LoadImage(LoadCardImageRequest request)
        {
            try
            {
                _logger.Debug($"{request.sessionID} GUARDAR IMAGEN CARNET");
                ParameterImage parameter = new(request.sessionID, $"CARNET_{request.lado}.png", request.carnet);
                Thread t = new(new ParameterizedThreadStart(ThreadImage));
                t.Start(parameter);
                var data = await _detectText.GetTextImage(request.sessionID, request.carnet, request.lado);
                return new SaveResponse
                {
                    sessionID = request.sessionID,
                    state = string.IsNullOrEmpty(data.Message),
                    message = string.IsNullOrEmpty(data.Message) ? "COMPLETADO" : data.Message
                };
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                throw;
            }
        }
        public async Task<DataSessionResponse> GetDataSession(BaseRequest request)
        {
            try
            {
                var session = await _repositorie.GetDataSessionV2(request.sessionID);
                var carnetProcess = await _repositorie.GetProcess(request.sessionID);
                var challenge = await _repositorie.GetChallengeSuccess(request.sessionID);
                DataSessionResponse dataSession = new DataSessionResponse();
                dataSession.sessionID = session.sessionID;
                dataSession.IdCanal = session.idCanal;
                dataSession.CarnetAnverso = false;
                dataSession.CarnetReverso = false;
                dataSession.PruebaVida = false;
                dataSession.Pasiva = false;
                dataSession.EsMenor = session.esMenor;
                if (challenge != null)
                {
                    dataSession.PruebaVida = challenge.body.state;
                }
                if (carnetProcess != null && carnetProcess.Value != null)
                {
                    DetectTextModel model = JsonConvert.DeserializeObject<DetectTextModel>(carnetProcess.Value);
                    dataSession.CarnetReverso = model.reverso.EsValido;
                    dataSession.CarnetAnverso = model.anverso.EsValido;
                    if (dataSession.CarnetAnverso && dataSession.CarnetReverso && dataSession.EsMenor)
                    {
                        dataSession.PruebaVida = true;
                    }
                }
                var pasiva = await _repositorie.GetParameter(session.idCanal, "VALIDACION");
                if (pasiva.FirstOrDefault().value == "TRUE")
                {
                    dataSession.Pasiva = true;
                }
                var diferencia = DateTime.Now.Subtract(session.dateCreated);
                if (diferencia.TotalMinutes > webConfig.time)
                {
                    throw new Exception("SESION NO VALIDA");
                }
                return dataSession;
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                throw;
            }
        }
        public async Task<ValidacionResponse> Validator(BaseRequest request)
        {
            try
            {
                var segip = _files.OpenFile(request.sessionID, "FOTO_SEGIP.png");
                ParameterCompare parameter = new(request.sessionID, segip);
                var data = await CompareCarnetIdentidad(parameter, true);
                return new ValidacionResponse
                {
                    sessionID = request.sessionID,
                    validacion = data.state
                };
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                throw;
            }
        }
        //GATEWAY
        public async Task<GenericResponse<int>> Credentials(CredentialGatewayRequest request)
        {
            GenericResponse<int> response = new GenericResponse<int>();
            response.sessionID = request.session;
            response.state = false;
            try
            {
                _logger.Debug(string.Format("REQUEST: {0}", JsonConvert.SerializeObject(request)));
                response.data = await _repositorie.GetChannelCredentials(request.body.accessKey, request.body.secretKey);
                if (response.data != -1)
                    response.state = true;
                else
                {
                    response.message = "CREDENCIALES NO VALIDAS";
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                response.data = -1;
                response.message = ex.Message;
            }
            return response;
        }
        public async Task<GenericResponse<string>> RegisterSession(StartGatewayRequest request, int idChannel)
        {
            GenericResponse<string> response = new GenericResponse<string>();
            response.sessionID = request.sessionID;
            try
            {
                _logger.Debug(string.Format("REQUEST: {0}", JsonConvert.SerializeObject(request)));
                bool valida = !(await _repositorie.ExistSession(request.sessionID));
                if (valida)
                {
                    CountRetryModel countRetry = await _repositorie.GetCountRetry(request.idc);
                    if (countRetry.count >= this.awsConfig.attempts)
                    {
                        if (!countRetry.blocking)
                        {
                            _logger.Debug($"CLIENTE BLOQUEADO IDC: {request.idc}");
                            await _repositorie.AddBlocking(request.idc, idChannel);
                        }
                        response.state = false;
                        response.message = $"EL CLIENTE HA SIDO BLOQUEADO POR VARIOS REINTENTOS.";
                    }
                    else
                    {
                        var thread = new Thread(() => ThreadRegisterSession(request));
                        thread.Start();
                        return new GenericResponse<string>
                        {
                            sessionID = request.sessionID,
                            state = true
                        };
                    }
                }
                else
                {
                    response.state = false;
                    response.message = $"LA SESSION ID EXISTE '{request.sessionID}'";
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                response.state = false;
                response.message = ex.Message;
            }
            return response;
        }
        private void ThreadRegisterSession(object _request)
        {
            lock (_request)
            {
                try
                {
                    StartGatewayRequest request = (StartGatewayRequest)_request;
                    _repositorie.AddSession(request.idChannel, request.sessionID, request.idc, string.Empty, 0, string.Empty);
                    _repositorie.UpdateSession(request.sessionID,
                        request.body.areaHeight,
                        request.body.areaLeft,
                        request.body.areaTop,
                        request.body.areaWidth,
                        request.body.imageHeight,
                        request.body.imageWidth,
                        request.body.minFaceAreaPercent,
                        request.body.noseHeight,
                        request.body.noseLeft,
                        request.body.noseTop,
                        request.body.noseWidth,
                        request.idChannel);
                }
                catch (Exception ex)
                {
                    _logger.Error(ex);
                }
            }
        }
        public GenericResponse<string> Instruction(InstructionGatewayRequest request)
        {
            GenericResponse<string> response = new GenericResponse<string>();
            response.sessionID = request.sessionID;
            try
            {
                var thread = new Thread(() => ThreadIntruction(request));
                thread.Start();
                return new GenericResponse<string>
                {
                    sessionID = request.sessionID,
                    state = true
                };
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                response.state = false;
                response.message = ex.Message;
            }
            return response;
        }
        private void ThreadIntruction(object _request)
        {
            lock (_request)
            {
                try
                {
                    InstructionGatewayRequest request = (InstructionGatewayRequest)_request;
                    string fileName = DateTime.Now.ToString("ddMMyyyyHHmmssfff") + ".png";
                    string file = request.body.image;
                    Lambda.Model.InformationModel information = null;
                    if (!string.IsNullOrEmpty(request.body.information))
                    {
                        information = JsonConvert.DeserializeObject<Lambda.Model.InformationModel>(request.body.information);
                        file = LambdaClient.CreateImage(request.body.image, new Lambda.Model.StartModel
                        {
                            areaHeight = request.body.areaHeight,
                            areaLeft = request.body.areaLeft,
                            areaTop = request.body.areaTop,
                            areaWidth = request.body.areaWidth,
                            imageHeight = request.body.imageHeigth,
                            imageWidth = request.body.imageWidth,
                            noseHeight = request.body.noseHeight,
                            noseLeft = request.body.noseLeft,
                            noseTop = request.body.noseTop,
                            noseWidth = request.body.noseWidth,
                        }, information
                        );
                    }
                    _files.SaveImage(request.sessionID, file, fileName);
                    _repositorie.AddChallenge(new VerifyResponse
                    {
                        sessionID = request.sessionID,
                        body = new VerifyBodyResponse
                        {
                            state = request.body.state,
                            message = request.body.message,
                            phase = request.body.phase,
                            fileName = fileName
                        }
                    }, information);
                }
                catch (Exception ex)
                {
                    _logger.Error(ex);
                }
            }
        }
    }
}
