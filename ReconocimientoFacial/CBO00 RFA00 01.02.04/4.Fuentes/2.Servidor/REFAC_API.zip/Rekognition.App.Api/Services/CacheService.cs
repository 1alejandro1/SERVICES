﻿using BCP.CROSS.LOGGER;
using Microsoft.Extensions.Configuration;
using Rekognition.App.Api.Commons;
using Rekognition.App.Api.Model;
using Rekognition.App.Api.Model.Config;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Rekognition.App.Api.Services
{
    public class CacheService
    {
        private readonly ILogger logger;
        private readonly CacheConfig cacheConfig;

        public CacheService(ILogger logger, IConfiguration configuration)
        {
            this.logger = logger;
            this.cacheConfig = new CacheConfig();
            configuration.GetSection("CacheService").Bind(this.cacheConfig);
        }
        public async Task<List<ParameterModel>> GetParameter(int IDChannel, string Type)
        {
            string method = $"Cache/Parameter?channelId={IDChannel}&type={Type}";
            try
            {
                var response = await ApiRest.GetAsync<List<ParameterModel>>(cacheConfig.Url, method);
                return response;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                throw;
            }
        }
    }
}
