﻿namespace Rekognition.App.Api.DTOs
{
    public class ParametersChannelRequest
    {
        public int channelId { get; set; }
    }
}
