﻿using System.ComponentModel.DataAnnotations;

namespace Rekognition.App.Api.DTOs
{
    public class VerifyRequest : BaseRequest
    {
        /// <summary>
        /// Imagen en base 64
        /// </summary>
        /// <example>iVBORw0KGgoAAAANSUhEUgAAAtAAAAIcCAYAAADffZlTAAAAAXNSR0IArs4c6 MORE...</example>
        [Required(ErrorMessage = "EL CAMPO {0} NO PUEDE ESTAR VACIO")]
        public string image64 { get; set; }
        /// <summary>
        /// Ancho de la imagen
        /// </summary>
        /// <example>720</example>
        [Required(ErrorMessage = "EL CAMPO {0} NO PUEDE ESTAR VACIO")]
        public int imageWidth { get; set; }
        /// <summary>
        /// Alto de la imagen
        /// </summary>
        /// <example>540</example>
        [Required(ErrorMessage = "EL CAMPO {0} NO PUEDE ESTAR VACIO")]
        public int imageHeight { get; set; }
        /// <summary>
        /// Caja posición X
        /// </summary>
        /// <example>208</example>
        [Required(ErrorMessage = "EL CAMPO {0} NO PUEDE ESTAR VACIO")]
        public int areaLeft { get; set; }
        /// <summary>
        /// Caja posición Y
        /// </summary>
        /// <example>67</example>
        [Required(ErrorMessage = "EL CAMPO {0} NO PUEDE ESTAR VACIO")]
        public int areaTop { get; set; }
        /// <summary>
        /// Ancho de la caja
        /// </summary>
        /// <example>303</example>
        [Required(ErrorMessage = "EL CAMPO {0} NO PUEDE ESTAR VACIO")]
        public int areaWidth { get; set; }
        /// <summary>
        /// Alto de la caja
        /// </summary>
        /// <example>405</example>
        [Required(ErrorMessage = "EL CAMPO {0} NO PUEDE ESTAR VACIO")]
        public int areaHeight { get; set; }
        /// <summary>
        /// Porcentaje mínimo del área
        /// </summary>
        /// <example>50</example>
        [Required(ErrorMessage = "EL CAMPO {0} NO PUEDE ESTAR VACIO")]
        public int minFaceAreaPercent { get; set; }
        /// <summary>
        /// Caja nariz posición X
        /// </summary>
        /// <example>267</example>
        [Required(ErrorMessage = "EL CAMPO {0} NO PUEDE ESTAR VACIO")]
        public int noseLeft { get; set; }
        /// <summary>
        /// Caja nariz posición Y
        /// </summary>
        /// <example>210</example>
        [Required(ErrorMessage = "EL CAMPO {0} NO PUEDE ESTAR VACIO")]
        public int noseTop { get; set; }
        /// <summary>
        /// Ancho de la caja nariz
        /// </summary>
        /// <example>20</example>
        [Required(ErrorMessage = "EL CAMPO {0} NO PUEDE ESTAR VACIO")]
        public int noseWidth { get; set; }
        /// <summary>
        /// Alto de la caja nariz
        /// </summary>
        /// <example>20</example>
        [Required(ErrorMessage = "EL CAMPO {0} NO PUEDE ESTAR VACIO")]
        public int noseHeight { get; set; }
        public string cumpleArea { get; set; }
    }
}
