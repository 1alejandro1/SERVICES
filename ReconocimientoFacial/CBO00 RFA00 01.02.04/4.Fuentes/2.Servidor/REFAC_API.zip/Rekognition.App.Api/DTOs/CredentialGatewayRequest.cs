﻿namespace Rekognition.App.Api.DTOs
{
    public class CredentialGatewayRequest
    {
        public string session { get; set; }
        public string fechaHora { get; set; }
        public BodyCredentialGatewayRequest body { get; set; }
    }
    public class BodyCredentialGatewayRequest
    {
        public string accessKey { get; set; }
        public string secretKey { get; set; }
    }
}
