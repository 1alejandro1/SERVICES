﻿using System.ComponentModel.DataAnnotations;

namespace Rekognition.App.Api.DTOs
{
    public class LoadCardImageRequest : BaseRequest
    {
        /// <summary>
        /// Imagen en base 64 carnet de identidad vigente anverso
        /// </summary>
        /// <example>iVBORw0KGgoAAAANSUhEUgAAAtAAAAIcCAYAAADffZlTAAAAAXNSR0IArs4c6 MORE...</example>
        [Required(ErrorMessage = "EL CAMPO {0} NO PUEDE ESTAR VACIO")]
        public string carnet { get; set; }

        /// <summary>
        /// lado de carnet: "ANVERSO" o "REVERSO"
        /// </summary>
        /// <example>iVBORw0KGgoAAAANSUhEUgAAAtAAAAIcCAYAAADffZlTAAAAAXNSR0IArs4c6 MORE...</example>
        [Required(ErrorMessage = "EL CAMPO {0} NO PUEDE ESTAR VACIO")]
        public string lado { get; set; }

    }
}
