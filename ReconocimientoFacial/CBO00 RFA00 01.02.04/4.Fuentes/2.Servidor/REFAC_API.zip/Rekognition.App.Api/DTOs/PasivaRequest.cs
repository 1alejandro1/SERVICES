﻿namespace Rekognition.App.Api.DTOs
{
    public class PasivaRequest : BaseRequest
    {
        public string selfi { get; set; }
    }
}
