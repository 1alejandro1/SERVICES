﻿using System.ComponentModel.DataAnnotations;

namespace Rekognition.App.Api.DTOs
{
    public class BaseRequest
    {
        /// <summary>
        /// Guid de sesión para seguimiento del proceso
        /// </summary>
        /// <example>a40f690a-1340-4e56-9a5a-d75b89209c05</example>
        [Required(ErrorMessage = "EL CAMPO {0} NO PUEDE ESTAR VACIO")]
        public string sessionID { get; set; }
    }
}
