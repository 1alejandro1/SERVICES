﻿namespace Rekognition.App.Api.DTOs
{
    public class StartGatewayRequest
    {
        public string sessionID { get; set; }
        public string fechaHora { get; set; }
        public string idc { get; set; }
        public int idChannel { get; set; }
        public BodyStartGatewayRequest body { get; set; }
    }
    public class BodyStartGatewayRequest
    {
        public int imageWidth { get; set; }
        public int imageHeight { get; set; }
        public int areaLeft { get; set; }
        public int areaTop { get; set; }
        public int areaWidth { get; set; }
        public int areaHeight { get; set; }
        public int minFaceAreaPercent { get; set; }
        public int noseLeft { get; set; }
        public int noseTop { get; set; }
        public int noseWidth { get; set; }
        public int noseHeight { get; set; }
    }
}