﻿namespace Rekognition.App.Api.DTOs
{
    public class InstructionGatewayRequest
    {
        public string sessionID { get; set; }
        public BodyInstructionGatewayRequest body { get; set; }
    }
    public class BodyInstructionGatewayRequest
    {
        public bool state { get; set; }
        public string phase { get; set; }
        public string message { get; set; }
        public string image { get; set; }
        public int imageWidth { get; set; }
        public int imageHeigth { get; set; }
        public int areaLeft { get; set; }
        public int areaTop { get; set; }
        public int areaWidth { get; set; }
        public int areaHeight { get; set; }
        public int noseLeft { get; set; }
        public int noseTop { get; set; }
        public int noseWidth { get; set; }
        public int noseHeight { get; set; }
        public string information { get; set; }
    }
}
