﻿using System.ComponentModel.DataAnnotations;

namespace Rekognition.App.Api.DTOs
{
    public class CreateSessionRequest
    {
        /// <summary>
        /// IDC del cliente a validar.
        /// </summary>
        /// <example>12345678QLP00</example>
        [Required(ErrorMessage = "EL CAMPO {0} NO PUEDE ESTAR VACIO")]
        [StringLength(13, MinimumLength = 13, ErrorMessage = "EL CAMPO {0} DEBE SER DE TAMAÑO {1}")]
        public string idc { get; set; }
        /// <summary>
        /// Correo Electronico del cliente.
        /// </summary>
        /// <example>example@bcp.com.bo</example>
        [Required(ErrorMessage = "EL CAMPO {0} NO PUEDE ESTAR VACIO")]
        [StringLength(50, MinimumLength = 6, ErrorMessage = "EL CAMPO {0} DEBE SER DE TAMAÑO {1}")]
        [EmailAddress(ErrorMessage = "EL CAMPO {0} TIENE QUE TENER FORMATO DE CORREO ELECTRONICO")]
        public string email { get; set; }
        /// <summary>
        /// Nro de Celular del Cliente.
        /// </summary>
        /// <example>74859652</example>
        [Required(ErrorMessage = "EL CAMPO {0} NO PUEDE ESTAR VACIO")]
        public int celular { get; set; }
        /// <summary>
        /// Nombre del canal con el que se realizara la firma digital.
        /// </summary>
        /// <example>RECONOCIMIENTO FACIAL</example>
        [Required(ErrorMessage = "EL CAMPO {0} NO PUEDE ESTAR VACIO")]
        public string canal { get; set; }
        /// <summary>
        /// Flag para validar si es una validación de menor de edad enviar SI
        /// </summary>
        /// <example>SI</example>
        public string esMenor { get; set; }
        /// <summary>
        /// idc del tutor para la validación
        /// </summary>
        /// <example>87654321QLP00</example>
        public string idcTutor { get; set; }
    }
}
