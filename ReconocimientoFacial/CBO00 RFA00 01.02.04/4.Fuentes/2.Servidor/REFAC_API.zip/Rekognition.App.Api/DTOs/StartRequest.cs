﻿using System.ComponentModel.DataAnnotations;

namespace Rekognition.App.Api.DTOs
{
    public class StartRequest : BaseRequest
    {
        /// <summary>
        /// IDC del cliente a validar.
        /// </summary>
        /// <example>08329480QLP00</example>
        [Required(ErrorMessage = "EL CAMPO {0} NO PUEDE ESTAR VACIO")]
        [StringLength(13, MinimumLength = 13, ErrorMessage = "EL CAMPO {0} DEBE SER DE TAMAÑO {1}")]
        public string idc { get; set; }
        /// <summary>
        /// Ancho de la imagen
        /// </summary>
        /// <example>620</example>
        [Required(ErrorMessage = "EL CAMPO {0} NO PUEDE ESTAR VACIO")]
        public int width { get; set; }
        /// <summary>
        /// Alto de la imagen
        /// </summary>
        /// <example>480</example>
        [Required(ErrorMessage = "EL CAMPO {0} NO PUEDE ESTAR VACIO")]
        public int height { get; set; }
        /// <summary>
        /// Session por Multi-Factor
        /// </summary>
        /// <example>false</example>
        public bool multiFactor { get; set; }
    }
}
