﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Rekognition.App.Api.DTOs;
using Rekognition.App.Api.Model;
using Rekognition.App.Api.Services;
using System;
using System.Threading.Tasks;

namespace Rekognition.App.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RekognitionController : ControllerBase
    {
        private readonly IRekognitionService rekognitionService;
        private readonly ICompareService compareService;

        public RekognitionController(IRekognitionService rekognitionService, ICompareService compareService)
        {
            this.rekognitionService = rekognitionService;
            this.compareService = compareService;
        }

        /// <summary>
        /// Obtener GUID de seguimiento.
        /// </summary>
        /// <returns></returns>
        /// <response code="200">OK</response>
        /// <response code="401">Unauthorized</response>
        /// <response code="500">Internal Server Error</response>
        [HttpGet("GetSessionID")]
        [ProducesResponseType(typeof(SessionResponse), 200)]
        public IActionResult GetSessionID()
        {
            try
            {
                int idChannel = int.Parse(HttpContext.Items["ID_CHANNEL"].ToString());
                var response = rekognitionService.GetSessionID();
                return Ok(response);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }

        /// <summary>
        /// Obtener area para el rostro y la area randomica para la acción de la nariz.
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        /// <response code="200">OK</response>
        /// <response code="400">Bad Request</response>
        /// <response code="401">Unauthorized</response>
        /// <response code="500">Internal Server Error</response>
        [HttpPost("Start")]
        [ProducesResponseType(typeof(StartResponse), 200)]
        public async Task<IActionResult> Start([FromBody] StartRequest request)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    int idChannel = int.Parse(HttpContext.Items["ID_CHANNEL"].ToString());
                    var response = await rekognitionService.Start(request, idChannel);
                    return Ok(response);
                }
                else
                {
                    return BadRequest(ModelState);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }

        /// <summary>
        /// Validación si cumple la acción solicitada
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        /// <response code="200">OK</response>
        /// <response code="400">Bad Request</response>
        /// <response code="401">Unauthorized</response>
        /// <response code="500">Internal Server Error</response>
        [HttpPost("Verify")]
        [ProducesResponseType(typeof(VerifyResponse), 200)]
        public async Task<IActionResult> Verify([FromBody] VerifyRequest request)
        {
            try
            {
                int idChannel = int.Parse(HttpContext.Items["ID_CHANNEL"].ToString());
                var response = await rekognitionService.Verify(request, idChannel);
                return Ok(response);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }
    }
}
