﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Rekognition.App.Api.DTOs;
using Rekognition.App.Api.Services;
using System;
using System.Threading.Tasks;

namespace Rekognition.App.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PasivaController : ControllerBase
    {
        private readonly IPasivaService pasiva;

        public PasivaController(IPasivaService pasiva)
        {
            this.pasiva = pasiva;
        }
        [HttpPost("Instruccion")]
        public async Task<IActionResult> GetInstruccion([FromBody] BaseRequest request)
        {
            try
            {
                var response = await pasiva.GetInstruccion(request.sessionID);
                return Ok(response);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }
        [HttpPost("Validacion")]
        public async Task<IActionResult> GetPasiva([FromBody] PasivaRequest request)
        {
            try
            {
                var response = await pasiva.GetValidacion(request.sessionID, request.selfi);
                return Ok(response);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }
    }
}
