﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Rekognition.App.Api.DTOs;
using Rekognition.App.Api.Services;
using System;
using System.Threading.Tasks;

namespace Rekognition.App.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GatewayController : ControllerBase
    {
        private readonly IRekognitionService rekognition;

        public GatewayController(IRekognitionService rekognition)
        {
            this.rekognition = rekognition;
        }

        [HttpPost("Credential")]
        public async Task<IActionResult> Credential([FromBody] CredentialGatewayRequest request)
        {
            try
            {
                var response = await rekognition.Credentials(request);
                return Ok(response);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }
        [HttpPost("Session")]
        public async Task<IActionResult> RegisterSession([FromBody] StartGatewayRequest request)
        {
            try
            {
                var response = await rekognition.RegisterSession(request, request.idChannel);
                return Ok(response);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }
        [HttpPost("Instruction")]
        public IActionResult Instruction([FromBody] InstructionGatewayRequest request)
        {
            try
            {
                var response = rekognition.Instruction(request);
                return Ok(response);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }
    }
}
