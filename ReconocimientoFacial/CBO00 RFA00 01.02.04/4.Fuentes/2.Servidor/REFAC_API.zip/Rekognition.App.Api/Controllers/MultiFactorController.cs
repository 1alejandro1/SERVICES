﻿ using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Rekognition.App.Api.DTOs;
using Rekognition.App.Api.Model;
using Rekognition.App.Api.Model.Response;
using Rekognition.App.Api.Services;
using System;
using System.Threading.Tasks;

namespace Rekognition.App.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MultiFactorController : ControllerBase
    {
        private readonly IFirmaDigitalService _firmaDigital;
        private readonly IRekognitionService _rekognition;

        public MultiFactorController(IFirmaDigitalService firmaDigital, IRekognitionService rekognition)
        {
            this._firmaDigital = firmaDigital;
            this._rekognition = rekognition;
        }

        [HttpPost("CreateSession")]
        [ProducesResponseType(typeof(UrlSessionResponse), 200)]
        public async Task<IActionResult> CreateSession([FromBody] CreateSessionRequest request, [FromServices] IOptions<ApiBehaviorOptions> apiBehaviorOptions)
        {
            try
            {
                int idChannel = int.Parse(HttpContext.Items["ID_CHANNEL"].ToString());
                if (string.IsNullOrEmpty(request.esMenor))
                    request.esMenor = string.Empty;
                if (request.esMenor.ToUpper() == "SI")
                {
                    if (string.IsNullOrEmpty(request.idcTutor))
                    {
                        ModelState.AddModelError(nameof(CreateSessionRequest.idcTutor), "EL CAMPO idcTutor SE ENCUENTRA VACIO");
                        return apiBehaviorOptions.Value.InvalidModelStateResponseFactory(ControllerContext);
                    }
                    if (request.idcTutor.Length < 13)
                    {
                        ModelState.AddModelError(nameof(CreateSessionRequest.idcTutor), "EL CAMPO idcTutor DEBE SER DE TAMAÑO 13");
                        return apiBehaviorOptions.Value.InvalidModelStateResponseFactory(ControllerContext);
                    }

                    if (request.idcTutor == request.idc)
                    {
                        ModelState.AddModelError(nameof(CreateSessionRequest.idcTutor), "EL CAMPO idcTutor NO PUEDE SER IGUAL AL CAMPO IDC");
                        return apiBehaviorOptions.Value.InvalidModelStateResponseFactory(ControllerContext);
                    }
                }
                var response = await _rekognition.CreateSession(request, idChannel);
                return Ok(response);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }

        [HttpPost("DataSession")]
        [ProducesResponseType(typeof(DataSessionResponse), 200)]
        public async Task<IActionResult> GetDataSession([FromBody] BaseRequest request)
        {
            try
            {
                var response = await _rekognition.GetDataSession(request);
                return Ok(response);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }

        [HttpPost("DigitalCert")]
        [ProducesResponseType(typeof(SaveResponse), 200)]
        public async Task<IActionResult> DigitalCert([FromBody] BaseRequest request)
        {
            try
            {
                var response = await _firmaDigital.CreateClient(request);
                return Ok(response);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }

        [HttpPost("LoadImage")]
        [ProducesResponseType(typeof(SaveResponse), 200)]
        public async Task<IActionResult> LoadImage(LoadCardImageRequest request)
        {
            try
            {
                int idChannel = int.Parse(HttpContext.Items["ID_CHANNEL"].ToString());
                var response = await _rekognition.LoadImage(request);
                return Ok(response);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }

        [HttpPost("State")]
        [ProducesResponseType(typeof(StateSessionResponse), 200)]
        public async Task<IActionResult> GetState([FromBody] BaseRequest request)
        {
            try
            {
                var response = await _rekognition.StateSession(request);
                return Ok(response);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }

        [HttpPost("TimeOut")]
        [ProducesResponseType(typeof(SaveResponse), 200)]
        public async Task<IActionResult> TimeOutState([FromBody] BaseRequest request)
        {
            try
            {
                var response = await _rekognition.TimeOutState(request);
                return Ok(response);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }

        [HttpPost("Validacion")]
        [ProducesResponseType(typeof(ValidacionResponse), 200)]
        public async Task<IActionResult> Validator([FromBody] BaseRequest request)
        {
            try
            {
                var response = await _rekognition.Validator(request);
                return Ok(response);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }
    }
}
