﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Rekognition.App.Api.DTOs;
using Rekognition.App.Api.Model;
using Rekognition.App.Api.Services;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Rekognition.App.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ParametersController : ControllerBase
    {
        private readonly IRekognitionService service;

        public ParametersController(IRekognitionService service)
        {
            this.service = service;
        }

        [HttpPost("Channel")]
        [ProducesResponseType(typeof(List<ParameterModel>), 200)]
        public async Task<IActionResult> GetChannel(ParametersChannelRequest request)
        {
            try
            {
                var response = await service.ParametersChannel(request);
                return Ok(response);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }
    }
}
