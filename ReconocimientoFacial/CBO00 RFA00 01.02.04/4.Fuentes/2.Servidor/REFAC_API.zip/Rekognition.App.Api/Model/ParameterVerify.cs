﻿using Rekognition.Lambda.Model;

namespace Rekognition.App.Api.Model
{
    public class ParameterVerify
    {
        public StartModel start { get; set; }
        public string image { get; set; }
        public int channelID { get; set; }
        public bool instruction { get; set; }
        public bool ppe { get; set; }
        public bool labels { get; set; }
        public decimal movimiento { get; set; }

        public ParameterVerify(StartModel start, string image, int channelID, bool instruction, bool ppe, bool labels, decimal movimiento)
        {
            this.start = start;
            this.image = image;
            this.channelID = channelID;
            this.instruction = instruction;
            this.ppe = ppe;
            this.labels = labels;
            this.movimiento = movimiento;
        }
    }
}
