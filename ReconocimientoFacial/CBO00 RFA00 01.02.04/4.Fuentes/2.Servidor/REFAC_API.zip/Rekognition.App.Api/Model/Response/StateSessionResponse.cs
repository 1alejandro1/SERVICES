﻿namespace Rekognition.App.Api.Model
{
    public class StateSessionResponse : BaseResponse
    {
        public string Idc { get; set; }
        public bool State { get; set; }
        public bool FinishedProcess { get; set; }
        public string Phase { get; set; }
        public int IdDigitalSignature { get; set; }
    }
}
