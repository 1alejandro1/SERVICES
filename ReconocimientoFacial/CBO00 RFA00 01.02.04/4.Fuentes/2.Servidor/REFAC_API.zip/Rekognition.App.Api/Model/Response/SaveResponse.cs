﻿namespace Rekognition.App.Api.Model
{
    public class SaveResponse : BaseResponse
    {
        public bool state { get; set; }
        public string message { get; set; }
    }
}
