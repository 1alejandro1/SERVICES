﻿namespace Rekognition.App.Api.Model.Response
{
    public class GenericResponse<T> : BaseResponse
    {
        public bool state { get; set; }
        public T data { get; set; }
        public string message { get; set; }
    }
}
