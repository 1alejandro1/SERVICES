﻿namespace Rekognition.App.Api.Model.Response
{
    public class InstruccionPasivaResponse : BasePasivaResponse
    {
        public string selfi { get; set; }
        public string imgInstruccion { get; set; }
    }
}
