﻿using System;

namespace Rekognition.App.Api.Model
{
    public class SessionDataResponse : BaseResponse
    {
        public string idc { get; set; }
        public string email { get; set; }
        public string celular { get; set; }
        public int id { get; set; }
        public string canal { get; set; }
        public int idCanal { get; set; }
        public bool esMenor { get; set; }
        public string idcTutor { get; set; }
        public DateTime dateCreated { get; set; }
    }
}
