﻿namespace Rekognition.App.Api.Model.Response
{
    public class DataSessionResponse : BaseResponse
    {
        public bool CarnetAnverso { get; set; }
        public bool CarnetReverso { get; set; }
        public bool PruebaVida { get; set; }
        public int IdCanal { get; set; }
        public bool Pasiva { get; set; }
        public bool EsMenor { get; set; }
    }
}
