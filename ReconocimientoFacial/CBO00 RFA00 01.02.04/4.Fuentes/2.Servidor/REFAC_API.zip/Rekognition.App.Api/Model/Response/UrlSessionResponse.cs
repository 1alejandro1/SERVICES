﻿namespace Rekognition.App.Api.Model
{
    public class UrlSessionResponse : BaseResponse
    {
        public string url { get; set; }
    }
}
