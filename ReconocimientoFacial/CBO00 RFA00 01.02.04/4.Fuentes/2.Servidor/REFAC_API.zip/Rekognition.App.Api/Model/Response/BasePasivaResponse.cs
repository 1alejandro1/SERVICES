﻿namespace Rekognition.App.Api.Model.Response
{
    public class BasePasivaResponse
    {
        public string message { get; set; }
        public string code { get; set; }
        public bool success { get; set; }
    }
}
