﻿using System;

namespace Rekognition.App.Api.Model
{
    public class BaseResponse
    {
        public string sessionID { get; set; }
        public string FechaHora { get { return DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"); } }
    }
}
