﻿namespace Rekognition.App.Api.Model
{
    public class SessionResponse
    {
        public string sessionID { get; set; }
    }
}
