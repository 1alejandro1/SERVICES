﻿namespace Rekognition.App.Api.Model.Response
{
    public class ValidacionResponse : BaseResponse
    {
        public bool validacion { get; set; }
    }
}
