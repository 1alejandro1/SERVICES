﻿namespace Rekognition.App.Api.Model
{
    public class VerifyResponse : BaseResponse
    {
        public VerifyBodyResponse body { get; set; }
    }

    public class VerifyBodyResponse
    {
        public bool state { get; set; }
        public string phase { get; set; }
        public string message { get; set; }
        public string fileName { get; set; }
        public string information { get; set; }
    }
}
