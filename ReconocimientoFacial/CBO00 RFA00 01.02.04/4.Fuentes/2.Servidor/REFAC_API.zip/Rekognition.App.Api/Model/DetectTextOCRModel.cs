﻿namespace Rekognition.App.Api.Model
{
    public class DetectTextOCRModel
    {
        public string id_referencia { get; set; }
        public string anverso_reverso { get; set; }
        public bool anverso_valido { get; set; }
        public string numero_ci { get; set; }
        public string extension_ci { get; set; }
        public string vencimiento_ci { get; set; }
        public bool reverso_valido { get; set; }
        public string nombre_cliente { get; set; }
        public string fecha_nac_cliente { get; set; }
        public string estado_civil { get; set; }
        public string Domicilio { get; set; }
        public string full_ocr { get; set; }
        public string cod_resp { get; set; }
        public string msg_resp { get; set; }
    }
}
