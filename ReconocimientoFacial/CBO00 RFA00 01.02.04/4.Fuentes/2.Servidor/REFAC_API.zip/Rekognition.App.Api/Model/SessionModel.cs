﻿namespace Rekognition.App.Api.Model
{
    public class SessionModel
    {
        public string idc { get; set; }
        public bool state { get; set; }
        public string phase { get; set; }
    }
}
