﻿namespace Rekognition.App.Api.Model
{
    public class ComparisonModel
    {
        public string proccess { get; set; }
        public bool state { get; set; }
        public string message { get; set; }
        public decimal percentage { get; set; }
        public string idc { get; set; }
        public string nombreCompleto { get; set; }
        public string image { get; set; }
    }
}
