﻿namespace Rekognition.App.Api.Model
{
    public class FirmaDigitalModel
    {
        public string idClient { get; set; }
        public bool success { get; set; }
        public string message { get; set; }
        public string code { get; set; }
    }

}
