﻿namespace Rekognition.App.Api.Model
{
    public class ProcessComparisonModel
    {
        public string sessionID { get; set; }
        public string type { get; set; }
        public bool status { get; set; }
        public string message { get; set; }
        public decimal percentage { get; set; }

        public static ProcessComparisonModel Disable(string sessionID, string type)
        {
            return new ProcessComparisonModel
            {
                message = "PROCESO DESHABILITADO",
                status = true,
                sessionID = sessionID,
                type = type,
                percentage = 0
            };
        }
    }
}
