﻿using System;

namespace Rekognition.App.Api.Model
{
    public class DetectTextModel
    {
        public AnversoModel anverso { get; set; }
        public ReversoModel reverso { get; set; }
    }

    public class AnversoModel
    {
        public bool EsValido { get; set; }
        public int Idc { get; set; }
        public DateTime FechaExpiracion { get; set; }
        public string Mensaje { get; set; }
    }

    public class ReversoModel
    {
        public bool EsValido { get; set; }
        public int Idc { get; set; }
        public string Nombres { get; set; }
        public DateTime FechaNacimiento { get; set; }
        public bool EsMenor { get; set; }
        public int IdcTutor { get; set; }
        public string NombresTutor { get; set; }
        public string Mensaje { get; set; }
    }
}
