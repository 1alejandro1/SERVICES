﻿namespace Rekognition.App.Api.Model
{
    public class ProcessModel
    {
        public bool State { get; set; }
        public string Value { get; set; }
        public string Message { get; set; }
    }
}
