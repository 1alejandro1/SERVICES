﻿namespace Rekognition.App.Api.Model
{
    public class CopyModel
    {
        public string SessionID { get; set; }
        public string FileName { get; set; }
    }
}
