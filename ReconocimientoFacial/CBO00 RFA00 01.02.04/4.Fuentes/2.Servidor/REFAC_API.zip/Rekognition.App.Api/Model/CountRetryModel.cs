﻿namespace Rekognition.App.Api.Model
{
    public class CountRetryModel
    {
        public int count { get; set; }
        public string idc { get; set; }
        public bool blocking { get; set; }
    }
}