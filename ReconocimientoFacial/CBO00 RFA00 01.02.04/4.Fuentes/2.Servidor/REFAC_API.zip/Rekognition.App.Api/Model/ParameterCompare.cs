﻿using System.Drawing;

namespace Rekognition.App.Api.Model
{
    public class ParameterCompare
    {
        public string sessionID { get; set; }
        public string source { get; set; }

        public ParameterCompare(string sessionID, string source)
        {
            this.sessionID = sessionID;
            this.source = source;
        }
    }
}
