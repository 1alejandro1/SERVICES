﻿namespace Rekognition.App.Api.Model
{
    public class ParameterImage
    {
        public string sessionID { get; set; }
        public string image { get; set; }
        public string fileName { get; set; }

        public ParameterImage(string sessionID, string fileName, string image)
        {
            this.sessionID = sessionID;
            this.image = image;
            this.fileName = fileName;
        }
    }
}
