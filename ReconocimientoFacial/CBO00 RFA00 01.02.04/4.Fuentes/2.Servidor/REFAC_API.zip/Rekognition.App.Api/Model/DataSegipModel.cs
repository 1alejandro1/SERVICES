﻿using System;

namespace Rekognition.App.Api.Model
{
    public class DataSegipModel
    {
        public string code { get; set; }
        public string message { get; set; }
        public string operation { get; set; }
        public bool success { get; set; }
        public DataSegipBodyModel data { get; set; }
        public DateTime dtUltimaActualizacion { get; set; }
    }

    public class DataSegipBodyModel
    {
        public bool EsValido { get; set; }
        public byte[] ReporteCertificacion { get; set; }
        public string apellidoEsposo { get; set; }
        public string ci { get; set; }
        public string complemento { get; set; }
        public string departamento { get; set; }
        public string domicilio { get; set; }
        public string estadoCivil { get; set; }
        public string fechaNacimiento { get; set; }
        public string foto { get; set; }
        public int intCodigoRespuesta { get; set; }
        public string localidad { get; set; }
        public string materno { get; set; }
        public string nombre { get; set; }
        public string nombreConyugue { get; set; }
        public string observacion { get; set; }
        public string pais { get; set; }
        public string paterno { get; set; }
        public string procedencia { get; set; }
        public string profesion { get; set; }
        public string provincia { get; set; }
        public string strCodigoUnico { get; set; }
        public string strDescripcionRespuesta { get; set; }
        public string strMensaje { get; set; }
        public string strTipoMensaje { get; set; }
        public string tipoDeRegistro { get; set; }
    }
}
