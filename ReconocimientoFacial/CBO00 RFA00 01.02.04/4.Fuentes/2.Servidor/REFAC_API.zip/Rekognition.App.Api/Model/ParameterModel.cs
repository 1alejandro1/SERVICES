﻿namespace Rekognition.App.Api.Model
{
    public class ParameterModel
    {
        public string type { get; set; }
        public string name { get; set; }
        public string value { get; set; }
    }
}
