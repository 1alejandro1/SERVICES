﻿namespace Rekognition.App.Api.Model
{
    public class WebConfig
    {
        public string url { get; set; }
        public string detectText { get; set; }
        public int time { get; set; }
    }
}
