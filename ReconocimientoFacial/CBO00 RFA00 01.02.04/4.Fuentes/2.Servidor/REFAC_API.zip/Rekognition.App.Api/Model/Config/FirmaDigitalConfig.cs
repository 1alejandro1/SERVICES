﻿namespace Rekognition.App.Api.Model.Config
{
    public class FirmaDigitalConfig
    {
        public string url { get; set; }
        public string username { get; set; }
        public string password { get; set; }
        public string token { get; set; }
    }
}
