﻿namespace Rekognition.App.Api.Model.Config
{
    public class PasivaConfig
    {
        public string url { get; set; }
    }
}
