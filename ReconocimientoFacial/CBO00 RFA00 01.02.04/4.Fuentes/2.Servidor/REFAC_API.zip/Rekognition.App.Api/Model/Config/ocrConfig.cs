﻿namespace Rekognition.App.Api.Model.Config
{
    public class ocrConfig
    {
        public string user { get; set; }
        public string password { get; set; }
        public string url { get; set; }
    }
}
