﻿namespace Rekognition.App.Api.Model.Config
{
    public class CacheConfig
    {
        public string Url { get; set; }
        public bool Enabled { get; set; }
    }
}
