﻿using System.Collections.Generic;

namespace Rekognition.App.Api.Model
{
    public class AwsConfig
    {
        public string access_key { get; set; }
        public string secret_key { get; set; }
        public string region { get; set; }
        public string functionName { get; set; }
        public int attempts { get; set; }
        public string Color { get; set; }
        public int percentageBW { get; set; }
        public int threshold { get; set; }
        public NoseConfig nose { get; set; }
        public AwsTipoConfig DetectText { get; set; }
    }

    public class AwsTipoConfig
    {
        public string Version { get; set; }
        public List<string> Anverso { get; set; }
        public List<string> Reverso { get; set; }
    }
    public class NoseConfig
    {
        public int minHDist { get; set; }
        public int maxHDist { get; set; }
        public int maxVDist { get; set; }
    }
}
