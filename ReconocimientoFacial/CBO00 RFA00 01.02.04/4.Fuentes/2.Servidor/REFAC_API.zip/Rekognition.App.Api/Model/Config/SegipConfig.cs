﻿namespace Rekognition.App.Api.Model
{
    public class SegipConfig
    {
        public string url { get; set; }
        public string canal { get; set; }
        public string usuario { get; set; }
    }
}
