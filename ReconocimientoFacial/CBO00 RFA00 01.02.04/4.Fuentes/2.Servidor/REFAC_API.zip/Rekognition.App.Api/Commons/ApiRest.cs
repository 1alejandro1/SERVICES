﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace Rekognition.App.Api.Commons
{
    public enum Authentication
    {
        None,
        Ntlm,
        Header,
        BasicAuth
    }
    public class ApiRest
    {
        public static async Task<T> PostAsync<T>(string urlBase, string method, object request, Authentication authentication, string userName = "", string password = "", List<Tuple<string, string>> headers = null)
        {
            string _response = string.Empty;
            HttpClientHandler clientHandler = new HttpClientHandler();
            clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
            HttpClient httpClient = new HttpClient(clientHandler);
            var myContent = JsonConvert.SerializeObject(request);
            var buffer = Encoding.UTF8.GetBytes(myContent);
            var byteContent = new ByteArrayContent(buffer);
            byteContent.Headers.ContentType = new MediaTypeHeaderValue("application/json");
            if (authentication != Authentication.None)
            {
                switch (authentication)
                {
                    case Authentication.None:
                        break;
                    case Authentication.Ntlm:
                        break;
                    case Authentication.Header:
                        httpClient.DefaultRequestHeaders.Add($"ACCESS_KEY", userName);
                        httpClient.DefaultRequestHeaders.Add($"SECRET_KEY", password);
                        break;
                    case Authentication.BasicAuth:
                        var authenticationString = $"{userName}:{password}";
                        var base64EncodedAuthenticationString = Convert.ToBase64String(Encoding.UTF8.GetBytes(authenticationString));
                        httpClient.DefaultRequestHeaders.Add($"Authorization", $"Basic {base64EncodedAuthenticationString}");
                        break;
                    default:
                        break;
                }
            }
            if (headers != null)
            {
                foreach (var item in headers)
                {
                    httpClient.DefaultRequestHeaders.Add(item.Item1, item.Item2);
                }
            }
            var data = await httpClient.PostAsync(urlBase + method, byteContent);
            using (HttpContent content = data.Content)
            {
                _response = await content.ReadAsStringAsync();
            }
            if (data.IsSuccessStatusCode)
            {
                return JsonConvert.DeserializeObject<T>(_response);
            }
            else
            {
                throw new Exception($"{data.StatusCode.ToString()} - {_response}");
            }
        }
        public static async Task<T> GetAsync<T>(string urlBase, string method)
        {
            HttpClientHandler clientHandler = new HttpClientHandler();
            clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
            HttpClient httpClient = new HttpClient(clientHandler);
            var _response = await httpClient.GetAsync(urlBase + method);
            if (_response.IsSuccessStatusCode)
            {
                using (HttpContent content = _response.Content)
                {
                    var data = await content.ReadAsStringAsync();
                    return JsonConvert.DeserializeObject<T>(data);
                }
            }
            else
            {
                throw new Exception($"{_response.StatusCode} - {method}");
            }
        }
    }
}