﻿using BCP.CROSS.COMMON;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace Rekognition.App.Api.healthchecks
{
    public class FileHealthCheck : IHealthCheck
    {
        private readonly IFiles files;

        public FileHealthCheck(IFiles files)
        {
            this.files = files;
        }
        public Task<HealthCheckResult> CheckHealthAsync(HealthCheckContext context, CancellationToken cancellationToken = default)
        {
            try
            {
                var exists = files.ExistsFolder();
                if (exists.Item1)
                    return Task.FromResult(HealthCheckResult.Healthy(exists.Item2));
                else
                    return Task.FromResult(HealthCheckResult.Unhealthy(exists.Item2));
            }
            catch (Exception ex)
            {
                return Task.FromResult(HealthCheckResult.Unhealthy(ex.Message));
            }
        }
    }
}
