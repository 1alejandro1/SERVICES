﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using System.Net.Http;
using System.Security.Authentication;

namespace Rekognition.App.Api.healthchecks
{
    public static class Extension
    {
        public static IServiceCollection AddHealthChecksApi(this IServiceCollection services, int EvaluationTimeOnSeconds)
        {
            services.AddHealthChecks()
                .AddCheck<SecryptHealthCheck>("SECRYPT API",
                    failureStatus: HealthStatus.Unhealthy,
                    tags: new[] { "SECRYPT" })
                .AddCheck<RekognitionHealthCheck>("BD REKOGNITION",
                    failureStatus: HealthStatus.Unhealthy,
                    tags: new[] { "BD" })
                .AddCheck<ServiceSegipHealthCheck>("WCF SERVICE SEGIP",
                    failureStatus: HealthStatus.Unhealthy,
                    tags: new[] { "SERVICE" })
                .AddCheck<FileHealthCheck>("FILE SERVER",
                    failureStatus: HealthStatus.Unhealthy,
                    tags: new[] { "FILES" });
            services.AddHealthChecksUI(setup =>
            {
                setup.SetEvaluationTimeInSeconds(EvaluationTimeOnSeconds);
                setup.UseApiEndpointHttpMessageHandler(sp =>
                {
                    return new HttpClientHandler
                    {
                        ServerCertificateCustomValidationCallback = (sender, certificate, chain, sslPolicyErrors) => { return true; },
                        SslProtocols = SslProtocols.Tls12 | SslProtocols.Tls11 | SslProtocols.Tls
                    };
                });
            }).AddInMemoryStorage();
            return services;
        }
    }
}
