﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Rekognition.App.Api.Model;
using System;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace Rekognition.App.Api.healthchecks
{
    public class ServiceSegipHealthCheck : IHealthCheck
    {
        private static readonly string sectionNameSegip = "segip_service";
        private readonly SegipConfig segipConfig;
        private readonly IHttpClientFactory httpClientFactory;

        public ServiceSegipHealthCheck(IConfiguration configuration, IHttpClientFactory httpClientFactory)
        {
            this.segipConfig = new SegipConfig();
            configuration.GetSection(sectionNameSegip).Bind(segipConfig);
            this.httpClientFactory = httpClientFactory;
        }

        public async Task<HealthCheckResult> CheckHealthAsync(HealthCheckContext context, CancellationToken cancellationToken = default)
        {
            try
            {
                using var httpClient = httpClientFactory.CreateClient();
                var response = await httpClient.GetAsync(segipConfig.url, cancellationToken);
                if (response.IsSuccessStatusCode)
                {
                    return HealthCheckResult.Healthy($"RUNNING WCF SERVICE SEGIP => URL: {segipConfig.url}");
                }
                return HealthCheckResult.Unhealthy($"NOT RUNNING WCF SERVICE SEGIP => URL: {segipConfig.url}");
            }
            catch (Exception ex)
            {
                return HealthCheckResult.Unhealthy(ex.Message);
            }
        }
    }
}
