﻿using BCP.CROSS.DATAACCESS;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using System.Threading;
using System.Threading.Tasks;

namespace Rekognition.App.Api.healthchecks
{
    public class RekognitionHealthCheck : IHealthCheck
    {
        private readonly string database = "REKOGNITION";
        private readonly IDataAccess dataAccess;

        public RekognitionHealthCheck(IDataAccess dataAccess)
        {
            this.dataAccess = dataAccess;
        }

        public async Task<HealthCheckResult> CheckHealthAsync(HealthCheckContext context, CancellationToken cancellationToken = default)
        {
            var check = await dataAccess.Check(database);
            if (check.Item1)
                return HealthCheckResult.Healthy(check.Item2);
            else
                return HealthCheckResult.Unhealthy(check.Item2);
        }
    }
}
