using BCP.CROSS.COMMON;
using BCP.CROSS.DATAACCESS;
using BCP.CROSS.LOGGER;
using BCP.CROSS.SECRYPT;
using HealthChecks.UI.Client;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Models;
using Rekognition.App.Api.healthchecks;
using Rekognition.App.Api.Middleware;
using Rekognition.App.Api.Repositories;
using Rekognition.App.Api.Services;
using Rekognition.App.Api.Swagger;
using Rekognition.Facial;
using Rekognition.Facial.Model;
using System;
using System.IO;
using System.Reflection;

namespace Rekognition.App.Api
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddLogger();
            services.AddDataBase();
            services.AddSecrypt();
            services.AddFileServer();
            services.AddTransient<IRekognitionRepositorie, RekognitionRepositorie>();
            services.AddTransient<IRekognitionService, RekognitionService>();
            services.AddTransient<ICompareService, CompareService>();
            services.AddTransient<IFirmaDigitalService, FirmaDigitalService>();
            services.AddTransient<IDetectTextService, DetectTextService>();
            services.AddTransient<IocrService, ocrService>();
            services.AddTransient<IPasivaService, PasivaService>();
            services.AddTransient<IFacialService, AWSFacialService>();
            services.AddTransient<IVerificationService, VerificationService>();
            services.AddControllers();
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo
                {
                    Title = "API REKOGNITION",
                    Version = "v1"
                });
                var fileName = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
                var filePath = Path.Combine(AppContext.BaseDirectory, fileName);
                c.IncludeXmlComments(filePath);
                c.OperationFilter<HeaderSwaggerAttribute>();
            });
            int EvaluationTimeOnSeconds = int.Parse(Configuration["HealthChecksUI:EvaluationTimeOnSeconds"]);
            services.AddHealthChecksApi(EvaluationTimeOnSeconds);
            services.AddHsts(options =>
            {
                options.MaxAge = TimeSpan.FromDays(60);
            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            app.UseHttpsRedirection();
            app.UseRouting();
            app.UseAuthorization();
            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("../swagger/v1/swagger.json", "API REKOGNITION v1");
            });
            app.UseMiddleware<ApiKeyMiddleware>();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapHealthChecks("/health", new HealthCheckOptions()
                {
                    Predicate = _ => true,
                    ResponseWriter = UIResponseWriter.WriteHealthCheckUIResponse
                });
                endpoints.MapHealthChecksUI(options =>
                {
                    options.UIPath = "/monitor";
                });
                endpoints.MapControllers();
            });
        }
    }
}