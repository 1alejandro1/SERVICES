﻿using Microsoft.AspNetCore.Http;
using Rekognition.App.Api.Repositories;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;

namespace Rekognition.App.Api.Middleware
{
    public class ApiKeyMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly IRekognitionRepositorie _rekogntion;
        private const string ACCESS_KEY = "ACCESS_KEY";
        private const string SECRET_KEY = "SECRET_KEY";
        public ApiKeyMiddleware(RequestDelegate next, IRekognitionRepositorie rekognitionRepositorie)
        {
            _next = next;
            this._rekogntion = rekognitionRepositorie;
        }
        public async Task InvokeAsync(HttpContext context)
        {
            context.Response.Headers.Add("X-Frame-Options", "DENY");
            context.Response.Headers.Add("X-Xss-Protection", "1; mode=block");
            context.Response.Headers.Add("X-Content-Type-Options", "nosniff");
            context.Response.Headers.Add("Referrer-Policy", "no-referrer");

            List<string> urlHeatlh = new() { "HEALTH", "MONITOR", "UI", "FAVICON", "/API/GATEWAY/", "/API/PASIVA/" };
            bool health = urlHeatlh.Any(x => context.Request.Path.Value.ToUpper().Contains(x));
            if (!health)
            {
                if (!context.Request.Headers.TryGetValue(ACCESS_KEY, out var accessKey))
                {
                    context.Response.StatusCode = 401;
                    await context.Response.WriteAsync("ACCESS KEY WAS NOT PROVIDED.");
                    return;
                }
                if (!context.Request.Headers.TryGetValue(SECRET_KEY, out var secretKey))
                {
                    context.Response.StatusCode = 401;
                    await context.Response.WriteAsync("SECRET KEY WAS NOT PROVIDED.");
                    return;
                }
                var response = await _rekogntion.GetChannelCredentials(accessKey, secretKey);
                if (response == -1)
                {
                    context.Response.StatusCode = 401;
                    await context.Response.WriteAsync("UNAUTHORIZED CLIENT");
                    return;
                }
                context.Items["ID_CHANNEL"] = response;
            }
            await _next(context);
        }
    }
}
