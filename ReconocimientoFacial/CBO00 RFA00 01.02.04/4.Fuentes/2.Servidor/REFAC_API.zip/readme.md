# API Rekognition

## :construction_worker: CI / CD

|Ambiente|Integración|Despliegue|
| ------ | ------ | ------ |
| DESARROLLO | ![Generic badge](https://btbdow00/tfs/CANALES%20PRESENCIALES/RECONOCIMIENTO%20FACIAL/_apis/build/status/REFAC_API/REFAC_API?branchName=DESARROLLO) | ![Generic badge](https://btbdow00/tfs/CANALES%20PRESENCIALES/_apis/public/Release/badge/73bc35bc-b618-4875-a3f3-1752e162e5df/2/2)|
| CERTIFICACION |  | ![Generic badge](https://btbdow00/tfs/CANALES%20PRESENCIALES/_apis/public/Release/badge/73bc35bc-b618-4875-a3f3-1752e162e5df/2/8)|
| PRODUCCION |  | ![Generic badge](https://btbdow00/tfs/CANALES%20PRESENCIALES/_apis/public/Release/badge/73bc35bc-b618-4875-a3f3-1752e162e5df/2/14)|

## :bulb: .Net

| Version| Download |
| ------ | ------ |
| .NET Core 6.0| [.NET Core 6.0][PlS20] |


[PlS20]: <https://dotnet.microsoft.com/en-us/download/dotnet/6.0>

## :bookmark_tabs: Overview

### :triangular_flag_on_post: API

* **Application Pools:** PoolApiRekognition

* **Semilla Segurinet:** SegCrypt64Rekognition

* **Version:** `Microsoft Windows Server 2019`

* **Server:**

    |Desarrollo|Certificación|Producción|
    | ------ | ------ | ------ |
    |[DEVRVW00][Pl50]|[CERRVW00][Pl51]|[BTBRVW00][Pl52]|

[Pl50]: <https://DEVRVW00/ApiRekognition/swagger>
[Pl51]: <https://CERRVW00/ApiRekognition/swagger>
[Pl52]: <https://BTBRVW00/ApiRekognition/swagger>

* **Log:** 

    |Ambiente|Ruta|
    | ------ | ------ |
    |DESARROLLO|`C:/BCB_Logs/ApiRekognition`|
    |CERTIFICACION|`C:/BCB_Logs/ApiRekognition`|
    |PRODUCCION|`C:/BCB_Logs/ApiRekognition`|

* **Monitor:**

    |Desarrollo|Certificación|Producción|
    | ------ | ------ | ------ |
    |[DEVRVW00][Pl60]|[CERRVW00][Pl61]|[BTBRVW00][Pl62]|

[Pl60]: <https://DEVRVW00/ApiRekognition/monitor>
[Pl61]: <https://CERRVW00/ApiRekognition/monitor>
[Pl62]: <https://BTBRVW00/ApiRekognition/monitor>

### :triangular_flag_on_post: Database
* **Nombre:** BD_REKOGNITION
* **Version:** `Microsoft SQL Server 2019`
* **Server:**

    |Desarrollo|Certificación|Producción|
    | ------ | ------ | ------ |
    |DEVSSE00|CERSSE00|BTBSSE00|

### :triangular_flag_on_post: File Server
* **Version:** `Microsoft SQL Server 2012`
* **Server:**

    |Desarrollo|Certificación|Producción|
    | ------ | ------ | ------ |
    |[DEVDFS00][Pl70]|[CERDFS00][Pl71]|[BTBDFS00][Pl72]|

[Pl70]: <\\devdfs00\reconocimiento_facial>
[Pl71]: <\\cerdfs00\reconocimiento_facial>
[Pl72]: <\\btbdfs00\reconocimiento_facial>