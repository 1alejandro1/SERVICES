﻿namespace BCP.CROSS.SECRYPT
{
    public class SecryptOptions
    {
        public string semilla { get; set; }
    }
}
