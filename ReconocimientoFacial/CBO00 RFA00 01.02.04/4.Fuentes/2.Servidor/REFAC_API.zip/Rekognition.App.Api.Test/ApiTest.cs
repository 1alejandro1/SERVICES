using Newtonsoft.Json;
using Rekognition.App.Api.Model;
using Rekognition.App.Api.Test.Helpers;
using System;
using System.Drawing;
using System.IO;
using System.Net.Http;
using System.Threading.Tasks;
using Xunit;

namespace Rekognition.App.Api.Test
{
    public class ApiTest : IClassFixture<TestFixture<Startup>>
    {
        private HttpClient _client;
        private string _accessKey = "5FE6E8017CADE35A93E7";
        private string _secretKey = "4DE0E8107CAAFB548F";

        public ApiTest(TestFixture<Startup> fixture)
        {
            this._client = fixture.Client;
            this._client.DefaultRequestHeaders.Remove("ACCESS_KEY");
            this._client.DefaultRequestHeaders.Add("ACCESS_KEY", _accessKey);
            this._client.DefaultRequestHeaders.Remove("SECRET_KEY");
            this._client.DefaultRequestHeaders.Add("SECRET_KEY", _secretKey);
        }

        [Fact]
        public void Template()
        {
            //Arrange
            //Act
            //Assert
        }
        [Fact]
        public async Task Parameters_Channel()
        {
            //Arrange
            var request = new
            {
                Url = "/api/Parameters/Channel",
                Body = new
                {
                    channelId = 1
                }
            };
            //Act
            var response = await _client.PostAsync(request.Url, ContentHelper.GetStringContent(request.Body));
            var value = await response.Content.ReadAsStringAsync();
            //Assert
            response.EnsureSuccessStatusCode();
        }
        [Fact]
        public async Task Rekognition_GetSessionID()
        {
            // Arrange
            var request = $"/api/Rekognition/GetSessionID";
            // Act
            var response = await _client.GetAsync(request);
            var value = await response.Content.ReadAsStringAsync();
            // Assert
            response.EnsureSuccessStatusCode();
        }
        [Fact]
        public async Task Rekognition_Process()
        {
            string fileName = "_Messi1.jpg";
            string Path = @"C:\img\" + fileName;
            StartResponse request = null;
            using (Image image = Image.FromFile(Path))
            {
                string start = await Start(image);
                using (MemoryStream m = new MemoryStream())
                {
                    image.Save(m, image.RawFormat);
                    byte[] imageBytes = m.ToArray();
                    string base64String = Convert.ToBase64String(imageBytes);
                    request = JsonConvert.DeserializeObject<StartResponse>(start);
                    await Verify(request, base64String);
                }
            }
            await LoadDocument_Anverso(request.sessionID);
            await LoadDocument_Reverso(request.sessionID);
        }
        //[Fact]
        //public async Task Rekognition_LoadDocument()
        //{
        //    string sessionID = "3af00d57-483d-409b-b861-35037bc1e3cc";
        //    await LoadDocument_Anverso(sessionID);
        //}
        private async Task<string> Start(Image image)
        {
            var request = new
            {
                Url = "/api/Rekognition/Start",
                Body = new
                {
                    sessionID = Guid.NewGuid().ToString(),
                    idc = "08329480QLP00",
                    width = image.Width,
                    height = image.Height,
                    multiFactor = false
                }
            };
            var response = await _client.PostAsync(request.Url, ContentHelper.GetStringContent(request.Body));
            var value = await response.Content.ReadAsStringAsync();
            response.EnsureSuccessStatusCode();
            return value;
        }
        private async Task Verify(StartResponse start, string base64String)
        {
            var request = new
            {
                Url = "/api/Rekognition/Verify",
                Body = new
                {
                    sessionID = start.sessionID,
                    image64 = base64String,
                    imageWidth = start.body.imageWidth,
                    imageHeight = start.body.imageHeight,
                    areaLeft = start.body.areaLeft,
                    areaTop = start.body.areaTop,
                    areaWidth = start.body.areaWidth,
                    areaHeight = start.body.areaHeight,
                    minFaceAreaPercent = start.body.minFaceAreaPercent,
                    noseLeft = start.body.noseLeft,
                    noseTop = start.body.noseTop,
                    noseWidth = start.body.noseWidth,
                    noseHeight = start.body.noseHeight
                }
            };
            var response = await _client.PostAsync(request.Url, ContentHelper.GetStringContent(request.Body));
            var value = await response.Content.ReadAsStringAsync();
            response.EnsureSuccessStatusCode();
        }
        private async Task LoadDocument_Anverso(string sessionID)
        {
            string Path = @"C:\img\";
            string file = "ANVERSO.jpg";
            //string file = "CARNET_ANVERSO 1.png";
            string base64Source = string.Empty;
            using (Image image = Image.FromFile(Path + file))
            {
                using (MemoryStream m = new MemoryStream())
                {
                    image.Save(m, image.RawFormat);
                    byte[] imageBytes = m.ToArray();
                    base64Source = Convert.ToBase64String(imageBytes);
                }
            }
            var request = new
            {
                Url = "/api/MultiFactor/LoadImage",
                Body = new
                {
                    sessionID = sessionID,
                    carnet = base64Source,
                    lado = "ANVERSO"
                }
            };
            var response = await _client.PostAsync(request.Url, ContentHelper.GetStringContent(request.Body));
            var value = await response.Content.ReadAsStringAsync();
            response.EnsureSuccessStatusCode();
        }
        private async Task LoadDocument_Reverso(string sessionID)
        {
            string Path = @"C:\img\";
            string file = "ANVERSO.jpg";
            //string file = "CARNET_REVERSO_IVO.png";
            //string file = "CARNET_REVERSO_JRGT.png";
            string base64Source = string.Empty;
            using (Image image = Image.FromFile(Path + file))
            {
                using (MemoryStream m = new MemoryStream())
                {
                    image.Save(m, image.RawFormat);
                    byte[] imageBytes = m.ToArray();
                    base64Source = Convert.ToBase64String(imageBytes);
                }
            }
            var request = new
            {
                Url = "/api/MultiFactor/LoadImage",
                Body = new
                {
                    sessionID = sessionID,
                    carnet = base64Source,
                    lado = "ANVERSO"
                }
            };
            var response = await _client.PostAsync(request.Url, ContentHelper.GetStringContent(request.Body));
            var value = await response.Content.ReadAsStringAsync();
            response.EnsureSuccessStatusCode();
        }
        [Fact]
        public async Task Rekognition_Reverso()
        {
            await LoadDocument_Reverso("85673b5d-cfb4-4752-a209-5d4f7eda2118");
        }
    }
}
