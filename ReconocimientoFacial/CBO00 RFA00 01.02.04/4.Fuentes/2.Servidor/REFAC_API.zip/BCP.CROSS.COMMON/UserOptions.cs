﻿namespace BCP.CROSS.COMMON
{
    public class UserOptions
    {
        public string user { get; set; }
        public string password { get; set; }
        public string domain { get; set; }
        public string destination { get; set; }
        public bool active { get; set; }
    }
}
