﻿using BCP.CROSS.SECRYPT;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace BCP.CROSS.COMMON
{
    public static class Extension
    {
        private static readonly string dataBaseSectionName = "fileServer";
        private static readonly string segurinetSectionName = "segurinet";

        public static IServiceCollection AddFileServer(this IServiceCollection services)
        {
            IConfiguration configuration;
            using (var serviceProvider = services.BuildServiceProvider())
            {
                configuration = serviceProvider.GetService<IConfiguration>();
            }
            UserOptions options = new UserOptions();
            configuration.GetSection(dataBaseSectionName).Bind(options);
            SecryptOptions optionsSecrypt = new SecryptOptions();
            configuration.GetSection(segurinetSectionName).Bind(optionsSecrypt);
            services.AddSingleton<IFiles, Files>(sp =>
            {
                return new Files(options, optionsSecrypt);
            });
            return services;
        }
    }
}
