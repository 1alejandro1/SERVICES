﻿using BCP.CROSS.SECRYPT;
using Microsoft.Win32.SafeHandles;
using SimpleImpersonation;
using System;
using System.Drawing;
using System.IO;
using System.Security.Principal;

namespace BCP.CROSS.COMMON
{
    public interface IFiles
    {
        bool SaveFile(string destination, string fileBase64, string filename = "");
        bool SaveImage(string destination, string fileBase64, string filename = "");
        string OpenFile(string destination, string filename);
        bool CopyFile(string destination, string source, string dest);
        Tuple<bool, string> ExistsFolder();
    }

    public class Files : IFiles
    {
        private readonly IManagerSecrypt secrypt;
        private readonly UserOptions userOptions;

        public Files(UserOptions userOptions, SecryptOptions secryptOptions)
        {
            this.userOptions = userOptions;
            this.secrypt = new ManagerSecrypt(secryptOptions.semilla);
        }

        public bool SaveImage(string destination, string fileBase64, string filename = "")
        {
            try
            {
                bool response = false;
                string exception = string.Empty;
                if (userOptions.active)
                {
                    string password = this.secrypt.Desencriptar(userOptions.password);
                    var credentials = new UserCredentials(userOptions.domain, userOptions.user, password);
                    using SafeAccessTokenHandle userHandle = credentials.LogonUser(LogonType.Interactive);
                    WindowsIdentity.RunImpersonated(userHandle, () =>
                    {
                        response = _saveImage(fileBase64, destination, filename, ref exception);
                    });
                }
                else
                {
                    response = _saveImage(fileBase64, destination, filename, ref exception);
                }
                if (!string.IsNullOrEmpty(exception))
                    new Exception(exception);
                return response;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public bool SaveFile(string destination, string fileBase64, string filename = "")
        {
            try
            {
                bool response = false;
                string exception = string.Empty;
                if (userOptions.active)
                {
                    string password = this.secrypt.Desencriptar(userOptions.password);
                    var credentials = new UserCredentials(userOptions.domain, userOptions.user, password);
                    using SafeAccessTokenHandle userHandle = credentials.LogonUser(LogonType.Interactive);
                    WindowsIdentity.RunImpersonated(userHandle, () =>
                    {
                        response = _saveFile(destination, fileBase64, filename, ref exception);
                    });
                }
                else
                {
                    response = _saveFile(destination, fileBase64, filename, ref exception);
                }
                if (!string.IsNullOrEmpty(exception))
                    new Exception(exception);
                return response;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public string OpenFile(string destination, string filename)
        {
            try
            {
                string exception = string.Empty;
                string response = string.Empty;
                if (userOptions.active)
                {
                    string password = this.secrypt.Desencriptar(userOptions.password);
                    var credentials = new UserCredentials(userOptions.domain, userOptions.user, password);
                    using SafeAccessTokenHandle userHandle = credentials.LogonUser(LogonType.Interactive);
                    WindowsIdentity.RunImpersonated(userHandle, () =>
                    {
                        response = _openFile(destination, filename, ref exception);
                    });
                }
                else
                {
                    response = _openFile(destination, filename, ref exception);
                }
                if (!string.IsNullOrEmpty(exception))
                    new Exception(exception);
                return response;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public bool CopyFile(string destination, string source, string dest)
        {
            try
            {
                bool response = false;
                string exception = string.Empty;
                if (userOptions.active)
                {
                    string password = this.secrypt.Desencriptar(userOptions.password);
                    var credentials = new UserCredentials(userOptions.domain, userOptions.user, password);
                    using SafeAccessTokenHandle userHandle = credentials.LogonUser(LogonType.Interactive);
                    WindowsIdentity.RunImpersonated(userHandle, () =>
                    {
                        response = _copyFile(destination, source, dest, ref exception);
                    });
                }
                else
                {
                    response = _copyFile(destination, source, dest, ref exception);
                }
                if (!string.IsNullOrEmpty(exception))
                    new Exception(exception);
                return response;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public Tuple<bool, string> ExistsFolder()
        {
            try
            {
                bool response = false;
                string exception = string.Empty;
                if (userOptions.active)
                {
                    string password = this.secrypt.Desencriptar(userOptions.password);
                    var credentials = new UserCredentials(userOptions.domain, userOptions.user, password);
                    using SafeAccessTokenHandle userHandle = credentials.LogonUser(LogonType.Interactive);
                    WindowsIdentity.RunImpersonated(userHandle, () =>
                    {
                        response = _existsFolder(userOptions.destination, ref exception);
                    });
                }
                else
                {
                    response = _existsFolder(userOptions.destination, ref exception);
                }
                if (!string.IsNullOrEmpty(exception))
                    new Exception(exception);
                return new Tuple<bool, string>(response, response ? $"LA RUTA '{userOptions.destination}' EXISTE" : $"LA RUTA '{userOptions.destination}' NO EXISTE");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private string _openFile(string destination, string filename, ref string exception)
        {
            try
            {
                destination = userOptions.destination + string.Format("\\{0}\\", DateTime.Now.ToString("ddMMyyyy")) + destination;
                destination += $"\\{filename}";
                byte[] files = File.ReadAllBytes(destination);
                return Convert.ToBase64String(files);
            }
            catch (Exception ex)
            {
                exception = ex.Message;
                return string.Empty;
            }
        }
        private bool _saveFile(string destination, string fileBase64, string filename, ref string exception)
        {
            try
            {
                byte[] bytes = Convert.FromBase64String(fileBase64);
                destination = userOptions.destination + string.Format("\\{0}\\", DateTime.Now.ToString("ddMMyyyy")) + destination;
                if (!Directory.Exists(destination))
                    Directory.CreateDirectory(destination);

                if (string.IsNullOrEmpty(filename))
                    destination += $"\\{DateTime.Now:ddMMyyyyHHmmss}.png";
                else
                    destination += $"\\{filename}";
                File.WriteAllBytes(destination, bytes);
                return true;
            }
            catch (Exception ex)
            {
                exception = ex.Message;
                return false;
            }
        }
        private bool _copyFile(string destination, string source, string dest, ref string exception)
        {
            try
            {
                destination = userOptions.destination + string.Format("\\{0}\\", DateTime.Now.ToString("ddMMyyyy")) + destination;
                source = destination + $"\\{source}";
                dest = destination + $"\\{dest}";
                File.Copy(source, dest);
                return true;
            }
            catch (Exception ex)
            {
                exception = ex.Message;
                return false;
            }
        }
        private bool _saveImage(string fileBase64, string destination, string filename, ref string exception)
        {
            try
            {
                byte[] bytes = Convert.FromBase64String(fileBase64);
                Image image;
                using (MemoryStream ms = new MemoryStream(bytes))
                {
                    destination = userOptions.destination + string.Format("\\{0}\\", DateTime.Now.ToString("ddMMyyyy")) + destination;
                    if (!Directory.Exists(destination))
                        Directory.CreateDirectory(destination);
                    if (string.IsNullOrEmpty(filename))
                        destination += $"\\{DateTime.Now:ddMMyyyyHHmmss}.png";
                    else
                        destination += $"\\{filename}";
                    image = Image.FromStream(ms);
                    image.Save(destination);
                }
                return true;
            }
            catch (Exception ex)
            {
                exception = ex.Message;
                return false;
            }
        }
        private bool _existsFolder(string destination, ref string exception)
        {
            try
            {
                return Directory.Exists(destination);
            }
            catch (Exception ex)
            {
                exception = ex.Message;
                return false;
            }
        }
    }
}
