﻿using Amazon;

namespace Rekognition.Facial.Common
{
    public class RegionAWS
    {
        public static RegionEndpoint GetRegion(string region)
        {
            RegionEndpoint _region = null;
            switch (region)
            {
                case "AFSOUTH1":
                    _region = RegionEndpoint.AFSouth1;
                    break;
                case "USISOBEAST1":
                    _region = RegionEndpoint.USIsobEast1;
                    break;
                case "USISOEAST1":
                    _region = RegionEndpoint.USIsoEast1;
                    break;
                case "USGOVCLOUDWEST1":
                    _region = RegionEndpoint.USGovCloudWest1;
                    break;
                case "USGOVCLOUDEAST1":
                    _region = RegionEndpoint.USGovCloudEast1;
                    break;
                case "CNNORTHWEST1":
                    _region = RegionEndpoint.CNNorthWest1;
                    break;
                case "CNNORTH1":
                    _region = RegionEndpoint.CNNorth1;
                    break;
                case "USWEST2":
                    _region = RegionEndpoint.USWest2;
                    break;
                case "USEAST2":
                    _region = RegionEndpoint.USEast2;
                    break;
                case "USEAST1":
                    _region = RegionEndpoint.USEast1;
                    break;
                case "SAEAST1":
                    _region = RegionEndpoint.SAEast1;
                    break;
                case "MESOUTH1":
                    _region = RegionEndpoint.MESouth1;
                    break;
                case "EUWEST3":
                    _region = RegionEndpoint.EUWest3;
                    break;
                case "USWEST1":
                    _region = RegionEndpoint.USWest1;
                    break;
                case "EUWEST1":
                    _region = RegionEndpoint.EUWest1;
                    break;
                case "EUWEST2":
                    _region = RegionEndpoint.EUWest2;
                    break;
                case "APNORTHEAST1":
                    _region = RegionEndpoint.APNortheast1;
                    break;
                case "APNORTHEAST2":
                    _region = RegionEndpoint.APNortheast2;
                    break;
                case "APNORTHEAST3":
                    _region = RegionEndpoint.APNortheast3;
                    break;
                case "APSOUTH1":
                    _region = RegionEndpoint.APSouth1;
                    break;
                case "APSOUTHEAST1":
                    _region = RegionEndpoint.APSoutheast1;
                    break;
                case "APEAST1":
                    _region = RegionEndpoint.APEast1;
                    break;
                case "CACENTRAL1":
                    _region = RegionEndpoint.CACentral1;
                    break;
                case "EUCENTRAL1":
                    _region = RegionEndpoint.EUCentral1;
                    break;
                case "EUNORTH1":
                    _region = RegionEndpoint.EUNorth1;
                    break;
                case "EUSOUTH1":
                    _region = RegionEndpoint.EUSouth1;
                    break;
                case "APSOUTHEAST2":
                    _region = RegionEndpoint.APSoutheast2;
                    break;
                default:
                    break;
            }
            return _region;
        }
    }
}
