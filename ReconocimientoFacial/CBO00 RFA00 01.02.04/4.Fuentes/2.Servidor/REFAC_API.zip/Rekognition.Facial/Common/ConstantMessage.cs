﻿namespace Rekognition.Facial.Common
{
    public class ConstantMessage
    {
        public const string AREA_MESSAGE_1 = "SITÚA TU ROSTRO DENTRO DEL ÁREA.";
        public const string LABEL_MESSAGE_1 = "NECESITAMOS QUE NO EXISTAN OBJETOS ELECTRÓNICOS EN LA IMAGEN.";
        public const string LABEL_MESSAGE_2 = "HEMOS ENCONTRADO OBJETOS OCULTANDO TU ROSTRO.";
        public const string FACE_MESSAGE_1 = "DETECTAMOS MÁS DE UN ROSTRO, (O FOTOS DETRÁS) CAMBIA DE FONDO.";
        public const string FACE_MESSAGE_3 = "POR FAVOR, VUELVE A INTENTARLO.";
        public const string FACE_MESSAGE_4 = "BUSCA UNA ILUMINACIÓN DE FRENTE.";
        public const string FACE_MESSAGE_5 = "POR FAVOR, QUÍTATE LOS LENTES.";
        public const string NOSE_MESSAGE_1 = "GIRA EL CUELLO LLEVANDO LA PUNTA DE LA NARIZ AL CUADRADO {{COLOR}}.";
        public const string NOSE_MESSAGE_2 = "MUEVE Y MANTÉN LA PUNTA DE LA NARÍZ AL CUADRADO {{COLOR}}.";
        public const string COMPLETED_MESSAGE_1 = "INSTRUCCION COMPLETADA, VERIFICANDO IDENTIDAD.";
        public const string VERIFICATION_MESSAGE_1 = "VERIFICACIÓN DE IDENTIDAD COMPLETADA.";
    }
}
