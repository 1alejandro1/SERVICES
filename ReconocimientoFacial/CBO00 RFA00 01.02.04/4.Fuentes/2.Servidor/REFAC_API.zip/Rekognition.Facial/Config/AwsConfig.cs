﻿namespace Rekognition.Facial.Config
{
    public class AwsConfig
    {
        public string Access_key { get; set; }
        public string Secret_key { get; set; }
        public string Region { get; set; }
    }
}
