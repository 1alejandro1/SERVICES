﻿using BCP.CROSS.LOGGER;
using Rekognition.Facial.Model;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Threading.Tasks;
using System.Linq;
using System.Drawing.Imaging;
using System.Text.RegularExpressions;
using System.Text;
using Rekognition.Facial.Common;

namespace Rekognition.Facial
{
    public interface IVerificationService
    {
        Task<FacialResponse> ValidationAsync(FacialRequest request);
    }
    public class VerificationService : IVerificationService
    {
        private readonly IFacialService facialService;
        private readonly ILogger logger;
        private readonly int MIN_FACE_AREA_PERCENT = 50;
        private readonly int NOSE_BOX_SIZE = 25;

        public VerificationService(IFacialService facialService, ILogger logger)
        {
            this.facialService = facialService;
            this.logger = logger;
        }
        public async Task<FacialResponse> ValidationAsync(FacialRequest request)
        {
            string _image = Convert.ToBase64String(request.Image);
            Image temp = Base64ToImage(CleanBase64(_image));
            temp.RotateFlip(RotateFlipType.RotateNoneFlipX);
            request.Image = ImageToByteArray(temp);
            FacialResponse response = new FacialResponse();
            response.State = false;
            response.Message = new List<string>();
            try
            {
                var data = await facialService.FacialAsync(request);
                response.Phase = data.Phase;
                response.Message = data.Message;
                if (data.State)
                {
                    MemoryStream imageStream = new MemoryStream(request.Image, 0, request.Image.Length);
                    imageStream.Write(request.Image, 0, request.Image.Length);
                    Image image = Image.FromStream(imageStream, true);
                    bool isInsideAreaBox = IsInsideAreaBox(request.IdTrace, data.Data, image.Width, image.Height, request.Area);
                    bool isMinFaceAreaPercent = IsMinFaceAreaPercent(request.IdTrace, data.Data, image.Width, image.Height, request.Area, request.minFaceAreaPercentTolerance);
                    bool area = isInsideAreaBox && isMinFaceAreaPercent;
                    Graphics graphics = Graphics.FromImage(image);
                    graphics.DrawRectangle(new Pen(Color.Yellow, 3),
                        x: image.Width * data.Data.BoundingBox.Left,
                        y: image.Height * data.Data.BoundingBox.Top,
                        width: image.Width * data.Data.BoundingBox.Width,
                        height: image.Height * data.Data.BoundingBox.Height);
                    graphics.DrawRectangle(new Pen(Color.Blue, 3),
                        x: request.Area.Left,
                        y: request.Area.Top,
                        width: request.Area.Width,
                        height: request.Area.Height);
                    graphics.DrawRectangle(new Pen(Color.Green, 3),
                        x: request.Nose.Left,
                        y: request.Nose.Top,
                        width: request.Nose.Width,
                        height: request.Nose.Height);
                    foreach (var item in data.Data.Landmarks)
                    {
                        if (item.Type == "eyeLeft" ||
                            item.Type == "eyeRight" ||
                            item.Type == "mouthLeft" ||
                            item.Type == "mouthRight" ||
                            item.Type == "nose" ||
                            item.Type == "upperJawlineLeft" ||
                            item.Type == "upperJawlineRight")
                        {
                            var pointX = item.X * image.Width;
                            var pointY = item.Y * image.Height;
                            graphics.DrawEllipse(new Pen(Color.Yellow, 3), pointX, pointY, 3, 3);
                        }
                    }
                    using MemoryStream ms = new MemoryStream();
                    image.Save(ms, ImageFormat.Jpeg);
                    response.Phase = "AreaState";
                    response.Image = ms.ToArray();
                    if (!area)
                    {
                        response.Message.Add(ConstantMessage.AREA_MESSAGE_1);
                    }
                    else
                    {
                        if (request.Instruction && !(request.Nose.Height == 0 && request.Nose.Width == 0))
                        {
                            response.Phase = "NoseState";
                            string instruction = Instruction(request.IdTrace, data.Data, image.Width, image.Height, request.Nose);
                            if (string.IsNullOrEmpty(instruction))
                            {
                                var validation = await facialService.ValidationFacialAsync(request);
                                response.Phase = validation.Phase;
                                response.Message = validation.Message;
                                if (validation.State)
                                {
                                    response.Phase = "InstructionState";
                                    response.Message.Add(ConstantMessage.COMPLETED_MESSAGE_1);
                                    response.State = true;
                                }
                                else
                                {
                                    response.State = false;
                                }

                            }
                            else
                            {
                                response.Message.Add(instruction);
                            }
                        }
                        else
                        {
                            var validation = await facialService.ValidationFacialAsync(request);
                            response.Phase = validation.Phase;
                            response.Message = validation.Message;
                            if (validation.State)
                            {
                                response.Phase = "InstructionState";
                                response.Message.Add(ConstantMessage.COMPLETED_MESSAGE_1);
                                response.State = true;
                            }
                            else
                            {
                                response.State = false;
                            }
                        }
                    }
                    return response;
                }
                else
                {
                    return response;
                }
            }
            catch (Exception ex)
            {
                logger.Error(new Exception($"[{request.IdTrace}]", ex));
                throw ex;
            }
        }
        private bool IsInsideAreaBox(string IdTrace, Amazon.Rekognition.Model.FaceDetail data, int imageWidth, int imageHeight, Model.Rectangle area)
        {
            try
            {
                float left = imageWidth * data.BoundingBox.Left;
                float top = imageHeight * data.BoundingBox.Top;
                float width = imageWidth * data.BoundingBox.Width;
                float height = imageHeight * data.BoundingBox.Height;
                return (area.Left <= left && area.Top <= top && ((area.Left + area.Width) >= (left + width)) && ((area.Top + area.Height) >= (top + height)));
            }
            catch (Exception ex)
            {
                logger.Error(new Exception($"[{IdTrace}]", ex));
                throw ex;
            }
        }
        private bool IsMinFaceAreaPercent(string IdTrace, Amazon.Rekognition.Model.FaceDetail data, int imageWidth, int imageHeight, Model.Rectangle area, float minFaceAreaPercentTolerance)
        {
            try
            {
                float left = imageWidth * data.BoundingBox.Left;
                float top = imageHeight * data.BoundingBox.Top;
                float width = imageWidth * data.BoundingBox.Width;
                float height = imageHeight * data.BoundingBox.Height;
                float faceAreaBoxArea = area.Width * area.Height;
                float faceBoxArea = width * height;
                float faceAreaPercent = faceBoxArea * 100 / faceAreaBoxArea;
                return faceAreaPercent + this.MIN_FACE_AREA_PERCENT >= minFaceAreaPercentTolerance;
            }
            catch (Exception ex)
            {
                logger.Error(new Exception($"[{IdTrace}]", ex));
                throw ex;
            }
        }
        private string Instruction(string IdTrace, Amazon.Rekognition.Model.FaceDetail data, int imageWidth, int imageHeight, Model.Rectangle nose)
        {
            string result = string.Empty;
            try
            {
                var _nose = data.Landmarks.FirstOrDefault(x => x.Type.Value.ToUpper() == "NOSE");
                float noseLeft = imageWidth * _nose.X;
                float noseTop = imageHeight * _nose.Y;
                var inside = (nose.Left <= noseLeft && noseLeft <= (nose.Left + nose.Width)) && (nose.Top <= noseTop && noseTop <= (nose.Top + nose.Height));
                if (inside)
                {
                    bool challengeInTheRight = nose.Left + NOSE_BOX_SIZE / 2 > imageWidth / 2;
                    bool rotatedRight = data.Pose.Yaw > 10;
                    bool rotatedLeft = data.Pose.Yaw < -10;
                    bool rotatedTop = data.Pose.Pitch > 10;
                    bool rotatedFace = (rotatedLeft || rotatedRight) && rotatedTop;
                    if (!rotatedFace)
                    {
                        result = ConstantMessage.NOSE_MESSAGE_1;
                    }
                    else
                    {
                        if (!((rotatedRight && challengeInTheRight) || (rotatedLeft && !challengeInTheRight)))
                        {
                            result = ConstantMessage.NOSE_MESSAGE_1;
                        }
                    }
                }
                else
                {
                    result = ConstantMessage.NOSE_MESSAGE_2;
                }
                return result;
            }
            catch (Exception ex)
            {
                logger.Error(new Exception($"[{IdTrace}]", ex));
                throw ex;
            }
        }
        private static byte[] ImageToByteArray(Image imageIn)
        {
            using (var ms = new MemoryStream())
            {
                imageIn.Save(ms, ImageFormat.Png);
                return ms.ToArray();
            }
        }
        private static Image Base64ToImage(string base64)
        {
            byte[] bytes = Convert.FromBase64String(base64);
            Image image;
            using (MemoryStream ms = new MemoryStream(bytes))
            {
                image = Image.FromStream(ms);
            }
            return image;
        }
        private static string CleanBase64(string image)
        {
            image = Regex.Replace(image, @"^data:image\/[a-zA-Z]+;base64,", string.Empty);
            StringBuilder _sb = new StringBuilder();
            _sb.Append(image);
            return _sb.ToString();
        }
    }
}
