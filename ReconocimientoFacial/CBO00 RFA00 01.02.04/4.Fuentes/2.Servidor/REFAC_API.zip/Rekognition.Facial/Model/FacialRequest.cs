﻿namespace Rekognition.Facial.Model
{
    public class FacialRequest
    {
        public string IdTrace { get; set; }
        public byte[] Image { get; set; }
        public int minFaceAreaPercentTolerance { get; set; }
        public Rectangle Area { get; set; }
        public Rectangle Nose { get; set; }
        public bool Instruction { get; set; }
    }
}
