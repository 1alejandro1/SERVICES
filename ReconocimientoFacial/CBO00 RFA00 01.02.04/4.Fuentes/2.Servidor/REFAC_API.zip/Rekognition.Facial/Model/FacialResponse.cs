﻿using Amazon.Rekognition.Model;
using System.Collections.Generic;

namespace Rekognition.Facial.Model
{
    public class FacialResponse
    {
        public string Phase { get; set; }
        public FaceDetail Data { get; set; }
        public bool State { get; set; }
        public List<string> Message { get; set; }
        public float Width { get; set; }
        public float Height { get; set; }
        public byte[] Image { get; set; }
    }
}
