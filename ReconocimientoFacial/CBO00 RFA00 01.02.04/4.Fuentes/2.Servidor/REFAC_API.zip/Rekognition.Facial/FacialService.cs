﻿using Amazon.Rekognition;
using Amazon.Rekognition.Model;
using BCP.CROSS.LOGGER;
using BCP.CROSS.SECRYPT;
using Microsoft.Extensions.Configuration;
using Rekognition.Facial.Common;
using Rekognition.Facial.Config;
using Rekognition.Facial.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Rekognition.Facial
{
    public interface IFacialService
    {
        Task<FacialResponse> FacialAsync(FacialRequest request);
        Task<FacialResponse> ValidationFacialAsync(FacialRequest request);
    }
    public class AWSFacialService : IFacialService
    {
        private readonly AwsConfig awsConfig;
        private readonly string AccessKey;
        private readonly string SecretKey;
        private readonly ILogger logger;

        public AWSFacialService(IConfiguration configuration, IManagerSecrypt secrypt, ILogger logger)
        {
            awsConfig = new AwsConfig();
            configuration.GetSection("aws_service").Bind(awsConfig);
            AccessKey = secrypt.Desencriptar(awsConfig.Access_key);
            SecretKey = secrypt.Desencriptar(awsConfig.Secret_key);
            this.logger = logger;
        }
        public async Task<FacialResponse> FacialAsync(FacialRequest request)
        {
            FacialResponse response = new FacialResponse();
            response.Phase = "FaceState";
            response.State = false;
            response.Message = new List<string>();
            try
            {
                using var client = new AmazonRekognitionClient(AccessKey, SecretKey, RegionAWS.GetRegion(awsConfig.Region));
                logger.Debug($"[{request.IdTrace}] INICIO DETECT FACE AWS");
                DetectFacesResponse data = await client.DetectFacesAsync(new Amazon.Rekognition.Model.DetectFacesRequest
                {
                    Image = new Amazon.Rekognition.Model.Image
                    {
                        Bytes = new MemoryStream(request.Image)
                    },
                    Attributes = new List<string> { "ALL" }
                });
                logger.Debug($"[{request.IdTrace}] FIN DETECT FACE AWS");
                if (data.FaceDetails.Count == 1)
                {
                    var person = data.FaceDetails.FirstOrDefault();
                    response.Data = person;
                    if (person.Eyeglasses.Value)
                    {
                        response.State = false;
                        response.Message.Add(ConstantMessage.FACE_MESSAGE_5);
                        logger.Debug($"[{request.IdTrace}] LENTES: {person.Eyeglasses.Confidence} %");
                        return response;
                    }
                    else
                    {
                        response.State = true;
                        response.Message = new List<string> { string.Empty };
                        return response;
                    }
                }
                else
                {
                    response.State = false;
                    response.Message.Add(data.FaceDetails.Count == 0 ? ConstantMessage.AREA_MESSAGE_1 : ConstantMessage.FACE_MESSAGE_1);
                    logger.Debug($"[{request.IdTrace}] {string.Join(",", response.Message)}");
                    return response;
                }
            }
            catch (Exception ex)
            {
                logger.Error(new Exception($"[{request.IdTrace}]", ex));
                throw ex;
            }
        }
        public async Task<FacialResponse> ValidationFacialAsync(FacialRequest request)
        {
            FacialResponse response = new FacialResponse();
            response.Phase = "FaceState";
            response.State = false;
            response.Message = new List<string>();
            try
            {
                using var client = new AmazonRekognitionClient(AccessKey, SecretKey, RegionAWS.GetRegion(awsConfig.Region));
                var label = client.DetectLabelsAsync(new Amazon.Rekognition.Model.DetectLabelsRequest
                {
                    Image = new Amazon.Rekognition.Model.Image
                    {
                        Bytes = new MemoryStream(request.Image)
                    },
                    MaxLabels = 20,
                    MinConfidence = 80
                });
                var equipment = client.DetectProtectiveEquipmentAsync(new Amazon.Rekognition.Model.DetectProtectiveEquipmentRequest
                {
                    Image = new Amazon.Rekognition.Model.Image
                    {
                        Bytes = new MemoryStream(request.Image)
                    },
                    SummarizationAttributes = new Amazon.Rekognition.Model.ProtectiveEquipmentSummarizationAttributes
                    {
                        MinConfidence = 80,
                        RequiredEquipmentTypes = new List<string> { "FACE_COVER", "HEAD_COVER" }
                    }
                });
                var responseLabels = await label;
                var responseEquipement = await equipment;
                List<string> lstEquipment = (from bodyParts in responseEquipement.Persons.FirstOrDefault().BodyParts
                                             from _equipment in bodyParts.EquipmentDetections
                                             where _equipment.CoversBodyPart.Value
                                             select $"{bodyParts.Name} - {_equipment.CoversBodyPart.Confidence} %").ToList();
                List<string> lstLabelsDetect = new List<string> { "SCREEN", "ELECTRONICS", "COMPUTER", "MONITOR", "ART", "DRAWING" };
                List<string> lstLabels = (from labels in responseLabels.Labels
                                          from parent in labels.Parents
                                          where lstLabelsDetect.Contains(parent.Name.ToUpper())
                                          select parent.Name.ToUpper()).ToList();
                if (lstEquipment.Count > 0)
                {
                    response.State = false;
                    response.Phase = "LabelState";
                    logger.Debug($"[{request.IdTrace}] {string.Join(",", lstEquipment)}");
                    response.Message.Add(ConstantMessage.LABEL_MESSAGE_2);
                }
                if (lstLabels.Distinct().ToList().Count > 0)
                {
                    response.State = false;
                    response.Phase = "LabelState";
                    logger.Debug($"[{request.IdTrace}] {string.Join(",", lstLabels)}");
                    response.Message.Add(ConstantMessage.LABEL_MESSAGE_1);
                }
                if (response.Message.Count == 0)
                {
                    response.State = true;
                }
                return response;
            }
            catch (Exception ex)
            {
                logger.Error(new Exception($"[{request.IdTrace}]", ex));
                throw ex;
            }
        }
    }
}
