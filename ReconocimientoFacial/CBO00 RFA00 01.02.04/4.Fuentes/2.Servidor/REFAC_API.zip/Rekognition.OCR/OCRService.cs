﻿using Amazon;
using Amazon.Textract;
using Amazon.Textract.Model;
using Microsoft.Azure.CognitiveServices.Vision.ComputerVision;
using Microsoft.Azure.CognitiveServices.Vision.ComputerVision.Models;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Rekognition.OCR
{
    public interface IOCRService
    {
        Task<List<string>> GetTextAzureAsync();
        Task<List<string>> GetTextAWSAsync();
    }
    public class OCRService : IOCRService
    {
        #region Azure
        private readonly string endpoint = "https://previewbcp.cognitiveservices.azure.com/";
        private readonly string key = "e4d1d7b022ee4560bc25eae5b5c3a781";
        #endregion
        #region AWS
        private readonly string accessKey = "AKIASJWT5GSE4JI5BX42";
        private readonly string secretKey = "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";
        private readonly RegionEndpoint region = RegionEndpoint.USEast1;
        #endregion
        public OCRService()
        {

        }
        public async Task<List<string>> GetTextAzureAsync()
        {
            List<string> lstText = new List<string>();
            try
            {
                string path = @"C:\img\";
                string imageFile = path + "CARNET_REVERSO_IVO.png";
                ApiKeyServiceClientCredentials credentials = new ApiKeyServiceClientCredentials(key);
                var cvClient = new ComputerVisionClient(credentials)
                {
                    Endpoint = endpoint
                };
                using var imageData = File.OpenRead(imageFile);
                var ocrResults = await cvClient.RecognizePrintedTextInStreamAsync(detectOrientation: true, image: imageData, language: OcrLanguages.Es);
                Image image = Image.FromFile(imageFile);
                Graphics graphics = Graphics.FromImage(image);
                Pen pen = new Pen(Color.Green, 5);
                foreach (var region in ocrResults.Regions)
                {
                    foreach (var line in region.Lines)
                    {
                        int[] dims = line.BoundingBox.Split(",").Select(int.Parse).ToArray();
                        Rectangle rect = new Rectangle(dims[0], dims[1], dims[2], dims[3]);
                        graphics.DrawRectangle(pen, rect);
                        string _line = string.Empty;
                        foreach (var word in line.Words)
                        {
                            _line += word.Text + " ";
                        }
                        lstText.Add(_line.TrimEnd().ToUpper());
                    }
                }
                string output_file = path + "ocr_results_azure.jpg";
                image.Save(output_file);
                return lstText;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<List<string>> GetTextAWSAsync()
        {
            List<string> lstText = new List<string>();
            try
            {
                string path = @"C:\img\";
                string imageFile = path + "CARNET_REVERSO_IVO.png";
                using var textractClient = new AmazonTextractClient(accessKey, secretKey, region);
                var bytes = File.ReadAllBytes(imageFile);
                var detectResponse = await textractClient.DetectDocumentTextAsync(new DetectDocumentTextRequest
                {
                    Document = new Document
                    {
                        Bytes = new MemoryStream(bytes)
                    }
                });
                Image image = Image.FromFile(imageFile);
                Graphics graphics = Graphics.FromImage(image);
                Pen pen = new Pen(Color.Green, 5);
                foreach (var item in detectResponse.Blocks)
                {
                    if (item.Confidence > 90)
                    {
                        float x = item.Geometry.BoundingBox.Left * image.Width;
                        float y = item.Geometry.BoundingBox.Top * image.Height;
                        float height = item.Geometry.BoundingBox.Height * image.Height;
                        float width = item.Geometry.BoundingBox.Width * image.Width;
                        graphics.DrawRectangle(pen, x, y, width, height);
                        lstText.Add(item.Text);
                    }
                }
                string output_file = path + "ocr_results_aws.jpg";
                image.Save(output_file);
                return lstText;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
