﻿using Amazon;
using Amazon.Lambda;
using FuzzySharp;
using Newtonsoft.Json;
using Rekognition.Lambda.Model;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Rekognition.Lambda
{
    public class LambdaClient
    {
        private readonly string _accessKey;
        private readonly string _secretKey;
        private readonly string _functionName;
        private readonly string _color;
        private readonly int _percentageBW;
        private readonly RegionEndpoint _region;
        private readonly LambdaConfig _config;

        public LambdaClient(LambdaConfig config)
        {
            this._accessKey = config.accessKey;
            this._secretKey = config.secretKey;
            this._functionName = config.functionName;
            this._color = config.color;
            this._region = RegionAWS.GetRegion(config.region);
            this._percentageBW = config.percentageBW;
            this._config = config;
        }
        public StartResponse StartOnPremise(string id, int width, int height)
        {
            try
            {
                Challenge challenge = new Challenge();
                return challenge.Init(id, width, height, this._config.nose.maxHDist, this._config.nose.maxVDist, this._config.nose.minHDist);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<VerifyResponse> Verify(string image, StartModel model, ProcessAWSConfig process)
        {
            try
            {
                Image temp = Base64ToImage(CleanBase64(image));
                temp.RotateFlip(RotateFlipType.RotateNoneFlipX);
                image = ImageToBase64(temp);
                AmazonLambdaClient client = new AmazonLambdaClient(_accessKey, _secretKey, _region);
                Amazon.Lambda.Model.InvokeRequest ir = new Amazon.Lambda.Model.InvokeRequest
                {
                    InvocationType = InvocationType.RequestResponse,
                    FunctionName = _functionName
                };
                var request = new
                {
                    frameBase64 = CleanBase64(image),
                    model.userId,
                    model.imageWidth,
                    model.imageHeight,
                    model.areaLeft,
                    model.areaTop,
                    model.areaWidth,
                    model.areaHeight,
                    model.minFaceAreaPercent,
                    model.noseLeft,
                    model.noseTop,
                    model.noseWidth,
                    model.noseHeight,
                    method = "VERIFY",
                    labels = process.labels ? "S" : "",
                    ppe = process.ppe ? "S" : "",
                    instruction = process.instruction ? "S" : ""
                };
                ir.Payload = JsonConvert.SerializeObject(request);
                var result = await client.InvokeAsync(ir);
                var strResponse = Encoding.ASCII.GetString(result.Payload.ToArray());
                VerifyResponse verify = JsonConvert.DeserializeObject<VerifyResponse>(strResponse);
                if (verify.information != null && verify.information.Count == 1)
                    verify.image = CreateImage(image, model, verify.information.FirstOrDefault());
                if (verify.body.state == "SuccessState")
                {
                    verify.body.state = "InstructionState";
                    verify.body.message = "VERIFICANDO TU IDENTIDAD";
                }
                verify.body.message = verify.body.message.Replace("{{COLOR}}", _color);
                return verify;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<Body.Facematch> Compare(string source, string target, float porcentaje)
        {
            try
            {
                AmazonLambdaClient client = new AmazonLambdaClient(_accessKey, _secretKey, _region);
                Amazon.Lambda.Model.InvokeRequest ir = new Amazon.Lambda.Model.InvokeRequest
                {
                    InvocationType = InvocationType.RequestResponse,
                    FunctionName = _functionName
                };
                var request = new
                {
                    frameBase64Source = source,
                    frameBase64Target = target,
                    similarity = porcentaje,
                    method = "COMPARE",
                    labels = "",
                    ppe = "",
                    instruction = ""
                };
                ir.Payload = JsonConvert.SerializeObject(request);
                var result = await client.InvokeAsync(ir);
                var strResponse = Encoding.ASCII.GetString(result.Payload.ToArray());
                CompareResponse compare = JsonConvert.DeserializeObject<CompareResponse>(strResponse);
                return compare.body.FaceMatches.FirstOrDefault();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<DetectTextResponse> DetectText(string image, List<string> lstText)
        {
            try
            {
                AmazonLambdaClient client = new AmazonLambdaClient(_accessKey, _secretKey, _region);
                Amazon.Lambda.Model.InvokeRequest ir = new Amazon.Lambda.Model.InvokeRequest
                {
                    InvocationType = InvocationType.RequestResponse,
                    FunctionName = _functionName
                };
                var request = new
                {
                    frameBase64 = ConvertBlackAndWhite(image, _percentageBW),
                    method = "DETECT_TEXT",
                    version = "v1",
                    labels = "",
                    ppe = "",
                    instruction = ""
                };
                ir.Payload = JsonConvert.SerializeObject(request);
                var result = await client.InvokeAsync(ir);
                var strResponse = Encoding.ASCII.GetString(result.Payload.ToArray());
                var response = JsonConvert.DeserializeObject<DetectTextResponse>(strResponse);
                response.body.TextDetections = response.body.TextDetections.Where(x => x.ParentId == null).ToList();
                if (lstText.Count > 0)
                {
                    foreach (var item in lstText)
                    {
                        var val1 = response.body.TextDetections.ToList().FirstOrDefault(x => Fuzz.WeightedRatio(x.DetectedText.ToUpper(), item) >= 75);
                        string text = string.Join(" ", response.body.TextDetections.Select(x => x.DetectedText).ToList());
                        var val2 = text.Contains(item);
                        if (val1 == null && !val2)
                        {

                            response.statusCode = 404;
                            break;
                        }
                    }
                }
                return response;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<DetectTextResponse> DetectTextV2(string image, List<string> lstText)
        {
            try
            {
                AmazonLambdaClient client = new AmazonLambdaClient(_accessKey, _secretKey, _region);
                Amazon.Lambda.Model.InvokeRequest ir = new Amazon.Lambda.Model.InvokeRequest
                {
                    InvocationType = InvocationType.RequestResponse,
                    FunctionName = _functionName
                };
                var request = new
                {
                    frameBase64 = image,
                    method = "DETECT_TEXT",
                    version = "v2",
                    labels = "",
                    ppe = "",
                    instruction = ""
                };
                ir.Payload = JsonConvert.SerializeObject(request);
                var result = await client.InvokeAsync(ir);
                var strResponse = Encoding.ASCII.GetString(result.Payload.ToArray());
                var response = JsonConvert.DeserializeObject<DetectTextV2Response>(strResponse);
                response.body.Blocks = response.body.Blocks.Where(x => x.BlockType == "LINE" && x.Confidence > 80).ToList();
                DetectTextResponse data = new DetectTextResponse();
                data.statusCode = response.statusCode;
                data.body = new BodyDetectText();
                data.body.TextDetections = response.body.Blocks.Select(x => new Textdetection { DetectedText = Regex.Replace(x.Text.ToUpper().Normalize(NormalizationForm.FormD), @"[^a-zA-z0-9 ]+", "") }).ToList();
                if (lstText.Count > 0)
                {
                    foreach (var item in lstText)
                    {
                        var val1 = data.body.TextDetections.ToList().FirstOrDefault(x => Fuzz.WeightedRatio(x.DetectedText.ToUpper(), item) >= 75);
                        string text = string.Join(" ", data.body.TextDetections.Select(x => x.DetectedText).ToList());
                        var val2 = text.Contains(item);
                        if (val1 == null && !val2)
                        {
                            data.statusCode = 404;
                            break;
                        }
                    }
                }
                return data;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public string ComparePartialRatio(List<string> items, string value)
        {
            string response = string.Empty;
            foreach (var item in items)
            {
                if (Fuzz.PartialRatio(item, value) >= 75)
                {
                    response = item;
                    break;
                }
            }
            return response;
        }
        public static string CreateImage(string image, StartModel start, InformationModel information)
        {
            byte[] imageBytes = Convert.FromBase64String(CleanBase64(image));
            MemoryStream imageStream = new MemoryStream(imageBytes, 0, imageBytes.Length);
            imageStream.Write(imageBytes, 0, imageBytes.Length);
            Image img = Image.FromStream(imageStream, true);
            using (Graphics graphics = Graphics.FromImage(img))
            {
                using (Pen brush = new Pen(Color.Red, 3))
                {
                    float x = information.BoundingBox.Left * start.imageWidth;
                    float y = information.BoundingBox.Top * start.imageHeight;
                    float height = information.BoundingBox.Height * start.imageHeight;
                    float width = information.BoundingBox.Width * start.imageWidth;
                    graphics.DrawRectangle(brush, x, y, width, height);
                }
                foreach (var item in information.Landmarks)
                {
                    if (item.Type == "eyeLeft" ||
                        item.Type == "eyeRight" ||
                        item.Type == "mouthLeft" ||
                        item.Type == "mouthRight" ||
                        item.Type == "nose" ||
                        item.Type == "upperJawlineLeft" ||
                        item.Type == "upperJawlineRight")
                    {
                        var pointX = item.X * img.Width;
                        var pointY = item.Y * img.Height;
                        using (Pen pen = new Pen(Color.Yellow, 3))
                        {
                            graphics.DrawEllipse(pen, pointX, pointY, 3, 3);
                        }
                    }
                }
                graphics.DrawRectangle(new Pen(Color.Blue, 3), start.areaLeft, start.areaTop, start.areaWidth, start.areaHeight);
                graphics.DrawRectangle(new Pen(Color.Green, 3), start.noseLeft, start.noseTop, start.noseWidth, start.noseHeight);
                using (MemoryStream ms = new MemoryStream())
                {
                    img.Save(ms, ImageFormat.Jpeg);
                    imageBytes = ms.ToArray();
                    string base64String = Convert.ToBase64String(imageBytes);
                    return base64String;
                }
            }
        }
        public static string ImageToBase64(Image file)
        {
            using (MemoryStream memoryStream = new MemoryStream())
            {
                file.Save(memoryStream, ImageFormat.Png);
                byte[] imageBytes = memoryStream.ToArray();
                return Convert.ToBase64String(imageBytes);
            }
        }
        private static Image Base64ToImage(string base64)
        {
            byte[] bytes = Convert.FromBase64String(base64);
            Image image;
            using (MemoryStream ms = new MemoryStream(bytes))
            {
                image = Image.FromStream(ms);
            }
            return image;
        }
        private static string CleanBase64(string image)
        {
            image = Regex.Replace(image, @"^data:image\/[a-zA-Z]+;base64,", string.Empty);
            StringBuilder _sb = new StringBuilder();
            _sb.Append(image);
            return _sb.ToString();
        }
        public string ConvertBlackAndWhite(string image, int umb)
        {
            if (umb == 0)
            {
                return image;
            }
            else
            {
                Bitmap source = Base64StringToBitmap(image);
                Bitmap target = new Bitmap(source.Width, source.Height, source.PixelFormat);
                for (int i = 0; i < source.Width; i++)
                {
                    for (int e = 0; e < source.Height; e++)
                    {
                        Color col = source.GetPixel(i, e);
                        byte gray = (byte)(col.R * 0.3f + col.G * 0.59f + col.B * 0.11f);
                        byte value = 0;
                        if (gray > umb)
                        {
                            value = 255;
                        }
                        Color newColor = Color.FromArgb(value, value, value);
                        target.SetPixel(i, e, newColor);
                    }
                }
                return BitmapToBase64String(target);
            }
        }
        public static Bitmap Base64StringToBitmap(string base64String)
        {
            byte[] byteBuffer = Convert.FromBase64String(base64String);
            using (MemoryStream memoryStream = new MemoryStream(byteBuffer))
            {
                memoryStream.Position = 0;
                Bitmap bmpReturn = (Bitmap)Bitmap.FromStream(memoryStream);
                memoryStream.Close();
                byteBuffer = null;
                return bmpReturn;
            }
        }
        public static string BitmapToBase64String(Bitmap bImage)
        {
            using (MemoryStream ms = new MemoryStream())
            {
                bImage.Save(ms, ImageFormat.Jpeg);
                byte[] byteImage = ms.ToArray();
                return Convert.ToBase64String(byteImage);
            }
        }
        public static bool SimpleRatio(string input1, string input2)
        {
            var response = Fuzz.Ratio(input1, input2);
            return response > 51;
        }
    }
}
