﻿using System.Collections.Generic;

namespace Rekognition.Lambda.Model
{
    public class DetectTextV2Response
    {
        public int statusCode { get; set; }
        public BodyDetect body { get; set; }
    }

    public class BodyDetect
    {
        public List<Block> Blocks { get; set; }
    }

    public class Httpheaders
    {
        public string xamznrequestid { get; set; }
        public string contenttype { get; set; }
        public string contentlength { get; set; }
        public string date { get; set; }
    }

    public class Block
    {
        public string BlockType { get; set; }
        public string Id { get; set; }
        public Relationship[] Relationships { get; set; }
        public float Confidence { get; set; }
        public string Text { get; set; }
        public string TextType { get; set; }
    }

    public class Relationship
    {
        public string Type { get; set; }
        public string[] Ids { get; set; }
    }

}
