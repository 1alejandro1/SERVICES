﻿namespace Rekognition.Lambda.Model
{
    public class LambdaConfig
    {
        public string accessKey { get; set; }
        public string secretKey { get; set; }
        public string functionName { get; set; }
        public string color { get; set; }
        public string region { get; set; }
        public int percentageBW { get; set; }
        public NoseConfig nose { get; set; }
    }
    public class NoseConfig
    {
        public int minHDist { get; set; }
        public int maxHDist { get; set; }
        public int maxVDist { get; set; }
    }
}
