﻿namespace Rekognition.Lambda.Model
{
    public class CompareResponse : BaseResponse
    {
        public Body body { get; set; }
    }

    public class Body
    {
        public Sourceimageface SourceImageFace { get; set; }
        public Facematch[] FaceMatches { get; set; }

        public class Sourceimageface
        {
            public decimal Confidence { get; set; }
        }

        public class Facematch
        {
            public decimal Similarity { get; set; }
        }
    }
}
