﻿using System.Collections.Generic;

namespace Rekognition.Lambda.Model
{
    public class DetectTextResponse
    {
        public int statusCode { get; set; }
        public BodyDetectText body { get; set; }
    }

    public class BodyDetectText
    {
        public List<Textdetection> TextDetections { get; set; }
    }

    public class Textdetection
    {
        public string DetectedText { get; set; }
        public string ParentId { get; set; }
    }
}
