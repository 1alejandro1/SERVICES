﻿namespace Rekognition.Lambda.Model
{
    public class ProcessAWSConfig
    {
        public bool labels { get; set; }
        public bool ppe { get; set; }
        public bool instruction { get; set; }
    }
}
