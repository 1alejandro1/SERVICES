﻿using System.Collections.Generic;

namespace Rekognition.Lambda.Model
{
    public class VerifyResponse : BaseResponse
    {
        public StateModel body { get; set; }
        public string image { get; set; }
        public List<InformationModel> information { get; set; }
    }

    public class StateModel
    {
        public string state { get; set; }
        public string message { get; set; }
    }

    public class InformationModel
    {
        public Boundingbox BoundingBox { get; set; }
        public Agerange AgeRange { get; set; }
        public Smile Smile { get; set; }
        public Eyeglasses Eyeglasses { get; set; }
        public Sunglasses Sunglasses { get; set; }
        public Gender Gender { get; set; }
        public Beard Beard { get; set; }
        public Mustache Mustache { get; set; }
        public Eyesopen EyesOpen { get; set; }
        public Mouthopen MouthOpen { get; set; }
        public Emotion[] Emotions { get; set; }
        public Landmark[] Landmarks { get; set; }
        public Pose Pose { get; set; }
        public Quality Quality { get; set; }
        public float Confidence { get; set; }
    }

    public class Boundingbox
    {
        public float Width { get; set; }
        public float Height { get; set; }
        public float Left { get; set; }
        public float Top { get; set; }
    }

    public class Agerange
    {
        public int Low { get; set; }
        public int High { get; set; }
    }

    public class Smile
    {
        public bool Value { get; set; }
        public float Confidence { get; set; }
    }

    public class Eyeglasses
    {
        public bool Value { get; set; }
        public float Confidence { get; set; }
    }

    public class Sunglasses
    {
        public bool Value { get; set; }
        public float Confidence { get; set; }
    }

    public class Gender
    {
        public string Value { get; set; }
        public float Confidence { get; set; }
    }

    public class Beard
    {
        public bool Value { get; set; }
        public float Confidence { get; set; }
    }

    public class Mustache
    {
        public bool Value { get; set; }
        public float Confidence { get; set; }
    }

    public class Eyesopen
    {
        public bool Value { get; set; }
        public float Confidence { get; set; }
    }

    public class Mouthopen
    {
        public bool Value { get; set; }
        public float Confidence { get; set; }
    }

    public class Pose
    {
        public float Roll { get; set; }
        public float Yaw { get; set; }
        public float Pitch { get; set; }
    }

    public class Quality
    {
        public float Brightness { get; set; }
        public float Sharpness { get; set; }
    }

    public class Emotion
    {
        public string Type { get; set; }
        public float Confidence { get; set; }
    }

    public class Landmark
    {
        public string Type { get; set; }
        public float X { get; set; }
        public float Y { get; set; }
    }

}
