﻿namespace Rekognition.Lambda.Model
{
    public class BaseResponse
    {
        public int statusCode { get; set; }

    }
}
