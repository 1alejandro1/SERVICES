﻿using Rekognition.Lambda.Model;
using System;
using System.Collections.Generic;

namespace Rekognition.Lambda
{
    public class Challenge
    {
        private readonly float AREA_BOX_WIDTH_RATIO = 0.75f;
        private readonly float AREA_BOX_HEIGHT_RATIO = 0.75f;
        private readonly float AREA_BOX_ASPECT_RATIO = 0.75f;
        private readonly int MIN_FACE_AREA_PERCENT = 50;
        private readonly int NOSE_BOX_SIZE = 25;
        private int NOSE_BOX_CENTER_MIN_H_DIST = 35;
        private int NOSE_BOX_CENTER_MAX_H_DIST = 65;
        private int NOSE_BOX_CENTER_MAX_V_DIST = 35;
        public StartResponse Init(string userId, int width, int height, int maxHDist, int maxVDist, int minHDist)
        {
            NOSE_BOX_CENTER_MIN_H_DIST = minHDist;
            NOSE_BOX_CENTER_MAX_H_DIST = maxHDist;
            NOSE_BOX_CENTER_MAX_V_DIST = maxVDist;
            Rectangle areaBox = GetAreaBox(width, height);
            Rectangle noseBox = GetNoseBox(width, height);
            return new StartResponse
            {
                statusCode = 200,
                body = new StartModel
                {
                    areaHeight = Convert.ToInt32(areaBox.height),
                    areaLeft = Convert.ToInt32(areaBox.left),
                    areaTop = Convert.ToInt32(areaBox.top),
                    areaWidth = Convert.ToInt32(areaBox.width),
                    imageHeight = height,
                    imageWidth = width,
                    minFaceAreaPercent = MIN_FACE_AREA_PERCENT,
                    noseHeight = Convert.ToInt32(noseBox.height),
                    noseLeft = Convert.ToInt32(noseBox.left),
                    noseTop = Convert.ToInt32(noseBox.top),
                    noseWidth = Convert.ToInt32(noseBox.width),
                    userId = userId
                }
            };
        }
        private Rectangle GetAreaBox(int image_width, int image_height)
        {
            Rectangle rectangle = new Rectangle();
            rectangle.height = image_height * AREA_BOX_HEIGHT_RATIO;
            rectangle.width = Math.Min(image_width * AREA_BOX_WIDTH_RATIO, rectangle.height * AREA_BOX_ASPECT_RATIO);
            rectangle.left = image_width / 2 - rectangle.width / 2;
            rectangle.top = image_height / 2 - rectangle.height / 2;
            return rectangle;
        }
        private Rectangle GetNoseBox(int image_width, int image_height)
        {
            Rectangle rectangle = new Rectangle();
            rectangle.width = NOSE_BOX_SIZE;
            rectangle.height = NOSE_BOX_SIZE;
            int multiplier = RandomChoice<int>(new List<int> { 1, -1 });
            Random random = new Random();
            rectangle.left = (image_width / 2) + (multiplier
                * random.Next(NOSE_BOX_CENTER_MIN_H_DIST - 1, NOSE_BOX_CENTER_MAX_H_DIST + 1));
            if (multiplier == -1)
                rectangle.left -= rectangle.width;
            multiplier = RandomChoice<int>(new List<int> { 1, -1 });
            //rectangle.top = image_height / 2 + (multiplier * (new Random().Next(0, NOSE_BOX_CENTER_MAX_V_DIST)));
            rectangle.top = (image_height / 2) + (-1 * new Random().Next(5, NOSE_BOX_CENTER_MAX_V_DIST));
            if (multiplier == -1)
                rectangle.top -= rectangle.height;
            return rectangle;
        }
        private static T RandomChoice<T>(IEnumerable<T> source)
        {
            Random rnd = new Random();
            T result = default;
            int cnt = 0;
            foreach (T item in source)
            {
                cnt++;
                if (rnd.Next(cnt) == 0)
                {
                    result = item;
                }
            }
            return result;
        }
    }
    public class Rectangle
    {
        public float left { get; set; }
        public float top { get; set; }
        public float width { get; set; }
        public float height { get; set; }
    }
}
