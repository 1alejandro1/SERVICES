using NUnit.Framework;
using System.Threading.Tasks;

namespace Rekognition.OCR.Test
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public async Task GetTextAzure()
        {
            IOCRService service = new OCRService();
            var lstText = await service.GetTextAzureAsync();
            Assert.True(lstText.Count > 0);
        }
        [Test]
        public async Task GetTextAWS()
        {
            IOCRService service = new OCRService();
            var lstText = await service.GetTextAWSAsync();
            Assert.True(lstText.Count > 0);
        }
    }
}